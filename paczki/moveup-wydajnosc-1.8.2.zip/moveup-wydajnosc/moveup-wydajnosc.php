<?php
/**
 * Plugin Name: moveUP – Wydajność
 * Description: Poprawki szybkości strony, których nie da się ustawić w panelu: własne, odchudzone fonty strony z wp-content/uploads/moveup-wydajnosc/fonty/fonty.json (albo – gdy tego folderu nie ma – z assets/fonty/ wtyczki) (@font-face w <head> zamiast osobnego CSS motywu Kadence), bez preloadu fontów Kadence, defer dla skryptów Kadence na końcu strony (animacje AOS, akordeon), małe pliki CSS z serwera strony wpisane w kod strony (bez kilkunastu zapytań blokujących wyświetlanie), preload obrazu LCP (np. tła hero) i limit wpisywanego CSS z wp-content/uploads/moveup-wydajnosc/ustawienia.json.
 * Version: 1.8.2
 * Author: moveUP Agency
 * Text Domain: moveup-wydajnosc
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-wydajnosc' );

define( 'MU_WYD_VER', '1.8.2' );

/**
 * Folder fontów: najpierw folder strony wp-content/uploads/moveup-wydajnosc/fonty/ (pliki tej strony – aktualizacje
 * wtyczki go nie ruszają), a gdy go nie ma – assets/fonty/ wtyczki (jak do wersji 1.3). Zwraca [ścieżka, adres URL].
 */
function mu_wyd_fonty_folder() {
	static $folder = null;
	if ( null === $folder ) {
		$up     = wp_upload_dir( null, false );
		$strona = trailingslashit( $up['basedir'] ) . 'moveup-wydajnosc/fonty/';
		$folder = file_exists( $strona . 'fonty.json' )
			? array( $strona, trailingslashit( $up['baseurl'] ) . 'moveup-wydajnosc/fonty/' )
			: array( __DIR__ . '/assets/fonty/', plugins_url( 'assets/fonty/', __FILE__ ) );
		$folder = apply_filters( 'moveup_wydajnosc_fonty_folder', $folder );
	}
	return $folder;
}

/**
 * Fonty strony z fonty.json w folderze fontów: [{ family, style, weight, file, preload? }].
 * Pliki to fonty zmienne przycięte do znaków potrzebnych po polsku (jeden plik na krój) – patrz readme.txt.
 * Pusta lista = fonty zostają takie, jak ustawił motyw.
 */
function mu_wyd_fonty() {
	static $fonty = null;
	if ( null === $fonty ) {
		$plik  = mu_wyd_fonty_folder()[0] . 'fonty.json';
		$fonty = file_exists( $plik ) ? json_decode( (string) file_get_contents( $plik ), true ) : array();
		$fonty = apply_filters( 'moveup_wydajnosc_fonty', is_array( $fonty ) ? $fonty : array() );
	}
	return $fonty;
}

/**
 * Ustawienia tej strony z wp-content/uploads/moveup-wydajnosc/ustawienia.json (folder strony – aktualizacje wtyczki go nie ruszają):
 * {
 *   "inline_css_limit": 18000,                 // limit pliku CSS wpisywanego w stronę (bajty), domyślnie 15000
 *   "defer": ["kadence-blocks-advanced-form"],  // dodatkowe skrypty (uchwyty) z defer – tylko te, które same czekają na DOMContentLoaded
 *   "preload_obrazy": [                        // obrazy LCP odkrywane dopiero z CSS (np. tło hero) – <link rel="preload"> na górze <head>
 *     { "href": "2025/07/hero-mobile.svg",     // względem folderu uploads albo pełny adres
 *       "media": "(max-width: 767px)",         // opcjonalnie
 *       "strony": "glowna" }                   // "glowna" (domyślnie), "wszystkie" albo lista ID stron
 *   ],
 *   "cookieyes_lokalnie": true,                // skrypt startowy CookieYes z serwera strony (kopia odświeżana co 5 min) – patrz niżej
 *   "obrazy_bez_lazy": 1,                      // ile pierwszych obrazów treści ładować od razu (WordPress: 3); reszta loading="lazy"
 *   "cookieyes_w_stronie": true,               // od 1.7.0: treść kopii CookieYes wpisana w <script> (wymaga cookieyes_lokalnie)
 *   "cookieyes_preload_baner": true,           // od 1.7.0: <link rel="preload"> dla banner.js (konkuruje z obrazem LCP – włączaj po pomiarze)
 *   "jquery_w_stopce": true,                   // od 1.7.2: jQuery i jQuery Migrate na końcu strony (gdy nic w <head> ich nie używa)
 *   "css_pozniej": ["trustindex"],             // od 1.7.2: arkusze (uchwyt albo fragment adresu) ładowane bez blokowania – dla treści poniżej pierwszego ekranu
 *   "bez_emoji": true                          // od 1.7.3: bez skryptu emoji WordPressa (obrazki z s.w.org) – jak „usuń emoji” w LiteSpeed Cache,
 *   "po_zgodzie": { … }                        // od 1.8.0: shortcode'y, skrypty i ramki z obcych serwerów dopiero po zgodzie CookieYes – opis niżej
 * }
 * Brak pliku = zachowanie jak w 1.4.
 */
function mu_wyd_ustawienia() {
	static $u = null;
	if ( null === $u ) {
		$plik = trailingslashit( wp_upload_dir( null, false )['basedir'] ) . 'moveup-wydajnosc/ustawienia.json';
		$u    = file_exists( $plik ) ? json_decode( (string) file_get_contents( $plik ), true ) : array();
		$u    = apply_filters( 'moveup_wydajnosc_ustawienia', is_array( $u ) ? $u : array() );
	}
	return $u;
}

// Ile pierwszych obrazów treści bez loading="lazy" (WordPress domyślnie 3 – drugi i trzeci często są poniżej pierwszego ekranu
// i zabierają łącze obrazowi LCP). Od 1.6.0, ustawienia.json → "obrazy_bez_lazy".
add_filter( 'wp_omit_loading_attr_threshold', function ( $ile ) {
	$u = mu_wyd_ustawienia();
	return isset( $u['obrazy_bez_lazy'] ) ? max( 0, (int) $u['obrazy_bez_lazy'] ) : $ile;
} );

add_action( 'wp_head', 'mu_wyd_preload_obrazy', 1 );

function mu_wyd_preload_obrazy() {
	$baza = trailingslashit( wp_upload_dir( null, false )['baseurl'] );
	foreach ( (array) ( mu_wyd_ustawienia()['preload_obrazy'] ?? array() ) as $o ) {
		if ( empty( $o['href'] ) ) {
			continue;
		}
		$strony = $o['strony'] ?? 'glowna';
		if ( 'glowna' === $strony && ! is_front_page() ) {
			continue;
		}
		if ( is_array( $strony ) && ! is_page( array_map( 'intval', $strony ) ) ) {
			continue;
		}
		$href = preg_match( '~^https?://~', $o['href'] ) ? $o['href'] : $baza . ltrim( $o['href'], '/' );
		printf(
			'<link rel="preload" as="image" href="%s"%s fetchpriority="high">' . "\n",
			esc_url( $href ),
			empty( $o['media'] ) ? '' : ' media="' . esc_attr( $o['media'] ) . '"'
		);
	}
}

add_action( 'init', function () {
	if ( ! mu_wyd_fonty() ) {
		return;
	}
	// Kadence: bez preloadu i bez własnego pliku CSS z fontami – zastępuje je @font-face poniżej.
	add_filter( 'kadence_local_fonts_preload', '__return_false' );
	add_filter( 'style_loader_tag', function ( $tag, $handle ) {
		return 'kadence-fonts-gfonts' === $handle ? '' : $tag;
	}, 10, 2 );
	add_action( 'wp_head', 'mu_wyd_font_face', 2 );
} );

function mu_wyd_font_face() {
	$url = mu_wyd_fonty_folder()[1];
	$css = '';
	foreach ( mu_wyd_fonty() as $f ) {
		if ( empty( $f['family'] ) || empty( $f['file'] ) ) {
			continue;
		}
		if ( ! empty( $f['preload'] ) ) { // tylko font tekstu z pierwszego ekranu – każdy preload zabiera łącze CSS-owi
			printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $url . $f['file'] . '?ver=' . MU_WYD_VER ) );
		}
		$css .= sprintf(
			"@font-face{font-family:'%s';font-style:%s;font-weight:%s;font-display:swap;src:url(%s) format('woff2')}",
			esc_attr( $f['family'] ),
			esc_attr( $f['style'] ?? 'normal' ),
			esc_attr( $f['weight'] ?? '400' ),
			esc_url( $url . $f['file'] . '?ver=' . MU_WYD_VER )
		);
	}
	if ( $css ) {
		echo '<style id="moveup-fonty">' . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- wartości oczyszczone wyżej
	}
}

// Skrypty na końcu strony, które same czekają na DOMContentLoaded – defer zamiast blokowania parsera.
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	$defer = apply_filters( 'moveup_wydajnosc_defer', array_merge( array( 'kadence-aos', 'kadence-blocks-accordion' ), (array) ( mu_wyd_ustawienia()['defer'] ?? array() ) ) );
	if ( in_array( $handle, $defer, true ) && false === strpos( $tag, ' defer' ) && false === strpos( $tag, ' async' ) ) {
		$tag = str_replace( ' src=', ' defer src=', $tag );
	}
	return $tag;
}, 10, 2 );

/*
 * Bez skryptu emoji WordPressa (od 1.7.3, ustawienia.json → "bez_emoji": true). WordPress podmienia emoji na obrazki
 * z s.w.org (serwer WordPress.org) – zapytania do obcego serwera przed zgodą i dodatkowy skrypt. Przeglądarki od lat
 * pokazują emoji same. Na serwerach LiteSpeed to samo robi LiteSpeed Cache (optm-emoji_rm); tu – dla stron na Apache.
 */
add_action( 'init', function () {
	if ( empty( mu_wyd_ustawienia()['bez_emoji'] ) || is_admin() ) {
		return;
	}
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	add_filter( 'emoji_svg_url', '__return_false' );
} );

/*
 * jQuery na końcu strony (od 1.7.2, ustawienia.json → "jquery_w_stopce": true). WordPress wstawia jQuery i jQuery Migrate
 * do <head> – blokują wyświetlanie (Budy Zosine: 35 KB przed pierwszym obrazem). Skrypty zależne od jQuery i tak są
 * w stopce; jeśli jakiś skrypt w <head> zależy od jQuery, WordPress i tak wypisze jQuery przed nim (zależności).
 * Włączaj po sprawdzeniu, że w <head> nie ma skryptów wbudowanych używających jQuery.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( empty( mu_wyd_ustawienia()['jquery_w_stopce'] ) || is_admin() ) {
		return;
	}
	$s = wp_scripts();
	foreach ( array( 'jquery', 'jquery-core', 'jquery-migrate' ) as $h ) {
		if ( isset( $s->registered[ $h ] ) ) {
			$s->add_data( $h, 'group', 1 );
		}
	}
}, 999 );

/*
 * Arkusze ładowane bez blokowania (od 1.7.2, ustawienia.json → "css_pozniej": [fragment uchwytu albo adresu, …]):
 * media="print" + onload → "all" (+ <noscript>). Tylko dla stylów treści poniżej pierwszego ekranu (np. widżet opinii),
 * inaczej mignie treść bez stylu. Działa na <link> z kolejki stylów i na <link> wpisanych w treść bloków (np. Trustindex).
 */
function mu_wyd_css_pozniej_pasuje( $tekst ) {
	foreach ( (array) ( mu_wyd_ustawienia()['css_pozniej'] ?? array() ) as $f ) {
		if ( '' !== (string) $f && false !== strpos( $tekst, (string) $f ) ) {
			return true;
		}
	}
	return false;
}
function mu_wyd_css_pozniej_tag( $tag ) {
	if ( false !== strpos( $tag, 'media="print"' ) || false !== strpos( $tag, "media='print'" ) ) {
		return $tag;
	}
	$nowy = preg_replace( '~\s+media=([\'"])[^\'"]*\1~', '', $tag );
	$nowy = preg_replace( '~\s*/?>\s*$~', ' media="print" onload="this.media=\'all\';this.onload=null">', trim( $nowy ) );
	// Kopia w <noscript> bez id – inaczej ten sam id dwa razy na stronie (W3C, od 1.8.1).
	return $nowy . '<noscript>' . preg_replace( '~\s+id=([\'"])[^\'"]*\1~', '', trim( $tag ) ) . '</noscript>';
}
add_filter( 'style_loader_tag', function ( $tag, $handle, $href ) {
	return ( mu_wyd_css_pozniej_pasuje( $handle ) || mu_wyd_css_pozniej_pasuje( (string) $href ) ) ? mu_wyd_css_pozniej_tag( $tag ) : $tag;
}, 30, 3 );
function mu_wyd_css_pozniej_tresc( $html ) {
	if ( empty( mu_wyd_ustawienia()['css_pozniej'] ) || false === strpos( (string) $html, 'stylesheet' ) ) {
		return $html;
	}
	return preg_replace_callback( '~<link\b[^>]*rel=([\'"])stylesheet\1[^>]*>~i', function ( $m ) {
		return mu_wyd_css_pozniej_pasuje( $m[0] ) ? mu_wyd_css_pozniej_tag( $m[0] ) : $m[0];
	}, $html );
}
add_filter( 'render_block', 'mu_wyd_css_pozniej_tresc', 30 );
add_filter( 'the_content', 'mu_wyd_css_pozniej_tresc', 30 ); // shortcode'y (np. Trustindex) – po do_shortcode (11)
add_filter( 'widget_text', 'mu_wyd_css_pozniej_tresc', 30 );

/**
 * Małe arkusze CSS z serwera strony (motyw, bloki Kadence, własne wtyczki) wpisane w <style> w miejscu <link>.
 * Kadence ładuje kilkanaście plików po 1–6 KB – każdy to osobne zapytanie blokujące wyświetlanie strony.
 * Kolejność stylów się nie zmienia (ten sam punkt w kodzie), więc wygląd zostaje – w odróżnieniu od łączenia
 * i minifikacji CSS w LiteSpeed, które przy Kadence psuło układ. Ścieżki url(…) są zamieniane na adresy bezwzględne.
 * Limit rozmiaru pliku: filtr moveup_wydajnosc_inline_css_limit (bajty, 0 = wyłączone), wyjątki: moveup_wydajnosc_inline_css_bez.
 */
add_filter( 'style_loader_tag', 'mu_wyd_inline_css', 20, 4 );

function mu_wyd_inline_css( $tag, $handle, $href, $media ) {
	if ( is_admin() || is_customize_preview() || '' === $tag || ! $href ) {
		return $tag;
	}
	$limit = (int) apply_filters( 'moveup_wydajnosc_inline_css_limit', (int) ( mu_wyd_ustawienia()['inline_css_limit'] ?? 15000 ) );
	$bez   = (array) apply_filters( 'moveup_wydajnosc_inline_css_bez', array() );
	if ( $limit <= 0 || in_array( $handle, $bez, true ) || ! in_array( $media, array( 'all', 'screen', '' ), true ) ) {
		return $tag;
	}
	$plik = mu_wyd_sciezka( $href );
	if ( ! $plik || ! is_readable( $plik ) || filesize( $plik ) > $limit ) {
		return $tag;
	}
	$css = (string) file_get_contents( $plik );
	if ( '' === trim( $css ) || false !== stripos( $css, '</style' ) ) {
		return $tag;
	}
	// url(względny) → adres bezwzględny względem katalogu pliku CSS
	$baza = trailingslashit( dirname( strtok( $href, '?' ) ) );
	$css  = preg_replace_callback( '/url\(\s*([\'"]?)(?!data:|https?:|\/\/|\/|#)([^\'")]+)\1\s*\)/i', function ( $m ) use ( $baza ) {
		return 'url(' . $m[1] . $baza . $m[2] . $m[1] . ')';
	}, $css );
	if ( null !== $css ) {
		$css = preg_replace( '~/\*# sourceMappingURL=[^*]*\*/~', '', $css );
	}
	if ( null !== $css ) { // czasy bez jednostki („transition-delay:0” w animacjach Kadence) – błąd W3C, przeglądarki i tak traktują jak 0s (od 1.8.1)
		$css = preg_replace( '~((?:transition|animation)-(?:delay|duration)\s*:\s*)0(?=\s*[;}!])~i', '${1}0s', $css );
	}
	if ( null === $css || '' === trim( $css ) ) { // błąd wyrażenia – zostaje zwykły <link>
		return $tag;
	}
	return sprintf( '<style id="%s-css"%s>%s</style>' . "\n", esc_attr( $handle ), 'all' === $media || '' === $media ? '' : ' media="' . esc_attr( $media ) . '"', $css );
}

/** Adres pliku z serwera strony → ścieżka na dysku (tylko wp-content i wp-includes, bez plików zewnętrznych). */
function mu_wyd_sciezka( $href ) {
	$url = strtok( set_url_scheme( $href, 'https' ), '?' );
	$map = array(
		set_url_scheme( content_url( '/' ), 'https' )  => trailingslashit( WP_CONTENT_DIR ),
		set_url_scheme( includes_url( '/' ), 'https' ) => trailingslashit( ABSPATH . WPINC ),
	);
	foreach ( $map as $u => $d ) {
		if ( 0 === strpos( $url, $u ) ) {
			$sc = realpath( $d . substr( $url, strlen( $u ) ) );
			return ( $sc && 0 === strpos( $sc, realpath( $d ) ) && '.css' === substr( $sc, -4 ) ) ? $sc : '';
		}
	}
	return '';
}

/* -------------------------------------------------------------------------
 * CookieYes: skrypt startowy z serwera strony (od 1.6.0, ustawienia.json → "cookieyes_lokalnie": true)
 *
 * Wtyczka CookieYes wstawia na górze <head> skrypt z cdn-cookieyes.com, który blokuje wyświetlanie – przeglądarka musi
 * najpierw nawiązać połączenie z drugim serwerem (Lighthouse: FCP +0,6 s, mariabanaszak.pl 94 → 98). Trzymamy kopię
 * tego jednego pliku w wp-content/uploads/moveup-wydajnosc/cookieyes/ i podmieniamy adres w znaczniku; baner,
 * konfiguracja i logi zgód dalej idą z CookieYes (skrypt ma ich adresy w sobie). Kopia odświeża się co 5 minut
 * (zapytanie warunkowe ETag), po zmianie czyści cache stron. Gdy kopii nie ma albo nie odświeżyła się od 6 godzin –
 * zostaje adres CookieYes. Kodu wtyczki CookieYes nie zmieniamy.
 * ---------------------------------------------------------------------- */
define( 'MU_WYD_CKY_OPCJA', 'mu_wyd_cookieyes' );
define( 'MU_WYD_CKY_CRON', 'mu_wyd_cookieyes_odswiez' );

function mu_wyd_cky_wlaczone() {
	return ! empty( mu_wyd_ustawienia()['cookieyes_lokalnie'] );
}

function mu_wyd_cky_folder() {
	$u = wp_upload_dir( null, false );
	return array( trailingslashit( $u['basedir'] ) . 'moveup-wydajnosc/cookieyes/', trailingslashit( $u['baseurl'] ) . 'moveup-wydajnosc/cookieyes/' );
}

/** Dane kopii dla adresu skryptu: [adres lokalny z wersją] albo '' gdy kopii nie wolno użyć. */
function mu_wyd_cky_lokalny( $zrodlo ) {
	$o = get_option( MU_WYD_CKY_OPCJA, array() );
	if ( empty( $o['zrodlo'] ) || $o['zrodlo'] !== $zrodlo || empty( $o['plik'] ) || empty( $o['sprawdzono'] ) || time() - (int) $o['sprawdzono'] > 6 * HOUR_IN_SECONDS ) {
		return '';
	}
	list( $dir, $url ) = mu_wyd_cky_folder();
	if ( ! is_readable( $dir . $o['plik'] ) || filesize( $dir . $o['plik'] ) < 1000 ) {
		return '';
	}
	return $url . $o['plik'] . '?ver=' . rawurlencode( $o['wersja'] ?? '1' );
}

/**
 * Treść kopii do wpisania w <script> (od 1.7.0, ustawienia.json → "cookieyes_w_stronie": true, wymaga "cookieyes_lokalnie").
 * '' gdy opcja wyłączona albo treść nie nadaje się do wpisania w HTML (wtedy zostaje plik z serwera strony).
 */
function mu_wyd_cky_w_kodzie( $zrodlo ) {
	if ( empty( mu_wyd_ustawienia()['cookieyes_w_stronie'] ) ) {
		return '';
	}
	$o = get_option( MU_WYD_CKY_OPCJA, array() );
	list( $dir ) = mu_wyd_cky_folder();
	$tresc = ( ! empty( $o['plik'] ) && is_readable( $dir . $o['plik'] ) ) ? (string) file_get_contents( $dir . $o['plik'] ) : '';
	if ( strlen( $tresc ) < 1000 || strlen( $tresc ) > 60000 || preg_match( '~</script|<script|<!--~i', $tresc ) ) {
		return '';
	}
	return trim( $tresc );
}

/** Adres pliku banera CookieYes z treści skryptu startowego (do preloadu) albo ''. */
function mu_wyd_cky_baner( $zrodlo ) {
	if ( ! preg_match( '~^https://cdn-cookieyes\.com/client_data/([a-f0-9]{16,64})/script\.js$~', $zrodlo, $m ) ) {
		return '';
	}
	return 'https://cdn-cookieyes.com/client_data/' . $m[1] . '/banner.js';
}

/**
 * Pobiera skrypt (warunkowo) i zapisuje kopię.
 *
 * @return string|WP_Error 'bez zmian', 'nowa wersja' albo błąd.
 */
function mu_wyd_cky_odswiez( $zrodlo = '' ) {
	$o      = get_option( MU_WYD_CKY_OPCJA, array() );
	$zrodlo = $zrodlo ? $zrodlo : ( $o['zrodlo'] ?? '' );
	if ( ! preg_match( '~^https://cdn-cookieyes\.com/client_data/([a-f0-9]{16,64})/script\.js$~', $zrodlo, $m ) ) {
		return new WP_Error( 'mu_wyd_cky_adres', 'Nieznany adres skryptu CookieYes.' );
	}
	$naglowki = array();
	if ( ! empty( $o['etag'] ) && ( $o['zrodlo'] ?? '' ) === $zrodlo ) {
		$naglowki['If-None-Match'] = $o['etag'];
	}
	$r = wp_remote_get( $zrodlo, array( 'timeout' => 10, 'headers' => $naglowki ) );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	$kod = (int) wp_remote_retrieve_response_code( $r );
	if ( 304 === $kod ) {
		$o['sprawdzono'] = time();
		update_option( MU_WYD_CKY_OPCJA, $o, false );
		return 'bez zmian';
	}
	$tresc = (string) wp_remote_retrieve_body( $r );
	// Kontrola treści: to ma być ten skrypt startowy, dla tej witryny.
	if ( 200 !== $kod || strlen( $tresc ) < 1000 || false === strpos( $tresc, $m[1] ) || false !== stripos( substr( $tresc, 0, 200 ), '<html' ) ) {
		return new WP_Error( 'mu_wyd_cky_tresc', 'CookieYes zwrócił kod ' . $kod . ' albo nieoczekiwaną treść.' );
	}
	list( $dir ) = mu_wyd_cky_folder();
	wp_mkdir_p( $dir );
	$plik = 'cookieyes-' . $m[1] . '.js';
	$tmp  = $dir . $plik . '.tmp';
	if ( false === file_put_contents( $tmp, $tresc ) || ! rename( $tmp, $dir . $plik ) ) {
		return new WP_Error( 'mu_wyd_cky_zapis', 'Nie udało się zapisać kopii skryptu.' );
	}
	$nowa = substr( md5( $tresc ), 0, 10 );
	$zmiana = ( $o['wersja'] ?? '' ) !== $nowa;
	update_option( MU_WYD_CKY_OPCJA, array(
		'zrodlo'     => $zrodlo,
		'plik'       => $plik,
		'etag'       => (string) wp_remote_retrieve_header( $r, 'etag' ),
		'wersja'     => $nowa,
		'sprawdzono' => time(),
		'zmieniono'  => time(),
	), false );
	if ( $zmiana ) {
		do_action( 'litespeed_purge_all' ); // strony z cache dostaną adres z nową wersją
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache(); // WP Super Cache (serwery Apache bez LiteSpeed) – od 1.7.1
		}
	}
	return $zmiana ? 'nowa wersja' : 'bez zmian';
}

add_filter( 'cron_schedules', function ( $s ) {
	$s['mu_wyd_5min'] = array( 'interval' => 5 * MINUTE_IN_SECONDS, 'display' => 'Co 5 minut (moveUP – Wydajność)' );
	return $s;
} );
add_action( MU_WYD_CKY_CRON, 'mu_wyd_cky_odswiez' );
add_action( 'init', function () {
	$jest = wp_next_scheduled( MU_WYD_CKY_CRON );
	if ( mu_wyd_cky_wlaczone() && ! $jest ) {
		wp_schedule_event( time() + 60, 'mu_wyd_5min', MU_WYD_CKY_CRON );
	} elseif ( ! mu_wyd_cky_wlaczone() && $jest ) {
		wp_clear_scheduled_hook( MU_WYD_CKY_CRON );
	}
} );
register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( MU_WYD_CKY_CRON );
} );

// Podmiana adresu w znaczniku, który CookieYes wypisuje w wp_head z priorytetem 1 (bufor od priorytetu 0 do 2).
add_action( 'wp_head', function () {
	if ( mu_wyd_cky_wlaczone() ) {
		ob_start();
		$GLOBALS['mu_wyd_cky_bufor'] = true;
	}
}, 0 );
add_action( 'wp_head', function () {
	if ( empty( $GLOBALS['mu_wyd_cky_bufor'] ) ) {
		return;
	}
	$GLOBALS['mu_wyd_cky_bufor'] = false;
	$html = (string) ob_get_clean();
	if ( preg_match( '~<script[^>]*\bid="cookieyes"[^>]*\bsrc="(https://cdn-cookieyes\.com/client_data/[a-f0-9]+/script\.js)"~', $html, $m ) ) {
		$lokalny  = mu_wyd_cky_lokalny( $m[1] );
		$w_kodzie = $lokalny ? mu_wyd_cky_w_kodzie( $m[1] ) : '';
		if ( $w_kodzie ) {
			// 1.7.0: treść kopii w znaczniku zamiast src – bez zapytania blokującego wyświetlanie; kolejność wykonania ta sama.
			// Preload pliku banera: skrypt startowy dokłada go dopiero po wykonaniu – przeglądarka zaczyna pobierać wcześniej.
			$baner = empty( mu_wyd_ustawienia()['cookieyes_preload_baner'] ) ? '' : mu_wyd_cky_baner( $m[1] );
			$html  = preg_replace_callback(
				'~<script\b[^>]*\bid="cookieyes"[^>]*>\s*</script>~',
				function ( $t ) use ( $m, $w_kodzie, $baner ) {
					return ( $baner ? '<link rel="preload" as="script" href="' . esc_url( $baner ) . '">' . "\n" : '' )
						. '<script id="cookieyes" data-zrodlo="' . esc_url( $m[1] ) . '">' . $w_kodzie . '</script>';
				},
				$html,
				1
			);
		} elseif ( $lokalny ) {
			$html = str_replace( 'src="' . $m[1] . '"', 'src="' . esc_url( $lokalny ) . '" data-zrodlo="' . esc_url( $m[1] ) . '"', $html );
		} else {
			$o = get_option( MU_WYD_CKY_OPCJA, array() );
			if ( ( $o['zrodlo'] ?? '' ) !== $m[1] ) { // pierwsze uruchomienie albo inna witryna CookieYes – zapamiętaj adres, kopię zrobi cron
				update_option( MU_WYD_CKY_OPCJA, array( 'zrodlo' => $m[1] ), false );
				wp_schedule_single_event( time(), MU_WYD_CKY_CRON );
			}
		}
	}
	// W3C (od 1.6.1): CookieYes 3.5.9 dodaje do znacznika atrybut NitroPacka „nitro-exclude” (błąd walidatora) i zbędne
	// type="text/javascript" (ostrzeżenie). Usuwamy oba tylko w znaczniku <script id="cookieyes">; NitroPacka na stronach nie ma.
	$html = preg_replace_callback(
		'~<script\b[^>]*\bid="cookieyes"[^>]*>~',
		function ( $t ) {
			return preg_replace( array( '~\s+nitro-exclude(?=[\s>])~', '~\s+type="text/javascript"~' ), '', $t[0] );
		},
		$html
	);
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- wyjście innych wtyczek z wp_head, zmienione tylko adres i atrybuty skryptu CookieYes
}, 2 );

/*
 * Treści z obcych serwerów dopiero po zgodzie (od 1.8.0, ustawienia.json → "po_zgodzie"):
 * {
 *   "kategoria": "functional",                       // kategoria CookieYes: functional, analytics, performance, advertisement
 *   "shortcode": ["trustindex"],                     // wyjście tych shortcode'ów czeka na zgodę (np. widżet opinii z awatarami Google)
 *   "skrypty": ["trustindex-loader-js"],             // uchwyty skryptów (id bez „-js” albo z) – ładowane dopiero po zgodzie
 *   "iframe": ["pomagam.pl"],                        // ramki z tych serwerów w treści czekają na zgodę
 *   "teksty": { "trustindex": "Opinie z Google…" },  // komunikat zamiast treści (klucz: shortcode albo serwer ramki)
 *   "tekst": "…", "przycisk": "Ustawienia plików cookie"   // domyślny komunikat i napis przycisku
 * }
 * Do czasu zgody w miejscu treści jest komunikat z przyciskiem otwierającym ustawienia CookieYes; sama treść leży
 * w <template> (przeglądarka nie pobiera z niej obrazów ani skryptów). Po zgodzie (od razu albo po kliknięciu w banerze)
 * skrypt podstawia treść i dokłada wstrzymane skrypty. Strony z WP Super Cache działają, bo decyzja zapada w przeglądarce.
 */
function mu_wyd_zgoda() {
	$u = mu_wyd_ustawienia()['po_zgodzie'] ?? array();
	return is_array( $u ) && $u ? $u : null;
}
function mu_wyd_zgoda_owin( $html, $klucz ) {
	$u = mu_wyd_zgoda();
	$GLOBALS['mu_wyd_zgoda_uzyta'] = true;
	$tekst = $u['teksty'][ $klucz ] ?? ( $u['tekst'] ?? 'Ta treść pochodzi z innego serwisu. Wyświetli się po zgodzie na pliki cookie funkcjonalne.' );
	return '<div class="mu-zgoda" data-kategoria="' . esc_attr( $u['kategoria'] ?? 'functional' ) . '"><template>' . $html . '</template>'
		. '<div class="mu-zgoda__info"><p class="mu-zgoda__tekst">' . esc_html( $tekst ) . '</p>'
		. '<button type="button" class="mu-zgoda__ustawienia">' . esc_html( $u['przycisk'] ?? 'Ustawienia plików cookie' ) . '</button></div></div>';
}
add_filter( 'do_shortcode_tag', function ( $wyjscie, $tag ) {
	$u = mu_wyd_zgoda();
	if ( ! $u || is_admin() || wp_doing_ajax() || defined( 'REST_REQUEST' ) || ! in_array( $tag, (array) ( $u['shortcode'] ?? array() ), true ) || '' === trim( (string) $wyjscie ) ) {
		return $wyjscie;
	}
	return mu_wyd_zgoda_owin( $wyjscie, $tag );
}, 20, 2 );
function mu_wyd_zgoda_ramki( $html ) {
	$u = mu_wyd_zgoda();
	if ( ! $u || is_admin() || empty( $u['iframe'] ) || false === stripos( $html, '<iframe' ) || false !== strpos( $html, 'mu-zgoda' ) ) {
		return $html;
	}
	return preg_replace_callback( '~<iframe\b[^>]*\bsrc="https?://(?:[a-z0-9-]+\.)*([a-z0-9-]+\.[a-z]{2,})/[^"]*"[^>]*>\s*</iframe>~i', function ( $m ) use ( $u ) {
		foreach ( (array) $u['iframe'] as $host ) {
			if ( false !== stripos( $m[0], '//' . $host ) || false !== stripos( $m[0], '.' . $host ) ) {
				return mu_wyd_zgoda_owin( $m[0], $host );
			}
		}
		return $m[0];
	}, $html );
}
add_filter( 'render_block', 'mu_wyd_zgoda_ramki', 25 );
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	$u = mu_wyd_zgoda();
	if ( ! $u || is_admin() ) {
		return $tag;
	}
	$h = (array) ( $u['skrypty'] ?? array() );
	if ( ! in_array( $handle, $h, true ) && ! in_array( $handle . '-js', $h, true ) ) {
		return $tag;
	}
	return preg_replace_callback( '~<script\b([^>]*)\bsrc=([\'"])([^\'"]+)\2([^>]*)>~', function ( $m ) use ( $u ) {
		$GLOBALS['mu_wyd_zgoda_uzyta'] = true;
		return '<script type="text/plain" data-mu-zgoda="' . esc_attr( $u['kategoria'] ?? 'functional' ) . '" data-src="' . esc_url( $m[3] ) . '">';
	}, $tag );
}, 30, 2 );
// Styl komunikatu w <head> (od 1.8.1 – <style> w treści to błąd W3C); 200 bajtów, gdy „po_zgodzie” jest ustawione.
add_action( 'wp_head', function () {
	if ( mu_wyd_zgoda() && ! is_admin() ) {
		echo '<style id="moveup-zgoda">.mu-zgoda__info{padding:32px 24px;border-radius:8px;background:var(--global-palette8,#f5f5f5);text-align:center}.mu-zgoda__tekst{margin:0 auto 16px;max-width:560px}</style>' . "\n";
	}
}, 20 );
add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['mu_wyd_zgoda_uzyta'] ) ) {
		return;
	}
	?>
<script id="moveup-zgoda-js">(function(){function z(k){try{var c=window.getCkyConsent&&window.getCkyConsent();return!!(c&&c.categories&&c.categories[k])}catch(e){return!1}}function o(){document.querySelectorAll('.mu-zgoda[data-kategoria]').forEach(function(b){if(!z(b.getAttribute('data-kategoria')))return;var t=b.querySelector('template'),f=document.createDocumentFragment();if(!t)return;f.appendChild(t.content.cloneNode(!0));f.querySelectorAll('script').forEach(function(s){var n=document.createElement('script');[].forEach.call(s.attributes,function(a){n.setAttribute(a.name,a.value)});n.text=s.text;s.replaceWith(n)});b.replaceWith(f)});document.querySelectorAll('script[data-mu-zgoda]').forEach(function(s){if(!z(s.getAttribute('data-mu-zgoda')))return;var n=document.createElement('script');n.src=s.getAttribute('data-src');n.async=!0;s.replaceWith(n)})}o();['cookieyes_consent_update','cookieyes_banner_load'].forEach(function(e){document.addEventListener(e,function(){setTimeout(o,0)})});window.addEventListener('load',o);document.addEventListener('click',function(e){if(e.target.closest&&e.target.closest('.mu-zgoda__ustawienia')&&window.revisitCkyConsent)window.revisitCkyConsent()})})();</script>
	<?php
}, 100 );

/*
 * Mapa Google z bloku Kadence (od 1.8.1): <iframe width="100%" height="100%"> to błąd W3C (atrybuty przyjmują tylko piksele).
 * Te same wymiary przenosimy do stylu – wygląd bez zmian.
 */
add_filter( 'render_block_kadence/googlemaps', function ( $html ) {
	return preg_replace_callback( '~<iframe\b[^>]*>~i', function ( $m ) {
		$t = $m[0];
		if ( ! preg_match( '~\swidth="100%"~', $t ) && ! preg_match( '~\sheight="100%"~', $t ) ) {
			return $t;
		}
		$t = preg_replace( '~\s(width|height)="100%"~', '', $t );
		if ( preg_match( '~\sstyle="([^"]*)"~', $t ) ) {
			return preg_replace( '~\sstyle="([^"]*)"~', ' style="$1;width:100%;height:100%"', $t, 1 );
		}
		return str_replace( '<iframe', '<iframe style="width:100%;height:100%"', $t );
	}, $html );
} );

/*
 * Ramki z obcych serwerów dopiero przy przewijaniu (od 1.8.2, ustawienia.json):
 *   "ramki_pozniej": ["pomagam.pl"],   // serwery ramek wczytywanych dopiero, gdy ramka zbliża się do ekranu
 *   "ramki_margines": 600              // opcjonalnie: ile px przed ekranem (domyślnie 600)
 * loading="lazy" nie wystarcza – Chrome na telefonie wczytuje takie ramki od razu (próg ok. 1250–2500 px), a z nimi
 * fonty, CSS i skrypty obcego serwisu. Tu adres trafia do data-mu-src, a mały skrypt (IntersectionObserver) wstawia go,
 * gdy ramka jest blisko ekranu. Bez JavaScriptu – oryginalna ramka w <noscript>. Ramki czekające na zgodę („po_zgodzie”) pomijamy.
 */
function mu_wyd_ramki_pozniej( $html ) {
	$hosty = (array) ( mu_wyd_ustawienia()['ramki_pozniej'] ?? array() );
	if ( ! $hosty || is_admin() || wp_doing_ajax() || defined( 'REST_REQUEST' ) || false === stripos( $html, '<iframe' ) || false !== strpos( $html, 'data-mu-src' ) || false !== strpos( $html, 'mu-zgoda' ) ) {
		return $html;
	}
	return preg_replace_callback( '~<iframe\b([^>]*?)\ssrc="(https?://[^"]+)"([^>]*)>\s*</iframe>~i', function ( $m ) use ( $hosty ) {
		$host = strtolower( (string) wp_parse_url( html_entity_decode( $m[2] ), PHP_URL_HOST ) );
		foreach ( $hosty as $h ) {
			$h = strtolower( $h );
			if ( $host === $h || substr( $host, -strlen( '.' . $h ) ) === '.' . $h ) {
				$GLOBALS['mu_wyd_ramki_pozniej'] = true;
				return '<iframe' . $m[1] . ' data-mu-src="' . $m[2] . '"' . $m[3] . '></iframe><noscript>' . $m[0] . '</noscript>';
			}
		}
		return $m[0];
	}, $html );
}
add_filter( 'render_block', 'mu_wyd_ramki_pozniej', 26 );
add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['mu_wyd_ramki_pozniej'] ) ) {
		return;
	}
	$margines = max( 0, (int) ( mu_wyd_ustawienia()['ramki_margines'] ?? 600 ) );
	?>
<script id="moveup-ramki-js">(function(){function w(f){f.src=f.getAttribute('data-mu-src');f.removeAttribute('data-mu-src')}var l=document.querySelectorAll('iframe[data-mu-src]');if(!('IntersectionObserver' in window)){l.forEach(w);return}var o=new IntersectionObserver(function(e){e.forEach(function(x){if(x.isIntersecting){o.unobserve(x.target);w(x.target)}})},{rootMargin:'<?php echo (int) $margines; ?>px 0px'});l.forEach(function(f){o.observe(f)})})();</script>
	<?php
}, 100 );
