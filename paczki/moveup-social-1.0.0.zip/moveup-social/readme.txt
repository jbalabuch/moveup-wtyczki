=== moveUP – Social ===
Contributors: moveUP Agency
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Ostatnie posty z Facebooka i Instagrama na stronie – z kanałów RSS (np. z n8n i Bright Data). Następczyni wtyczki „MONAR – Facebook” (strony MONAR zostają przy niej).

== Jak to działa ==

Ustawienia → Social:
– Źródła – kanał RSS jednego profilu: serwis (Facebook/Instagram), nazwa, adres kanału i profilu, zdjęcie profilu, tekst przycisku „Obserwuj”.
– Feedy – zestaw źródeł (kilka profili w jednym feedzie – posty razem, od najnowszego) i sposób wyświetlania. Na stronie: blok „Shortcode” z [moveup_social feed="…"].

Opcje feedu:
– układ: siatka, karuzela (strzałki, przewijanie automatyczne), lista; na telefonie i tablecie siatka albo pasek przewijany palcem,
– kolumny osobno na komputer, tablet i telefon, liczba postów, rzędy na start z przyciskiem „Wczytaj więcej postów”,
– proporcje zdjęć: 1:1, 4:5, 3:4 (siatka Instagrama), 16:9,
– szczegóły posta: pod zdjęciem, obok, na zdjęciu po najechaniu (i na fokus klawiatury) albo same zdjęcia,
– co pokazać: data, godzina, tekst (skrócony z „Czytaj więcej”, cały, bez), nazwa profilu, link „Zobacz post na …”,
– nagłówek H2 i podtytuł, profile ze zdjęciem nad postami, przyciski „Obserwuj” nad lub pod postami (na telefonie pod postami),
– kolory akcentu, przycisków i karty, krój przycisków, zaokrąglenie, odstępy.

Zdjęcia: webp do 720 px w wp-content/uploads/moveup-social/ – odwiedzający nie łączą się z Facebookiem ani Instagramem (bez zgody na cookies). Posty odświeżane co godzinę (WP-Cron – najlepiej cron systemowy), po zmianie postów czyszczony cache LiteSpeed; strona z cache starszym niż godzina dociąga posty przez REST (/wp-json/moveup-social/v1/feed).

Dostępność: zdjęcia z opisem dla czytników („Post na Instagramie: …, otwiera się w nowej karcie”), nakładka także na fokus klawiatury, „Wczytaj więcej” przenosi fokus na pierwszy nowy post, karuzela zatrzymuje się po najechaniu i fokusie, bez animacji przy „ogranicz ruch”.

== Changelog ==

= 1.0.0 =
Pierwsza wersja: wiele źródeł (Facebook, Instagram) w jednym feedzie, siatka/karuzela/lista, szczegóły pod/obok/na zdjęciu, wybór daty, godziny, tekstu i linku.
