/* moveUP – Social: rzędy i „Wczytaj więcej postów”, rozwijanie tekstu, karuzela bez końca, dociąganie świeżych postów z pominięciem cache strony. */
( function () {
	var MOBILNY = window.matchMedia( '(max-width: 1024px)' );

	function rozwijanie( sekcja ) {
		sekcja.querySelectorAll( '.mus__tekst--skrot' ).forEach( function ( tekst ) {
			var btn = tekst.parentNode.querySelector( '.mus__rozwin' );
			if ( ! btn || btn.dataset.gotowy ) {
				return;
			}
			btn.dataset.gotowy = '1';
			btn.hidden = tekst.scrollHeight <= tekst.clientHeight + 2;
			btn.addEventListener( 'click', function () {
				var otwarty = tekst.classList.toggle( 'is-rozwiniety' );
				btn.setAttribute( 'aria-expanded', otwarty ? 'true' : 'false' );
				btn.textContent = otwarty ? 'Zwiń' : 'Czytaj więcej';
			} );
		} );
	}

	/* Siatka: tyle rzędów, ile w ustawieniach; przycisk dokłada kolejny rząd i przenosi fokus na pierwszy nowy post. */
	function rzedy( sekcja ) {
		var lista = sekcja.querySelector( '.mus__lista' );
		var btn = sekcja.querySelector( '.mus__wiecej' );
		var start = parseInt( sekcja.getAttribute( 'data-wiersze' ), 10 ) || 0;
		var ile = start;
		function kolumny() {
			return getComputedStyle( lista ).gridTemplateColumns.split( ' ' ).filter( Boolean ).length || 1;
		}
		function pokaz( fokus ) {
			var posty = lista.querySelectorAll( '.mus__post' );
			var pasek = sekcja.classList.contains( 'mus--pasek' ) && MOBILNY.matches;
			var limit = ( ! start || pasek ) ? posty.length : kolumny() * ile;
			var nowy = null;
			posty.forEach( function ( p, i ) {
				var ukryj = i >= limit;
				if ( p.hidden && ! ukryj && ! nowy ) {
					nowy = p;
				}
				p.hidden = ukryj;
			} );
			if ( btn ) {
				btn.hidden = limit >= posty.length;
			}
			if ( fokus && nowy ) {
				var a = nowy.querySelector( 'a:not([tabindex="-1"])' );
				if ( a ) {
					a.focus();
				}
			}
		}
		if ( btn ) {
			btn.addEventListener( 'click', function () {
				ile++;
				pokaz( true );
			} );
		}
		window.addEventListener( 'resize', function () { pokaz( false ); } );
		pokaz( false );
		return function () { pokaz( false ); };
	}

	/* Karuzela: po ostatnim poście płynnie wraca pierwszy. */
	function karuzela( sekcja ) {
		var box = sekcja.querySelector( '.mus__karuzela' );
		var tor = sekcja.querySelector( '.mus__lista' );
		var prev = sekcja.querySelector( '.mus__strzalka--prev' );
		var next = sekcja.querySelector( '.mus__strzalka--next' );
		if ( ! box || ! prev || ! next ) {
			return function () {};
		}
		function krok() {
			var post = tor.querySelector( '.mus__post' );
			return post ? post.getBoundingClientRect().width + ( parseFloat( getComputedStyle( tor ).columnGap ) || 0 ) : tor.clientWidth;
		}
		function natychmiast( fn ) {
			tor.style.scrollBehavior = 'auto';
			tor.style.scrollSnapType = 'none';
			fn();
			void tor.offsetHeight;
			tor.style.scrollBehavior = '';
			tor.style.scrollSnapType = '';
		}
		function dalej() {
			if ( tor.scrollLeft + tor.clientWidth >= tor.scrollWidth - 2 ) {
				natychmiast( function () {
					tor.appendChild( tor.firstElementChild );
					tor.scrollLeft -= krok();
				} );
			}
			tor.scrollBy( { left: krok(), behavior: 'smooth' } );
		}
		function wstecz() {
			if ( tor.scrollLeft <= 2 ) {
				natychmiast( function () {
					tor.insertBefore( tor.lastElementChild, tor.firstElementChild );
					tor.scrollLeft += krok();
				} );
			}
			tor.scrollBy( { left: -krok(), behavior: 'smooth' } );
		}
		function odswiez() {
			box.classList.toggle( 'is-przewijana', tor.scrollWidth > tor.clientWidth + 2 );
			var zdj = tor.querySelector( '.mus__zdjecie' );
			if ( zdj ) {
				var top = Math.round( zdj.getBoundingClientRect().height / 2 - prev.offsetHeight / 2 ) + 'px';
				prev.style.top = top;
				next.style.top = top;
			}
		}
		prev.addEventListener( 'click', wstecz );
		next.addEventListener( 'click', dalej );
		window.addEventListener( 'resize', odswiez );
		odswiez();

		var co = parseInt( sekcja.getAttribute( 'data-autoplay' ), 10 ) || 0;
		if ( co && ! window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			var pauza = false;
			var timer = null;
			var uruchom = function () {
				clearInterval( timer );
				timer = setInterval( function () {
					if ( ! pauza && ! document.hidden && box.classList.contains( 'is-przewijana' ) ) {
						dalej();
					}
				}, co );
			};
			[ [ 'mouseenter', true ], [ 'mouseleave', false ], [ 'focusin', true ], [ 'focusout', false ] ].forEach( function ( z ) {
				box.addEventListener( z[ 0 ], function () { pauza = z[ 1 ]; if ( ! z[ 1 ] ) { uruchom(); } } );
			} );
			tor.addEventListener( 'touchstart', function () { pauza = true; }, { passive: true } );
			tor.addEventListener( 'touchend', function () { pauza = false; uruchom(); }, { passive: true } );
			uruchom();
		}
		return function () {
			natychmiast( function () { tor.scrollLeft = 0; } );
			odswiez();
		};
	}

	function start() {
		document.querySelectorAll( '.mus' ).forEach( function ( sekcja ) {
			if ( sekcja.classList.contains( 'is-js' ) ) {
				return;
			}
			sekcja.classList.add( 'is-js' );
			var poRzedach = rzedy( sekcja );
			var poKaruzeli = karuzela( sekcja );
			rozwijanie( sekcja );
			// Serwer pytamy tylko, gdy strona z cache ma posty starsze niż godzina – inaczej każde wejście to niecache'owane zapytanie do PHP.
			var api = sekcja.getAttribute( 'data-api' );
			var czas = parseInt( sekcja.getAttribute( 'data-czas' ), 10 ) || 0;
			if ( ! api || ! window.fetch || Date.now() / 1000 - czas < 3600 ) {
				return;
			}
			fetch( api, { credentials: 'same-origin', cache: 'no-store' } )
				.then( function ( r ) { return r.ok ? r.json() : null; } )
				.then( function ( d ) {
					if ( d && d.html && d.czas > czas ) {
						sekcja.querySelector( '.mus__lista' ).innerHTML = d.html;
						sekcja.setAttribute( 'data-czas', d.czas );
						poRzedach();
						poKaruzeli();
						rozwijanie( sekcja );
					}
				} )
				.catch( function () {} );
		} );
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
} )();
