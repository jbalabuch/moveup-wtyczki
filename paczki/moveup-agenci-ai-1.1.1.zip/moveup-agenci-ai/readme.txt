=== moveUP – Agenci AI ===
Contributors: moveUP Agency
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.1.1
License: GPLv2 or later

Strona czytelna dla asystentów AI (ChatGPT, Claude, Perplexity, Gemini). Zwykłe strony dla odwiedzających bez zmian.

== Funkcje ==

– Wersja Markdown każdej strony: odpowiedź text/markdown na nagłówek „Accept: text/markdown” (Markdown for Agents) albo ?format=markdown; tytuł, opis z Rank Math, adres źródłowy i treść bez menu, skryptów i ikon. Bez cache LiteSpeed, nagłówek Vary: Accept, X-Markdown-Tokens. W <head> stron: <link rel="alternate" type="text/markdown">.
– /llms.txt: nazwa i opis serwisu, strony w kolejności menu z opisami z Rank Math (tylko indeksowane; noindex w sekcji „Optional”).
– robots.txt (filtr WordPressa, działa z Rank Math): Content-Signal (search, ai-input, ai-train – ustawiane w panelu) i jawna grupa dla botów AI (GPTBot, ClaudeBot, PerplexityBot, Google-Extended i in.) z blokadą /wp-admin/.

Serwer LiteSpeed: przy włączeniu wtyczki i zapisie ustawień wstawia na początku .htaccess blok „moveUP Agenci AI” (zapytania z Accept: text/markdown omijają cache stron); usuwa go przy wyłączeniu wtyczki.

Ustawienia → Agenci AI. Domyślnie: search=yes, ai-input=yes, ai-train=no.

== Aktualizacje ==

Od wersji 1.1.0 wtyczka sama sprawdza nowe wersje w https://github.com/jbalabuch/moveup-wtyczki (plik wtyczki.json) – aktualizacja pojawia się w Kokpit → Aktualizacje, można włączyć automatyczne aktualizacje. Nagłówek „Update URI” sprawia, że WordPress nie myli wtyczki z wtyczką o tej samej nazwie na wordpress.org.
