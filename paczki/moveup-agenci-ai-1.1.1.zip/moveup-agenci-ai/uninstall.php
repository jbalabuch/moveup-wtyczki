<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
delete_option( 'mu_agenci_ai' );
