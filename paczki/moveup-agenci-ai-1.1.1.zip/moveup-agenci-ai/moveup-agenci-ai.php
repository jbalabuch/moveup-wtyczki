<?php
/**
 * Plugin Name: moveUP – Agenci AI
 * Description: Strona czytelna dla asystentów AI: wersja Markdown każdej strony (nagłówek Accept: text/markdown albo ?format=markdown), plik /llms.txt z mapą strony, reguły dla botów AI i Content-Signal w robots.txt. Nic nie dokłada do zwykłych stron poza jednym znacznikiem <link>.
 * Version: 1.1.1
 * Author: moveUP Agency
 * Text Domain: moveup-agenci-ai
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-agenci-ai' );

define( 'MU_AI_VER', '1.1.1' );
define( 'MU_AI_OPCJA', 'mu_agenci_ai' );

/** Boty AI, które dostają jawne reguły w robots.txt (wyszukiwanie, odpowiedzi, uczenie). */
function mu_ai_boty() {
	return array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'Claude-User', 'PerplexityBot', 'Perplexity-User', 'Google-Extended', 'Applebot-Extended', 'Amazonbot', 'meta-externalagent', 'CCBot' );
}

function mu_ai_opcje() {
	$o = get_option( MU_AI_OPCJA, array() );
	return wp_parse_args( is_array( $o ) ? $o : array(), array(
		'markdown' => 1,
		'llms'     => 1,
		'boty'     => 1,
		'search'   => 'yes',
		'ai_input' => 'yes',
		'ai_train' => 'no',
		'opis'     => '',
	) );
}

/* -------------------------------------------------------------------------
 * HTML → Markdown (DOMDocument, bez zależności)
 * ---------------------------------------------------------------------- */
function mu_ai_html_na_md( $html ) {
	if ( '' === trim( $html ) ) {
		return '';
	}
	$dom = new DOMDocument();
	libxml_use_internal_errors( true );
	$dom->loadHTML( '<?xml encoding="utf-8"?><div id="mu-ai-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	$root = $dom->getElementById( 'mu-ai-root' );
	$md   = $root ? mu_ai_wezel( $root, 0 ) : '';
	$md   = preg_replace( "/[ \t]+\n/", "\n", $md );
	$md   = preg_replace( "/\n{3,}/", "\n\n", $md );
	return trim( $md ) . "\n";
}

function mu_ai_wezel( $n, $lista ) {
	if ( XML_TEXT_NODE === $n->nodeType ) {
		return preg_replace( '/\s+/u', ' ', $n->nodeValue );
	}
	if ( XML_ELEMENT_NODE !== $n->nodeType ) {
		return '';
	}
	$tag   = strtolower( $n->nodeName );
	$klasa = (string) $n->getAttribute( 'class' );
	// pomijamy: skrypty, style, ikony SVG, formularze, elementy ukryte przed wszystkimi
	if ( in_array( $tag, array( 'script', 'style', 'noscript', 'svg', 'template', 'form', 'button', 'nav', 'iframe' ), true )
		|| $n->hasAttribute( 'hidden' ) || 'true' === $n->getAttribute( 'aria-hidden' ) ) {
		if ( 'iframe' === $tag && $n->getAttribute( 'title' ) ) {
			return "\n\n" . $n->getAttribute( 'title' ) . "\n\n";
		}
		return '';
	}
	$w = '';
	foreach ( $n->childNodes as $c ) {
		$w .= mu_ai_wezel( $c, in_array( $tag, array( 'ul', 'ol' ), true ) ? $lista + 1 : $lista );
	}
	$t = trim( $w );
	switch ( $tag ) {
		case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6':
			return '' === $t ? '' : "\n\n" . str_repeat( '#', (int) $tag[1] ) . ' ' . $t . "\n\n";
		case 'p':
			return '' === $t ? '' : "\n\n" . $t . "\n\n";
		case 'br':
			return "  \n";
		case 'strong': case 'b':
			return '' === $t ? '' : '**' . $t . '**';
		case 'em': case 'i':
			return '' === $t || false !== strpos( $klasa, 'icon' ) ? '' : '*' . $t . '*';
		case 'a':
			$href = $n->getAttribute( 'href' );
			if ( '' === $t ) {
				$t = trim( (string) $n->getAttribute( 'aria-label' ) );
			}
			if ( '' === $t || '' === $href || 0 === strpos( $href, '#' ) ) {
				return $t;
			}
			return '[' . $t . '](' . esc_url_raw( mu_ai_pelny_url( $href ) ) . ')';
		case 'img':
			$alt = trim( (string) $n->getAttribute( 'alt' ) );
			return '' === $alt ? '' : '![' . $alt . '](' . esc_url_raw( mu_ai_pelny_url( $n->getAttribute( 'src' ) ) ) . ')';
		case 'li':
			return "\n" . str_repeat( '  ', max( 0, $lista - 1 ) ) . '- ' . $t;
		case 'ul': case 'ol':
			return "\n" . $w . "\n\n";
		case 'blockquote':
			return "\n\n> " . str_replace( "\n", "\n> ", $t ) . "\n\n";
		case 'hr':
			return "\n\n---\n\n";
		case 'div': case 'section': case 'article': case 'figure': case 'header': case 'main': case 'aside': case 'details': case 'summary': case 'figcaption': case 'dl': case 'dt': case 'dd': case 'tr':
			return "\n" . $w . "\n";
		case 'td': case 'th':
			return ' ' . $t . ' |';
		default:
			return $w;
	}
}

function mu_ai_pelny_url( $u ) {
	return ( 0 === strpos( $u, '/' ) && 0 !== strpos( $u, '//' ) ) ? home_url( $u ) : $u;
}

/** Tytuł jako czysty tekst (bez &nbsp; i innych encji z filtrów typografii). */
function mu_ai_tytul( $id ) {
	return trim( html_entity_decode( wp_strip_all_tags( get_the_title( $id ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
}

/* -------------------------------------------------------------------------
 * Wersja Markdown strony
 * ---------------------------------------------------------------------- */
function mu_ai_chce_markdown() {
	if ( isset( $_GET['format'] ) && in_array( $_GET['format'], array( 'markdown', 'md' ), true ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return true;
	}
	$accept = isset( $_SERVER['HTTP_ACCEPT'] ) ? strtolower( (string) $_SERVER['HTTP_ACCEPT'] ) : '';
	$md     = strpos( $accept, 'text/markdown' );
	if ( false === $md ) {
		return false;
	}
	$html = strpos( $accept, 'text/html' );
	return false === $html || $md < $html; // przeglądarka zawsze stawia text/html pierwsze
}

function mu_ai_url_md( $url ) {
	return add_query_arg( 'format', 'markdown', $url );
}

function mu_ai_opis_strony( $id ) {
	$d = get_post_meta( $id, 'rank_math_description', true );
	if ( ! $d ) {
		$d = get_post_meta( $id, '_yoast_wpseo_metadesc', true );
	}
	return $d ? wp_strip_all_tags( $d ) : '';
}

function mu_ai_indeksowana( $id ) {
	$r = get_post_meta( $id, 'rank_math_robots', true );
	return ! ( is_array( $r ) && in_array( 'noindex', $r, true ) ) && 'publish' === get_post_status( $id ) && ! post_password_required( $id );
}

add_action( 'template_redirect', function () {
	$o = mu_ai_opcje();
	if ( ! $o['markdown'] || ! is_singular() || ! mu_ai_chce_markdown() ) {
		return;
	}
	$post = get_queried_object();
	if ( ! $post || post_password_required( $post ) ) {
		return;
	}
	do_action( 'litespeed_control_set_nocache', 'moveup-agenci-ai: markdown' ); // wersja Markdown nie trafia do cache stron
	setup_postdata( $post );
	$tresc = apply_filters( 'the_content', $post->post_content );
	wp_reset_postdata();

	$tytul = mu_ai_tytul( $post->ID );
	$opis  = mu_ai_opis_strony( $post->ID );
	$md    = '# ' . $tytul . "\n\n";
	if ( $opis ) {
		$md .= '> ' . $opis . "\n\n";
	}
	$md .= 'Źródło: ' . get_permalink( $post ) . "\n\n";
	$md .= mu_ai_html_na_md( $tresc );

	nocache_headers();
	status_header( 200 );
	header( 'Content-Type: text/markdown; charset=utf-8' );
	header( 'Vary: Accept' );
	header( 'X-Markdown-Tokens: ' . (int) ceil( mb_strlen( $md ) / 4 ) );
	header( 'Link: <' . esc_url_raw( get_permalink( $post ) ) . '>; rel="canonical"' );
	if ( ! mu_ai_indeksowana( $post->ID ) ) {
		header( 'X-Robots-Tag: noindex' );
	}
	echo $md; // phpcs:ignore WordPress.Security.EscapeOutput -- tekst, nie HTML
	exit;
}, 1 );

// Wskazanie wersji Markdown: w <head> i Vary w nagłówku HTTP
add_action( 'wp_head', function () {
	if ( mu_ai_opcje()['markdown'] && is_singular() ) {
		echo '<link rel="alternate" type="text/markdown" href="' . esc_url( mu_ai_url_md( get_permalink() ) ) . '">' . "\n";
	}
}, 2 );
add_action( 'send_headers', function () {
	if ( mu_ai_opcje()['markdown'] && ! is_admin() ) {
		header( 'Vary: Accept', false );
	}
} );

/* -------------------------------------------------------------------------
 * /llms.txt
 * ---------------------------------------------------------------------- */
function mu_ai_llms() {
	$o     = mu_ai_opcje();
	$nazwa = get_bloginfo( 'name' );
	$opis  = $o['opis'] ? $o['opis'] : ( mu_ai_opis_strony( (int) get_option( 'page_on_front' ) ) ?: get_bloginfo( 'description' ) );
	$out   = '# ' . $nazwa . "\n\n> " . $opis . "\n\n";

	// kolejność jak w menu głównym, potem pozostałe strony
	$ids  = array();
	$lok  = get_nav_menu_locations();
	$menu = ! empty( $lok['primary'] ) ? wp_get_nav_menu_items( $lok['primary'] ) : array();
	foreach ( (array) $menu as $p ) {
		if ( 'page' === $p->object ) {
			$ids[] = (int) $p->object_id;
		}
	}
	$front = (int) get_option( 'page_on_front' );
	if ( $front ) {
		array_unshift( $ids, $front );
	}
	foreach ( get_pages( array( 'sort_column' => 'menu_order,post_title' ) ) as $p ) {
		$ids[] = $p->ID;
	}
	$ids = array_values( array_unique( $ids ) );

	$out .= "## Strony\n\n";
	foreach ( $ids as $id ) {
		if ( ! mu_ai_indeksowana( $id ) ) {
			continue;
		}
		$t    = mu_ai_tytul( $id );
		$d    = mu_ai_opis_strony( $id );
		$link = $o['markdown'] ? mu_ai_url_md( get_permalink( $id ) ) : get_permalink( $id );
		$out .= '- [' . $t . '](' . $link . ')' . ( $d ? ': ' . $d : '' ) . "\n";
	}
	$inne = array();
	foreach ( get_pages() as $p ) {
		if ( ! mu_ai_indeksowana( $p->ID ) && 'publish' === $p->post_status ) {
			$inne[] = '- [' . mu_ai_tytul( $p->ID ) . '](' . get_permalink( $p ) . ')';
		}
	}
	if ( $inne ) {
		$out .= "\n## Optional\n\n" . implode( "\n", $inne ) . "\n";
	}
	return $out;
}

add_action( 'parse_request', function () {
	if ( ! mu_ai_opcje()['llms'] ) {
		return;
	}
	$sciezka = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH );
	$baza    = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $baza . '/llms.txt' !== $sciezka || file_exists( ABSPATH . 'llms.txt' ) ) {
		return;
	}
	do_action( 'litespeed_control_set_ttl', 3600 );
	status_header( 200 );
	header( 'Content-Type: text/markdown; charset=utf-8' );
	header( 'X-Robots-Tag: noindex' );
	echo mu_ai_llms(); // phpcs:ignore WordPress.Security.EscapeOutput
	exit;
}, 0 );

/* -------------------------------------------------------------------------
 * robots.txt: Content-Signal + jawne reguły dla botów AI
 * ---------------------------------------------------------------------- */
add_filter( 'robots_txt', function ( $txt, $publiczna ) {
	$o = mu_ai_opcje();
	if ( ! $publiczna || ! $o['boty'] ) {
		return $txt;
	}
	$sygnal = 'Content-Signal: search=' . $o['search'] . ', ai-input=' . $o['ai_input'] . ', ai-train=' . $o['ai_train'];
	// Content-Signal w grupie „User-agent: *”
	if ( false === stripos( $txt, 'Content-Signal:' ) ) {
		$txt = preg_replace( '/^(User-agent:\s*\*\s*)$/mi', "$1\n" . $sygnal, $txt, 1, $ile );
		if ( ! $ile ) {
			$txt = "User-agent: *\n" . $sygnal . "\n\n" . $txt;
		}
	}
	// Osobna grupa dla botów AI powtarza blokadę kokpitu (konkretna grupa zastępuje „*”).
	$blok = "\n# Asystenci i wyszukiwarki AI (moveUP – Agenci AI)\n";
	foreach ( mu_ai_boty() as $b ) {
		$blok .= 'User-agent: ' . $b . "\n";
	}
	$zgoda = ( 'yes' === $o['ai_input'] || 'yes' === $o['search'] );
	$blok .= $sygnal . "\n" . ( $zgoda ? "Allow: /\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\n" : "Disallow: /\n" );
	// Sitemap zostaje na końcu pliku
	if ( preg_match( '/^Sitemap:.*$/mi', $txt ) ) {
		$txt = preg_replace( '/^(Sitemap:.*)$/mi', trim( $blok ) . "\n\n$1", $txt, 1 );
	} else {
		$txt .= $blok;
	}
	if ( $o['llms'] && false === stripos( $txt, 'llms.txt' ) ) {
		$txt .= "\n# Mapa strony dla modeli językowych: " . home_url( '/llms.txt' ) . "\n";
	}
	return $txt;
}, 99, 2 );

/* -------------------------------------------------------------------------
 * LiteSpeed: zapytania o Markdown z pominięciem cache stron (cache LSWS nie rozróżnia nagłówka Accept)
 * ---------------------------------------------------------------------- */
function mu_ai_litespeed() {
	return isset( $_SERVER['SERVER_SOFTWARE'] ) && false !== stripos( (string) $_SERVER['SERVER_SOFTWARE'], 'litespeed' );
}

function mu_ai_htaccess( $wlacz ) {
	if ( ! mu_ai_litespeed() ) {
		return null;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$plik = get_home_path() . '.htaccess';
	if ( ! is_writable( $plik ) ) {
		return false;
	}
	// Blok musi stać NA POCZĄTKU pliku: reguła WordPressa „RewriteRule . /index.php [L]” kończy
	// przetwarzanie, więc reguła na końcu działałaby tylko dla strony głównej.
	$tresc = (string) file_get_contents( $plik );
	$tresc = preg_replace( '/# BEGIN moveUP Agenci AI.*?# END moveUP Agenci AI\R*/s', '', $tresc );
	if ( $wlacz ) {
		$blok  = "# BEGIN moveUP Agenci AI\n"
			. "# Zapytania o Markdown (Accept: text/markdown) omijają cache LiteSpeed. Blok zarządzany przez wtyczkę moveUP – Agenci AI.\n"
			. "<IfModule LiteSpeed>\n"
			. "RewriteEngine On\n"
			. "RewriteCond %{HTTP_ACCEPT} text/markdown [NC]\n"
			. "RewriteRule .* - [E=Cache-Control:no-cache]\n"
			. "</IfModule>\n"
			. "# END moveUP Agenci AI\n\n";
		$tresc = $blok . $tresc;
	}
	return false !== file_put_contents( $plik, $tresc, LOCK_EX );
}

function mu_ai_htaccess_jest() {
	if ( ! function_exists( 'get_home_path' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	$plik = get_home_path() . '.htaccess';
	// reguła działa tylko na początku pliku (przed blokiem WordPressa)
	$c = is_readable( $plik ) ? (string) file_get_contents( $plik ) : '';
	$i = strpos( $c, '# BEGIN moveUP Agenci AI' );
	$w = strpos( $c, '# BEGIN WordPress' );
	return false !== $i && ( false === $w || $i < $w );
}

register_activation_hook( __FILE__, function () {
	mu_ai_htaccess( (bool) mu_ai_opcje()['markdown'] );
} );
register_deactivation_hook( __FILE__, function () {
	mu_ai_htaccess( false );
} );
// Przy każdym „Zapisz zmiany” – także gdy ustawienia się nie zmieniły (wtedy update_option_* nie działa).
add_filter( 'pre_update_option_' . MU_AI_OPCJA, function ( $nowe ) {
	mu_ai_htaccess( ! empty( $nowe['markdown'] ) );
	return $nowe;
} );

/* -------------------------------------------------------------------------
 * Ustawienia → Agenci AI
 * ---------------------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_options_page( 'Agenci AI', 'Agenci AI', 'manage_options', 'moveup-agenci-ai', 'mu_ai_ustawienia' );
} );
add_action( 'admin_init', function () {
	register_setting( 'moveup-agenci-ai', MU_AI_OPCJA, array( 'type' => 'array', 'sanitize_callback' => function ( $v ) {
		$v  = is_array( $v ) ? $v : array();
		$yn = function ( $k ) use ( $v ) { return ( isset( $v[ $k ] ) && 'yes' === $v[ $k ] ) ? 'yes' : 'no'; };
		return array(
			'markdown' => empty( $v['markdown'] ) ? 0 : 1,
			'llms'     => empty( $v['llms'] ) ? 0 : 1,
			'boty'     => empty( $v['boty'] ) ? 0 : 1,
			'search'   => $yn( 'search' ),
			'ai_input' => $yn( 'ai_input' ),
			'ai_train' => $yn( 'ai_train' ),
			'opis'     => isset( $v['opis'] ) ? sanitize_textarea_field( $v['opis'] ) : '',
		);
	} ) );
} );

function mu_ai_ustawienia() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o = mu_ai_opcje();
	$n = MU_AI_OPCJA;
	$tak_nie = function ( $k, $etykieta, $opis ) use ( $o, $n ) {
		printf( '<p><label><select name="%1$s[%2$s]"><option value="yes" %3$s>yes</option><option value="no" %4$s>no</option></select> <strong>%5$s</strong></label> – %6$s</p>',
			esc_attr( $n ), esc_attr( $k ), selected( $o[ $k ], 'yes', false ), selected( $o[ $k ], 'no', false ), esc_html( $etykieta ), esc_html( $opis ) );
	};
	?>
	<div class="wrap">
		<h1>Agenci AI</h1>
		<p>Ułatwia asystentom AI (ChatGPT, Claude, Perplexity, Gemini) poprawne odczytanie strony. Zwykłe strony dla odwiedzających się nie zmieniają.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'moveup-agenci-ai' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row">Wersja Markdown</th><td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[markdown]" value="1" <?php checked( $o['markdown'] ); ?>> Czysty tekst strony dla agentów (nagłówek <code>Accept: text/markdown</code> albo <code>?format=markdown</code>)</label>
					<?php if ( mu_ai_litespeed() ) : ?>
					<p class="description"><?php echo mu_ai_htaccess_jest() ? 'Serwer LiteSpeed: reguła w .htaccess jest – zapytania o Markdown omijają cache stron.' : '<strong>Serwer LiteSpeed: brak reguły w .htaccess</strong> – kliknij „Zapisz zmiany”, żeby ją dodać (bez niej cache podaje agentom HTML zamiast Markdown).'; // phpcs:ignore ?></p>
					<?php endif; ?></td></tr>
				<tr><th scope="row">llms.txt</th><td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[llms]" value="1" <?php checked( $o['llms'] ); ?>> <a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank">/llms.txt</a> – mapa strony dla modeli językowych (strony z wyszukiwarki, z opisami z Rank Math)</label>
					<p><label for="mu-ai-opis">Opis serwisu w llms.txt (puste = opis strony głównej z Rank Math)</label><br><textarea id="mu-ai-opis" class="large-text" rows="2" name="<?php echo esc_attr( $n ); ?>[opis]"><?php echo esc_textarea( $o['opis'] ); ?></textarea></p></td></tr>
				<tr><th scope="row">robots.txt</th><td>
					<label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[boty]" value="1" <?php checked( $o['boty'] ); ?>> Jawne reguły dla botów AI i deklaracja Content-Signal</label>
					<?php
					$tak_nie( 'search', 'search', 'indeksowanie w wyszukiwarkach' );
					$tak_nie( 'ai_input', 'ai-input', 'cytowanie strony w odpowiedziach asystentów AI' );
					$tak_nie( 'ai_train', 'ai-train', 'użycie treści do uczenia modeli' );
					?>
					<p class="description"><a href="<?php echo esc_url( home_url( '/robots.txt' ) ); ?>" target="_blank">Podgląd robots.txt</a> · <a href="https://contentsignals.org/" target="_blank" rel="noopener">contentsignals.org</a></p>
				</td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $l ) {
	array_unshift( $l, '<a href="' . esc_url( admin_url( 'options-general.php?page=moveup-agenci-ai' ) ) . '">Ustawienia</a>' );
	return $l;
} );
