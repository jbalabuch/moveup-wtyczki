( function ( $ ) {
	'use strict';

	$( function () {
		var t = window.jadlospisyAdmin || {};
		var $id = $( '#jadlospis_pdf' );
		var $name = $( '#jadlospis_pdf_nazwa' );
		var $remove = $( '#jadlospis_pdf_usun' );
		var $od = $( '#jadlospis_od' );
		var $do = $( '#jadlospis_do' );
		var frame;

		if ( ! $id.length ) {
			return;
		}

		function toggleRemove() {
			$remove.toggle( !! $id.val() );
		}

		$( '#jadlospis_pdf_wybierz' ).on( 'click', function ( e ) {
			e.preventDefault();

			if ( ! frame ) {
				frame = wp.media( {
					title: t.frameTitle,
					button: { text: t.frameButton },
					library: { type: 'application/pdf' },
					multiple: false
				} );

				frame.on( 'select', function () {
					var file = frame.state().get( 'selection' ).first().toJSON();

					if ( file.mime !== 'application/pdf' ) {
						window.alert( t.notPdf );
						return;
					}

					$id.val( file.id );
					$name.empty().append(
						$( '<a>', { href: file.url, target: '_blank', rel: 'noopener', text: file.filename } )
					);
					toggleRemove();
				} );
			}

			frame.open();
		} );

		$remove.on( 'click', function ( e ) {
			e.preventDefault();
			$id.val( '' );
			$name.empty().append( $( '<em>' ).text( t.noFile ) );
			toggleRemove();
		} );

		function pad( n ) {
			return ( n < 10 ? '0' : '' ) + n;
		}

		// Po wybraniu daty początkowej podpowiadamy końcową (domyślnie tydzień).
		$od.on( 'change', function () {
			var od = $od.val();
			var days = parseInt( t.defaultDays, 10 ) || 7;
			var d;

			$do.attr( 'min', od );

			if ( od && ( ! $do.val() || $do.val() < od ) ) {
				d = new Date( od + 'T12:00:00' );
				d.setDate( d.getDate() + days - 1 );
				$do.val( d.getFullYear() + '-' + pad( d.getMonth() + 1 ) + '-' + pad( d.getDate() ) );
			}
		} );

		toggleRemove();
	} );
} )( jQuery );
