( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var c = wp.components;
	var ServerSideRender = wp.serverSideRender;
	var d = ( window.jadlospisyBlock && window.jadlospisyBlock.defaults ) || {};

	wp.blocks.registerBlockType( 'jadlospisy/jadlospisy', {
		apiVersion: 2,
		title: 'Jadłospisy',
		description: 'Aktualny jadłospis i archiwum jadłospisów w PDF.',
		category: 'widgets',
		icon: 'food',
		keywords: [ 'jadłospis', 'menu', 'pdf', 'posiłki' ],
		supports: { align: [ 'wide', 'full' ], html: false },
		attributes: {
			widok: { type: 'string', default: d.widok || 'wszystko' },
			podglad: { type: 'boolean', default: true },
			naglowek: { type: 'string', default: d.naglowek || 'h2' },
			tytulAktualny: { type: 'string', default: d.tytul_aktualny || 'Aktualny jadłospis' },
			tytulArchiwum: { type: 'string', default: d.tytul_archiwum || 'Archiwum jadłospisów' },
			limitArchiwum: { type: 'number', default: 0 },
			nadchodzace: { type: 'boolean', default: true }
		},

		edit: function ( props ) {
			var a = props.attributes;
			var set = function ( key ) {
				return function ( value ) {
					var obj = {};
					obj[ key ] = value;
					props.setAttributes( obj );
				};
			};

			var showCurrent = a.widok !== 'archiwum';
			var showArchive = a.widok !== 'aktualny';

			return el(
				'div',
				useBlockProps(),
				el(
					InspectorControls,
					null,
					el(
						c.PanelBody,
						{ title: 'Ustawienia', initialOpen: true },
						el( c.SelectControl, {
							label: 'Co wyświetlić',
							value: a.widok,
							options: [
								{ label: 'Aktualny jadłospis i archiwum', value: 'wszystko' },
								{ label: 'Tylko aktualny jadłospis', value: 'aktualny' },
								{ label: 'Tylko archiwum', value: 'archiwum' }
							],
							onChange: set( 'widok' )
						} ),
						el( c.SelectControl, {
							label: 'Poziom nagłówków',
							help: 'Dopasuj do sekcji, w której osadzasz blok.',
							value: a.naglowek,
							options: [
								{ label: 'H2', value: 'h2' },
								{ label: 'H3', value: 'h3' },
								{ label: 'H4', value: 'h4' }
							],
							onChange: set( 'naglowek' )
						} )
					),
					showCurrent &&
						el(
							c.PanelBody,
							{ title: 'Aktualny jadłospis', initialOpen: false },
							el( c.TextControl, {
								label: 'Nagłówek',
								help: 'Zostaw puste, żeby ukryć nagłówek.',
								value: a.tytulAktualny,
								onChange: set( 'tytulAktualny' )
							} ),
							el( c.ToggleControl, {
								label: 'Podgląd PDF na stronie',
								help: 'Na telefonach podgląd jest ukryty – zostają przyciski.',
								checked: a.podglad,
								onChange: set( 'podglad' )
							} )
						),
					showArchive &&
						el(
							c.PanelBody,
							{ title: 'Archiwum', initialOpen: false },
							el( c.TextControl, {
								label: 'Nagłówek',
								help: 'Zostaw puste, żeby ukryć nagłówek.',
								value: a.tytulArchiwum,
								onChange: set( 'tytulArchiwum' )
							} ),
							el( c.RangeControl, {
								label: 'Ile pozycji pokazać od razu',
								help: '0 = wszystkie. Pozostałe schowają się pod „Pokaż starsze”.',
								value: a.limitArchiwum,
								min: 0,
								max: 50,
								onChange: function ( value ) {
									props.setAttributes( { limitArchiwum: parseInt( value, 10 ) || 0 } );
								}
							} ),
							el( c.ToggleControl, {
								label: 'Pokazuj nadchodzące jadłospisy',
								help: 'Jadłospisy, które jeszcze nie obowiązują, z etykietą „nadchodzący”.',
								checked: a.nadchodzace,
								onChange: set( 'nadchodzace' )
							} )
						)
				),
				el( ServerSideRender, {
					block: 'jadlospisy/jadlospisy',
					attributes: a
				} )
			);
		},

		save: function () {
			return null;
		}
	} );
} )( window.wp );
