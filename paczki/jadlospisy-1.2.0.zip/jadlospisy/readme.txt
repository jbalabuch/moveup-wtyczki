=== Jadłospisy ===
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later

Jadłospisy w PDF z zakresem dat. Pokazuje aktualny jadłospis i archiwum – jako blok, widżet albo shortcode.

== Instalacja ==

1. Wtyczki → Dodaj nową → Wyślij wtyczkę na serwer → wybierz plik jadlospisy.zip.
2. Włącz wtyczkę. W menu pojawi się pozycja „Jadłospisy”.

== Dodawanie jadłospisu ==

1. Jadłospisy → Dodaj jadłospis.
2. „Wybierz lub wgraj PDF” – wgraj nowy plik albo wybierz z Biblioteki mediów.
3. Ustaw daty „Obowiązuje od” i „Obowiązuje do” (po wybraniu pierwszej daty druga podpowie się sama – tydzień później).
4. Tytuł możesz pominąć – powstanie z dat, np. „Jadłospis 14 września – 20 września 2026”.
   Wpisany ręcznie tytuł (np. „Jadłospis bezglutenowy”) pokaże się na stronie pod datami.
5. Opublikuj.

Na liście jadłospisów kolumna „Na stronie” pokazuje, który jadłospis jest teraz aktualny, które są w archiwum, a którym brakuje pliku lub dat.

== Który jadłospis jest „aktualny”? ==

1. Ten, który obowiązuje dzisiaj.
2. Jeśli dziś żaden nie obowiązuje (np. przerwa) – ostatni, który już się zaczął.
3. Jeśli wszystkie są w przyszłości – najbliższy.

Dzięki temu jadłospis na kolejny tydzień można wgrać wcześniej – nie wyskoczy jako aktualny przed czasem.
Wszystkie pozostałe jadłospisy trafiają do archiwum (od najnowszego). Te, które jeszcze nie obowiązują, mają etykietę „nadchodzący” – można je ukryć.

== Osadzanie na stronie ==

Blok (edytor Gutenberg)
Dodaj blok „Jadłospisy”. Ustawienia w panelu bocznym: co wyświetlić, poziom nagłówków, nagłówki sekcji, podgląd PDF, liczba pozycji archiwum, nadchodzące jadłospisy.

Shortcode (Elementor, Divi, WPBakery, klasyczny edytor)
Wstaw widżet „Shortcode” i wpisz:

  [jadlospisy]

Parametry (wszystkie opcjonalne):

  widok="wszystko"        wszystko | aktualny | archiwum
  podglad="tak"           tak | nie – podgląd PDF pod przyciskami (na telefonach zawsze ukryty)
  naglowek="h2"           h2 | h3 | h4 | h5 | h6 – dopasuj do sekcji, w której osadzasz
  tytul_aktualny="Aktualny jadłospis"   pusty = bez nagłówka
  tytul_archiwum="Archiwum jadłospisów" pusty = bez nagłówka
  limit_archiwum="0"      ile pozycji pokazać od razu; resztę schowa „Pokaż starsze jadłospisy”; 0 = wszystkie
  nadchodzace="tak"       tak | nie – czy pokazywać w archiwum jadłospisy, które jeszcze nie obowiązują

Przykłady:

  [jadlospisy widok="aktualny" podglad="nie"]
  [jadlospisy widok="archiwum" limit_archiwum="5" naglowek="h3"]
  Aktualny i archiwum w osobnych kolumnach – dwa shortcody z różnym parametrem widok.

Widżet (pasek boczny, stopka)
Wygląd → Widżety → „Jadłospisy”.

== Wygląd ==

Wtyczka dziedziczy czcionki motywu. Kolory zmienisz w Wygląd → Dostosuj → Dodatkowy CSS:

  .jadlospisy {
      --jadlospisy-kolor: #b3261e;          /* przyciski i etykiety */
      --jadlospisy-kolor-tekst: #fff;       /* tekst na przyciskach */
      --jadlospisy-tlo: #f7f7f7;            /* tło karty aktualnego jadłospisu */
      --jadlospisy-ramka: #e2e2e2;
      --jadlospisy-promien: 4px;
      --jadlospisy-podglad-wysokosc: 700px;
  }

== Dla programistów ==

Filtry:
  jadlospisy_items          – lista jadłospisów (tablica) przed wyświetleniem
  jadlospisy_current_item   – wybór aktualnego jadłospisu
  jadlospisy_format_range   – format zakresu dat
  jadlospisy_domyslna_dlugosc – ile dni podpowiadać w panelu (domyślnie 7)

Dane: typ wpisu „jadlospis”, pola _jadlospis_od, _jadlospis_do (Y-m-d), _jadlospis_pdf (ID załącznika).

== Odinstalowanie ==

Usunięcie wtyczki kasuje wpisy jadłospisów. Pliki PDF zostają w Bibliotece mediów.
Sama dezaktywacja niczego nie usuwa.

= 1.1.1 =
* Układ „karta”: bez odstępu 40 px między kartą a archiwum.

= 1.1.0 =
* Układ „karta” (shortcode uklad="karta"): aktualny jadłospis w karcie z przyciskiem „Pobierz PDF”, archiwum w rozwijanej liście. Domyślny układ bez zmian.

== Aktualizacje ==

Od wersji 1.2.0 wtyczka sama sprawdza nowe wersje w https://github.com/jbalabuch/moveup-wtyczki (plik wtyczki.json) – aktualizacja pojawia się w Kokpit → Aktualizacje, można włączyć automatyczne aktualizacje. Nagłówek „Update URI” sprawia, że WordPress nie myli wtyczki z wtyczką o tej samej nazwie na wordpress.org.
