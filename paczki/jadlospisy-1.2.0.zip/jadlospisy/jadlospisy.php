<?php
/**
 * Plugin Name:       Jadłospisy
 * Description:       Jadłospisy w PDF z zakresem dat. Pokazuje aktualny jadłospis i archiwum – jako blok, widżet albo shortcode [jadlospisy]; układ „karta” (uklad="karta"): karta z przyciskiem PDF i rozwijane archiwum.
 * Version:           1.2.0
 * Author:            moveUP Agency
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Update URI:        https://github.com/jbalabuch/moveup-wtyczki
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       jadlospisy
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'jadlospisy' );

define( 'JADLOSPISY_VERSION', '1.2.0' );
define( 'JADLOSPISY_DIR', plugin_dir_path( __FILE__ ) );
define( 'JADLOSPISY_URL', plugin_dir_url( __FILE__ ) );

require_once JADLOSPISY_DIR . 'includes/class-jadlospisy-post-type.php';
require_once JADLOSPISY_DIR . 'includes/class-jadlospisy-repository.php';
require_once JADLOSPISY_DIR . 'includes/class-jadlospisy-frontend.php';
require_once JADLOSPISY_DIR . 'includes/class-jadlospisy-widget.php';

Jadlospisy_Post_Type::init();
Jadlospisy_Frontend::init();

add_action(
	'widgets_init',
	function () {
		register_widget( 'Jadlospisy_Widget' );
	}
);

if ( is_admin() ) {
	require_once JADLOSPISY_DIR . 'includes/class-jadlospisy-admin.php';
	Jadlospisy_Admin::init();
}
