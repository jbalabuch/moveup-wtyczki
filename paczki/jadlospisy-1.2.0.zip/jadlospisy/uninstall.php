<?php
/**
 * Usunięcie wtyczki (nie dezaktywacja): kasuje wpisy jadłospisów.
 * Pliki PDF zostają w Bibliotece mediów.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$jadlospisy_ids = get_posts(
	array(
		'post_type'   => 'jadlospis',
		'post_status' => array_keys( get_post_stati() ),
		'numberposts' => -1,
		'fields'      => 'ids',
	)
);

foreach ( $jadlospisy_ids as $jadlospisy_id ) {
	wp_delete_post( $jadlospisy_id, true );
}
