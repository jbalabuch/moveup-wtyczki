<?php
/**
 * Typ wpisu „jadlospis” – widoczny tylko w panelu, bez własnych adresów URL.
 */

defined( 'ABSPATH' ) || exit;

final class Jadlospisy_Post_Type {

	const NAME      = 'jadlospis';
	const META_OD   = '_jadlospis_od';
	const META_DO   = '_jadlospis_do';
	const META_PDF  = '_jadlospis_pdf';
	const META_AUTO = '_jadlospis_tytul_auto';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	public static function register() {
		register_post_type(
			self::NAME,
			array(
				'labels'        => array(
					'name'               => __( 'Jadłospisy', 'jadlospisy' ),
					'singular_name'      => __( 'Jadłospis', 'jadlospisy' ),
					'menu_name'          => __( 'Jadłospisy', 'jadlospisy' ),
					'all_items'          => __( 'Wszystkie jadłospisy', 'jadlospisy' ),
					'add_new'            => __( 'Dodaj jadłospis', 'jadlospisy' ),
					'add_new_item'       => __( 'Dodaj jadłospis', 'jadlospisy' ),
					'edit_item'          => __( 'Edytuj jadłospis', 'jadlospisy' ),
					'new_item'           => __( 'Nowy jadłospis', 'jadlospisy' ),
					'search_items'       => __( 'Szukaj jadłospisów', 'jadlospisy' ),
					'not_found'          => __( 'Nie dodano jeszcze żadnego jadłospisu.', 'jadlospisy' ),
					'not_found_in_trash' => __( 'Kosz jest pusty.', 'jadlospisy' ),
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'show_in_rest'  => false,
				'menu_position' => 25,
				'menu_icon'     => 'dashicons-food',
				'supports'      => array( 'title' ),
				'rewrite'       => false,
				'query_var'     => false,
			)
		);
	}
}
