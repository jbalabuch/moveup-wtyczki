<?php
/**
 * Klasyczny widżet – do paska bocznego, stopki i kreatorów stron obsługujących widżety WP.
 */

defined( 'ABSPATH' ) || exit;

class Jadlospisy_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'jadlospisy_widget',
			__( 'Jadłospisy', 'jadlospisy' ),
			array(
				'description'                 => __( 'Aktualny jadłospis i archiwum jadłospisów w PDF.', 'jadlospisy' ),
				'customize_selective_refresh' => true,
			)
		);
	}

	private function defaults() {
		return array(
			'title'          => '',
			'widok'          => 'wszystko',
			'podglad'        => 0,
			'limit_archiwum' => 5,
		);
	}

	public function widget( $args, $instance ) {
		$instance = wp_parse_args( (array) $instance, $this->defaults() );

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput

		$title = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
		if ( $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput
		}

		echo Jadlospisy_Frontend::render( // phpcs:ignore WordPress.Security.EscapeOutput -- escapowane w render().
			array(
				'widok'          => $instance['widok'],
				'podglad'        => (bool) $instance['podglad'],
				'naglowek'       => $title ? 'h4' : 'h3',
				'limit_archiwum' => $instance['limit_archiwum'],
			)
		);

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public function form( $instance ) {
		$i = wp_parse_args( (array) $instance, $this->defaults() );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Tytuł widżetu (opcjonalnie):', 'jadlospisy' ); ?></label>
			<input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $i['title'] ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'widok' ) ); ?>"><?php esc_html_e( 'Co wyświetlić:', 'jadlospisy' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'widok' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'widok' ) ); ?>">
				<option value="wszystko" <?php selected( $i['widok'], 'wszystko' ); ?>><?php esc_html_e( 'Aktualny jadłospis i archiwum', 'jadlospisy' ); ?></option>
				<option value="aktualny" <?php selected( $i['widok'], 'aktualny' ); ?>><?php esc_html_e( 'Tylko aktualny jadłospis', 'jadlospisy' ); ?></option>
				<option value="archiwum" <?php selected( $i['widok'], 'archiwum' ); ?>><?php esc_html_e( 'Tylko archiwum', 'jadlospisy' ); ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'limit_archiwum' ) ); ?>"><?php esc_html_e( 'Ile pozycji archiwum pokazać od razu (0 = wszystkie):', 'jadlospisy' ); ?></label>
			<input class="tiny-text" type="number" min="0" step="1" id="<?php echo esc_attr( $this->get_field_id( 'limit_archiwum' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit_archiwum' ) ); ?>" value="<?php echo esc_attr( $i['limit_archiwum'] ); ?>">
		</p>
		<p>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'podglad' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'podglad' ) ); ?>" value="1" <?php checked( $i['podglad'] ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'podglad' ) ); ?>"><?php esc_html_e( 'Pokaż podgląd PDF (lepiej w szerokich obszarach niż w pasku bocznym)', 'jadlospisy' ); ?></label>
		</p>
		<?php
	}

	public function update( $new, $old ) {
		return array(
			'title'          => sanitize_text_field( $new['title'] ?? '' ),
			'widok'          => in_array( $new['widok'] ?? '', array( 'wszystko', 'aktualny', 'archiwum' ), true ) ? $new['widok'] : 'wszystko',
			'podglad'        => empty( $new['podglad'] ) ? 0 : 1,
			'limit_archiwum' => max( 0, (int) ( $new['limit_archiwum'] ?? 0 ) ),
		);
	}
}
