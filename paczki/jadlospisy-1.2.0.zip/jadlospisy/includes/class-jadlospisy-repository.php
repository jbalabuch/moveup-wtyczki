<?php
/**
 * Pobieranie jadłospisów i logika „aktualny / archiwum”.
 */

defined( 'ABSPATH' ) || exit;

final class Jadlospisy_Repository {

	/** @var array|null Pamięć podręczna na czas jednego żądania. */
	private static $items = null;

	/** Dzisiejsza data w strefie czasowej witryny (Y-m-d). */
	public static function today() {
		return current_time( 'Y-m-d' );
	}

	public static function flush() {
		self::$items = null;
	}

	/**
	 * Opublikowane i kompletne (PDF + obie daty) jadłospisy, od najnowszego.
	 *
	 * @return array[]
	 */
	public static function all() {
		if ( null !== self::$items ) {
			return self::$items;
		}

		$posts = get_posts(
			array(
				'post_type'   => Jadlospisy_Post_Type::NAME,
				'post_status' => 'publish',
				'numberposts' => -1,
			)
		);

		$items = array();
		foreach ( $posts as $post ) {
			$item = self::item( $post );
			if ( $item ) {
				$items[] = $item;
			}
		}

		usort(
			$items,
			function ( $a, $b ) {
				return array( $b['od'], $b['do'], $b['id'] ) <=> array( $a['od'], $a['do'], $a['id'] );
			}
		);

		self::$items = apply_filters( 'jadlospisy_items', $items );

		return self::$items;
	}

	/**
	 * Dane jednego jadłospisu albo null, jeśli brakuje PDF-a lub dat.
	 *
	 * @param int|WP_Post $post
	 * @return array|null
	 */
	public static function item( $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return null;
		}

		$od     = get_post_meta( $post->ID, Jadlospisy_Post_Type::META_OD, true );
		$do     = get_post_meta( $post->ID, Jadlospisy_Post_Type::META_DO, true );
		$pdf_id = (int) get_post_meta( $post->ID, Jadlospisy_Post_Type::META_PDF, true );
		$url    = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';

		if ( ! self::is_date( $od ) || ! self::is_date( $do ) || ! $url ) {
			return null;
		}

		return array(
			'id'     => $post->ID,
			'tytul'  => $post->post_title,
			'od'     => $od,
			'do'     => $do,
			'pdf_id' => $pdf_id,
			'url'    => $url,
			'auto'   => (bool) get_post_meta( $post->ID, Jadlospisy_Post_Type::META_AUTO, true ),
		);
	}

	/**
	 * Aktualny jadłospis:
	 * 1. obowiązujący dzisiaj (przy nakładaniu się dat – ten, który zaczyna się później),
	 * 2. jeśli dziś nic nie obowiązuje – ostatni, który już się zaczął,
	 * 3. jeśli wszystkie są w przyszłości – najbliższy nadchodzący.
	 *
	 * @return array|null
	 */
	public static function current() {
		$items = self::all();
		$today = self::today();
		$found = null;

		foreach ( $items as $item ) {
			if ( $item['od'] <= $today && $item['do'] >= $today ) {
				$found = $item;
				break;
			}
		}

		if ( ! $found ) {
			foreach ( $items as $item ) {
				if ( $item['od'] <= $today ) {
					$found = $item;
					break;
				}
			}
		}

		if ( ! $found && $items ) {
			$found = end( $items );
		}

		return apply_filters( 'jadlospisy_current_item', $found, $items );
	}

	/**
	 * Wszystkie jadłospisy poza aktualnym.
	 *
	 * @param bool $with_upcoming Czy pokazywać jadłospisy, które jeszcze się nie zaczęły.
	 * @return array[]
	 */
	public static function archive( $with_upcoming = true ) {
		$current    = self::current();
		$current_id = $current ? $current['id'] : 0;
		$today      = self::today();

		return array_values(
			array_filter(
				self::all(),
				function ( $item ) use ( $current_id, $today, $with_upcoming ) {
					if ( $item['id'] === $current_id ) {
						return false;
					}
					return $with_upcoming || $item['od'] <= $today;
				}
			)
		);
	}

	/** @return string aktualny | nadchodzacy | archiwalny */
	public static function status( array $item ) {
		$current = self::current();
		if ( $current && $current['id'] === $item['id'] ) {
			return 'aktualny';
		}
		return $item['od'] > self::today() ? 'nadchodzacy' : 'archiwalny';
	}

	public static function is_date( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) ) {
			return false;
		}
		return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	}

	/**
	 * Zakres dat do wyświetlenia, np. „14 września – 20 września 2026”
	 * albo „28 września – 4 października 2026”.
	 */
	public static function format_range( $od, $do ) {
		$tz = wp_timezone();
		$a  = DateTimeImmutable::createFromFormat( '!Y-m-d', $od, $tz );
		$b  = DateTimeImmutable::createFromFormat( '!Y-m-d', $do, $tz );

		if ( ! $a || ! $b ) {
			return '';
		}

		$ta = $a->getTimestamp();
		$tb = $b->getTimestamp();

		if ( $od === $do ) {
			$text = wp_date( 'j F Y', $ta );
		} elseif ( substr( $od, 0, 4 ) === substr( $do, 0, 4 ) ) {
			// Miesiąc zawsze przy obu datach, także w tym samym miesiącu: „14 sierpnia – 23 sierpnia 2026”.
			$text = wp_date( 'j F', $ta ) . ' – ' . wp_date( 'j F Y', $tb );
		} else {
			$text = wp_date( 'j F Y', $ta ) . ' – ' . wp_date( 'j F Y', $tb );
		}

		return apply_filters( 'jadlospisy_format_range', $text, $od, $do );
	}

	/** Tytuł nadawany automatycznie, gdy redaktor zostawi pole puste. */
	public static function auto_title( $od, $do ) {
		/* translators: %s: zakres dat */
		return sprintf( __( 'Jadłospis %s', 'jadlospisy' ), self::format_range( $od, $do ) );
	}

	/** Czy tytuł został wpisany ręcznie (a nie wygenerowany z dat). */
	public static function has_custom_title( array $item ) {
		return ! $item['auto'] && '' !== trim( $item['tytul'] );
	}

	/** Np. „PDF, 240 KB”. */
	public static function file_meta( $pdf_id ) {
		$path = get_attached_file( $pdf_id );
		if ( $path && file_exists( $path ) ) {
			return 'PDF, ' . size_format( filesize( $path ) );
		}
		return 'PDF';
	}
}
