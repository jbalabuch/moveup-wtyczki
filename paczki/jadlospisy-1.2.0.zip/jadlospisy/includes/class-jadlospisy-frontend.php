<?php
/**
 * Wyświetlanie jadłospisów: shortcode [jadlospisy] i blok „Jadłospisy”.
 */

defined( 'ABSPATH' ) || exit;

final class Jadlospisy_Frontend {

	const SHORTCODE = 'jadlospisy';
	const BLOCK     = 'jadlospisy/jadlospisy';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_assets' ) );
		add_action( 'init', array( __CLASS__, 'register_block' ) );
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'shortcode' ) );
	}

	public static function register_assets() {
		wp_register_style( 'jadlospisy', JADLOSPISY_URL . 'assets/jadlospisy.css', array(), JADLOSPISY_VERSION );
		wp_register_script(
			'jadlospisy-block',
			JADLOSPISY_URL . 'assets/block.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
			JADLOSPISY_VERSION,
			true
		);
		wp_localize_script( 'jadlospisy-block', 'jadlospisyBlock', array( 'defaults' => self::defaults() ) );
	}

	/** Domyślne ustawienia widoku. */
	public static function defaults() {
		return array(
			'widok'          => 'wszystko',
			'podglad'        => 'tak',
			'naglowek'       => 'h2',
			'tytul_aktualny' => __( 'Aktualny jadłospis', 'jadlospisy' ),
			'tytul_archiwum' => __( 'Archiwum jadłospisów', 'jadlospisy' ),
			'limit_archiwum' => 0,
			'nadchodzace'    => 'tak',
			'uklad'          => 'standard', // standard | karta (karta z przyciskiem PDF + rozwijane archiwum)
		);
	}

	public static function register_block() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		$d = self::defaults();

		register_block_type(
			self::BLOCK,
			array(
				'api_version'     => 2,
				'editor_script'   => 'jadlospisy-block',
				'style'           => 'jadlospisy',
				'render_callback' => array( __CLASS__, 'render_block' ),
				'supports'        => array(
					'align' => array( 'wide', 'full' ),
					'html'  => false,
				),
				'attributes'      => array(
					'widok'         => array( 'type' => 'string', 'default' => $d['widok'] ),
					'podglad'       => array( 'type' => 'boolean', 'default' => true ),
					'naglowek'      => array( 'type' => 'string', 'default' => $d['naglowek'] ),
					'tytulAktualny' => array( 'type' => 'string', 'default' => $d['tytul_aktualny'] ),
					'tytulArchiwum' => array( 'type' => 'string', 'default' => $d['tytul_archiwum'] ),
					'limitArchiwum' => array( 'type' => 'number', 'default' => 0 ),
					'nadchodzace'   => array( 'type' => 'boolean', 'default' => true ),
					'uklad'         => array( 'type' => 'string', 'default' => $d['uklad'] ),
					'align'         => array( 'type' => 'string' ),
					'className'     => array( 'type' => 'string' ),
				),
			)
		);
	}

	public static function shortcode( $atts ) {
		return self::render( shortcode_atts( self::defaults(), $atts, self::SHORTCODE ) );
	}

	public static function render_block( $attributes ) {
		$map  = array(
			'widok'         => 'widok',
			'podglad'       => 'podglad',
			'naglowek'      => 'naglowek',
			'tytulAktualny' => 'tytul_aktualny',
			'tytulArchiwum' => 'tytul_archiwum',
			'limitArchiwum' => 'limit_archiwum',
			'nadchodzace'   => 'nadchodzace',
			'uklad'         => 'uklad',
		);
		$args = array();
		foreach ( $map as $from => $to ) {
			if ( isset( $attributes[ $from ] ) ) {
				$args[ $to ] = $attributes[ $from ];
			}
		}

		$wrapper = function_exists( 'get_block_wrapper_attributes' )
			? get_block_wrapper_attributes( array( 'class' => 'jadlospisy' ) )
			: '';

		return self::render( $args, $wrapper );
	}

	/**
	 * Główny widok – używany przez shortcode, blok i widżet.
	 *
	 * @param array  $args    Ustawienia (klucze jak w defaults()).
	 * @param string $wrapper Atrybuty HTML kontenera (dla bloków).
	 */
	public static function render( $args = array(), $wrapper = '' ) {
		$a = self::normalize( $args );

		wp_enqueue_style( 'jadlospisy' );

		if ( '' === $wrapper ) {
			$wrapper = 'class="jadlospisy"';
		}

		ob_start();

		if ( 'karta' === $a['uklad'] ) {
			$wrapper = str_replace( 'class="jadlospisy', 'class="jadlospisy jadlospisy--karta', $wrapper );
		}

		echo '<div ' . $wrapper . '>'; // phpcs:ignore WordPress.Security.EscapeOutput -- atrybuty budowane przez WP.

		if ( 'karta' === $a['uklad'] ) {
			self::render_karta( Jadlospisy_Repository::current(), Jadlospisy_Repository::archive( $a['nadchodzace'] ), $a );
			echo '</div>';
			return ob_get_clean();
		}

		if ( 'archiwum' !== $a['widok'] ) {
			self::render_current( Jadlospisy_Repository::current(), $a );
		}

		if ( 'aktualny' !== $a['widok'] ) {
			self::render_archive( Jadlospisy_Repository::archive( $a['nadchodzace'] ), $a );
		}

		echo '</div>';

		return ob_get_clean();
	}

	private static function normalize( $args ) {
		$args = wp_parse_args( $args, self::defaults() );

		return array(
			'widok'          => in_array( $args['widok'], array( 'wszystko', 'aktualny', 'archiwum' ), true ) ? $args['widok'] : 'wszystko',
			'podglad'        => self::to_bool( $args['podglad'] ),
			'naglowek'       => in_array( $args['naglowek'], array( 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $args['naglowek'] : 'h2',
			'tytul_aktualny' => sanitize_text_field( $args['tytul_aktualny'] ),
			'tytul_archiwum' => sanitize_text_field( $args['tytul_archiwum'] ),
			'limit_archiwum' => max( 0, (int) $args['limit_archiwum'] ),
			'nadchodzace'    => self::to_bool( $args['nadchodzace'] ),
			'uklad'          => 'karta' === $args['uklad'] ? 'karta' : 'standard',
		);
	}

	private static function to_bool( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		return ! in_array( strtolower( trim( (string) $value ) ), array( 'nie', 'ukryj', '0', 'false', 'no', 'off', '' ), true );
	}

	private static function heading( $text, $tag ) {
		if ( '' === $text ) {
			return;
		}
		printf( '<%1$s class="jadlospisy__naglowek">%2$s</%1$s>', $tag, esc_html( $text ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- $tag z białej listy.
	}

	private static function render_current( $item, array $a ) {
		echo '<section class="jadlospisy__sekcja jadlospisy__sekcja--aktualny">';
		self::heading( $a['tytul_aktualny'], $a['naglowek'] );

		if ( ! $item ) {
			echo '<p class="jadlospisy__pusto">' . esc_html__( 'Jadłospis pojawi się tu wkrótce.', 'jadlospisy' ) . '</p>';
			echo '</section>';
			return;
		}

		$range = Jadlospisy_Repository::format_range( $item['od'], $item['do'] );

		echo '<div class="jadlospisy__karta">';

		echo '<p class="jadlospisy__okres">' . esc_html( $range );
		if ( $item['od'] > Jadlospisy_Repository::today() ) {
			echo ' <span class="jadlospisy__etykieta">' . esc_html__( 'nadchodzący', 'jadlospisy' ) . '</span>';
		}
		echo '</p>';

		if ( Jadlospisy_Repository::has_custom_title( $item ) ) {
			echo '<p class="jadlospisy__opis">' . esc_html( $item['tytul'] ) . '</p>';
		}

		echo '<p class="jadlospisy__akcje">';
		// Ukryte dopiski dla czytników ekranu: który jadłospis i że to PDF (WCAG 2.4.4 – cel linku bez kontekstu).
		printf(
			'<a class="jadlospisy__przycisk" href="%1$s" target="_blank" rel="noopener">%2$s<span class="screen-reader-text"> %3$s (PDF, otwiera się w nowej karcie)</span></a>',
			esc_url( $item['url'] ),
			esc_html__( 'Otwórz jadłospis', 'jadlospisy' ),
			esc_html( $range )
		);
		printf(
			'<a class="jadlospisy__przycisk jadlospisy__przycisk--drugi" href="%1$s" download>%2$s<span class="screen-reader-text"> %3$s %4$s (PDF)</span></a>',
			esc_url( $item['url'] ),
			esc_html__( 'Pobierz', 'jadlospisy' ),
			esc_html__( 'jadłospis', 'jadlospisy' ),
			esc_html( $range )
		);
		echo '<span class="jadlospisy__meta">' . esc_html( Jadlospisy_Repository::file_meta( $item['pdf_id'] ) ) . '</span>';
		echo '</p>';

		if ( $a['podglad'] ) {
			printf(
				'<div class="jadlospisy__podglad"><iframe src="%1$s" title="%2$s" loading="lazy"></iframe></div>',
				esc_url( $item['url'] . '#view=FitH' ),
				/* translators: %s: zakres dat */
				esc_attr( sprintf( __( 'Podgląd jadłospisu %s', 'jadlospisy' ), $range ) )
			);
		}

		echo '</div>';
		echo '</section>';
	}

	private static function render_archive( array $items, array $a ) {
		// W widoku łączonym puste archiwum po prostu się nie pokazuje.
		if ( ! $items && 'wszystko' === $a['widok'] ) {
			return;
		}

		echo '<section class="jadlospisy__sekcja jadlospisy__sekcja--archiwum">';
		self::heading( $a['tytul_archiwum'], $a['naglowek'] );

		if ( ! $items ) {
			echo '<p class="jadlospisy__pusto">' . esc_html__( 'Archiwum jest puste.', 'jadlospisy' ) . '</p>';
			echo '</section>';
			return;
		}

		$limit   = $a['limit_archiwum'];
		$visible = $limit ? array_slice( $items, 0, $limit ) : $items;
		$hidden  = $limit ? array_slice( $items, $limit ) : array();

		self::render_list( $visible );

		if ( $hidden ) {
			// Starsze pozycje pod przyciskiem; napis zmienia się po rozwinięciu (bez JS – <details> + CSS).
			echo '<details class="jadlospisy__wiecej"><summary class="jadlospisy__przycisk jadlospisy__przycisk--drugi">';
			echo '<span class="jadlospisy__pokaz">';
			/* translators: %d: liczba ukrytych jadłospisów */
			echo esc_html( sprintf( __( 'Pokaż starsze jadłospisy (%d)', 'jadlospisy' ), count( $hidden ) ) );
			echo '</span><span class="jadlospisy__zwin">' . esc_html__( 'Zwiń listę', 'jadlospisy' ) . '</span>';
			echo '</summary>';
			self::render_list( $hidden );
			echo '</details>';
		}

		echo '</section>';
	}

	/**
	 * Układ „karta”: aktualny jadłospis w karcie (ikona, tytuł, zakres dat, przycisk „Pobierz PDF”),
	 * pod nią archiwum w rozwijanym <details> (zakres dat + link „Pobierz PDF” w każdym wierszu).
	 */
	private static function render_karta( $item, array $items, array $a ) {
		$ikona = '<span class="jadlospisy__ikona" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/></svg></span>';
		$range = $item ? Jadlospisy_Repository::format_range( $item['od'], $item['do'] ) : '';

		echo '<div class="jadlospisy__plik' . ( $item ? '' : ' jadlospisy__plik--pusty' ) . '">';
		echo $ikona; // phpcs:ignore WordPress.Security.EscapeOutput -- stały SVG.
		echo '<div class="jadlospisy__plik-opis">';
		printf( '<%1$s class="jadlospisy__plik-tytul">%2$s</%1$s>', esc_html( $a['naglowek'] ), esc_html( $a['tytul_aktualny'] ) );
		if ( $item ) {
			echo '<small class="jadlospisy__plik-daty">' . esc_html( $range );
			if ( $item['od'] > Jadlospisy_Repository::today() ) {
				echo ' <span class="jadlospisy__etykieta">' . esc_html__( 'nadchodzący', 'jadlospisy' ) . '</span>';
			}
			echo '</small>';
		} else {
			echo '<small class="jadlospisy__plik-daty">' . esc_html__( 'Jadłospis pojawi się tu wkrótce.', 'jadlospisy' ) . '</small>';
		}
		echo '</div>';
		if ( $item ) {
			printf(
				'<a class="jadlospisy__pobierz" href="%1$s" target="_blank" rel="noopener">%2$s<span class="screen-reader-text"> – %3$s %4$s (%5$s, otwiera się w nowej karcie)</span></a>',
				esc_url( $item['url'] ),
				esc_html__( 'Pobierz PDF', 'jadlospisy' ),
				esc_html__( 'jadłospis', 'jadlospisy' ),
				esc_html( $range ),
				esc_html( Jadlospisy_Repository::file_meta( $item['pdf_id'] ) )
			);
		}
		echo '</div>';

		if ( ! $items ) {
			return;
		}
		echo '<details class="jadlospisy__archiwum"><summary>' . esc_html( $a['tytul_archiwum'] ) . '</summary><ul class="jadlospisy__archiwum-lista">';
		foreach ( $items as $it ) {
			$r = Jadlospisy_Repository::format_range( $it['od'], $it['do'] );
			printf(
				'<li><span>%1$s</span><a href="%2$s" target="_blank" rel="noopener">%3$s<span class="screen-reader-text"> – %4$s %1$s (%5$s, otwiera się w nowej karcie)</span></a></li>',
				esc_html( $r ),
				esc_url( $it['url'] ),
				esc_html__( 'Pobierz PDF', 'jadlospisy' ),
				esc_html__( 'jadłospis', 'jadlospisy' ),
				esc_html( Jadlospisy_Repository::file_meta( $it['pdf_id'] ) )
			);
		}
		echo '</ul></details>';
	}

	private static function render_list( array $items ) {
		$today = Jadlospisy_Repository::today();

		echo '<ul class="jadlospisy__lista">';
		foreach ( $items as $item ) {
			echo '<li class="jadlospisy__pozycja">';
			printf(
				'<a class="jadlospisy__link" href="%1$s" target="_blank" rel="noopener">%2$s</a>',
				esc_url( $item['url'] ),
				esc_html( Jadlospisy_Repository::format_range( $item['od'], $item['do'] ) )
			);
			if ( $item['od'] > $today ) {
				echo '<span class="jadlospisy__etykieta">' . esc_html__( 'nadchodzący', 'jadlospisy' ) . '</span>';
			}
			if ( Jadlospisy_Repository::has_custom_title( $item ) ) {
				echo '<span class="jadlospisy__opis">' . esc_html( $item['tytul'] ) . '</span>';
			}
			echo '<span class="jadlospisy__meta">' . esc_html( Jadlospisy_Repository::file_meta( $item['pdf_id'] ) ) . '</span>';
			echo '</li>';
		}
		echo '</ul>';
	}
}
