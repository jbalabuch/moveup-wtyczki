<?php
/**
 * Panel: pole PDF i daty, kolumny na liście, komunikaty.
 */

defined( 'ABSPATH' ) || exit;

final class Jadlospisy_Admin {

	const NONCE = 'jadlospisy_nonce';

	/** @var string[] Kody ostrzeżeń z bieżącego zapisu. */
	private static $notices = array();

	public static function init() {
		$pt = Jadlospisy_Post_Type::NAME;

		add_action( 'add_meta_boxes_' . $pt, array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_' . $pt, array( __CLASS__, 'save' ) );
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'auto_title' ), 10, 2 );
		add_filter( 'redirect_post_location', array( __CLASS__, 'redirect' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'enter_title_here', array( __CLASS__, 'title_placeholder' ), 10, 2 );
		add_filter( 'post_updated_messages', array( __CLASS__, 'messages' ) );

		add_filter( 'manage_' . $pt . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . $pt . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_filter( 'manage_edit-' . $pt . '_sortable_columns', array( __CLASS__, 'sortable_columns' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'list_order' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Edycja jadłospisu                                                   */
	/* ------------------------------------------------------------------ */

	public static function add_meta_box() {
		add_meta_box(
			'jadlospisy-dane',
			__( 'Plik i okres obowiązywania', 'jadlospisy' ),
			array( __CLASS__, 'render_meta_box' ),
			null,
			'normal',
			'high'
		);
	}

	public static function render_meta_box( $post ) {
		$od     = get_post_meta( $post->ID, Jadlospisy_Post_Type::META_OD, true );
		$do     = get_post_meta( $post->ID, Jadlospisy_Post_Type::META_DO, true );
		$pdf_id = (int) get_post_meta( $post->ID, Jadlospisy_Post_Type::META_PDF, true );
		$url    = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
		$file   = $pdf_id ? get_attached_file( $pdf_id ) : '';

		wp_nonce_field( self::NONCE, self::NONCE );
		?>
		<div class="jadlospisy-box">
			<div class="jadlospisy-box__pdf">
				<p class="jadlospisy-box__etykieta"><?php esc_html_e( 'Plik PDF', 'jadlospisy' ); ?></p>
				<input type="hidden" id="jadlospis_pdf" name="jadlospis_pdf" value="<?php echo esc_attr( $url ? $pdf_id : '' ); ?>">
				<p id="jadlospis_pdf_nazwa" class="jadlospisy-box__plik">
					<?php if ( $url ) : ?>
						<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( wp_basename( $file ? $file : $url ) ); ?></a>
					<?php else : ?>
						<em><?php esc_html_e( 'Nie wybrano pliku.', 'jadlospisy' ); ?></em>
					<?php endif; ?>
				</p>
				<p>
					<button type="button" class="button button-primary" id="jadlospis_pdf_wybierz"><?php esc_html_e( 'Wybierz lub wgraj PDF', 'jadlospisy' ); ?></button>
					<button type="button" class="button-link button-link-delete" id="jadlospis_pdf_usun"><?php esc_html_e( 'Usuń plik', 'jadlospisy' ); ?></button>
				</p>
			</div>

			<div class="jadlospisy-box__daty">
				<p>
					<label class="jadlospisy-box__etykieta" for="jadlospis_od"><?php esc_html_e( 'Obowiązuje od', 'jadlospisy' ); ?></label>
					<input type="date" id="jadlospis_od" name="jadlospis_od" value="<?php echo esc_attr( $od ); ?>">
				</p>
				<p>
					<label class="jadlospisy-box__etykieta" for="jadlospis_do"><?php esc_html_e( 'Obowiązuje do', 'jadlospisy' ); ?></label>
					<input type="date" id="jadlospis_do" name="jadlospis_do" value="<?php echo esc_attr( $do ); ?>" min="<?php echo esc_attr( $od ); ?>">
				</p>
			</div>

			<p class="description jadlospisy-box__opis">
				<?php esc_html_e( 'Tytuł nie jest wymagany – jeśli zostawisz go pustego, powstanie z dat, np. „Jadłospis 14 września – 20 września 2026”. Na stronie jako aktualny pokazuje się jadłospis obowiązujący dzisiaj.', 'jadlospisy' ); ?>
			</p>
		</div>
		<?php
	}

	private static function nonce_ok() {
		return isset( $_POST[ self::NONCE ] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ), self::NONCE );
	}

	private static function posted_date( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification -- sprawdzane w nonce_ok() przed wywołaniem.
		$value = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
		return Jadlospisy_Repository::is_date( $value ) ? $value : '';
	}

	/** @return string[] [od, do] – uporządkowane rosnąco. */
	private static function posted_range() {
		$od = self::posted_date( 'jadlospis_od' );
		$do = self::posted_date( 'jadlospis_do' );
		if ( $od && $do && $do < $od ) {
			return array( $do, $od, true );
		}
		return array( $od, $do, false );
	}

	public static function save( $post_id ) {
		if ( ! self::nonce_ok() || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification
		$pdf_id = isset( $_POST['jadlospis_pdf'] ) ? absint( $_POST['jadlospis_pdf'] ) : 0;
		if ( $pdf_id && 'application/pdf' !== get_post_mime_type( $pdf_id ) ) {
			$pdf_id = 0;
		}

		list( $od, $do, $swapped ) = self::posted_range();

		self::update_meta( $post_id, Jadlospisy_Post_Type::META_PDF, $pdf_id ? $pdf_id : '' );
		self::update_meta( $post_id, Jadlospisy_Post_Type::META_OD, $od );
		self::update_meta( $post_id, Jadlospisy_Post_Type::META_DO, $do );

		$is_auto = $od && $do && get_post_field( 'post_title', $post_id, 'raw' ) === Jadlospisy_Repository::auto_title( $od, $do );
		self::update_meta( $post_id, Jadlospisy_Post_Type::META_AUTO, $is_auto ? 1 : '' );

		Jadlospisy_Repository::flush();

		if ( $swapped ) {
			self::$notices[] = 'zamienione';
		}
		if ( ! $pdf_id ) {
			self::$notices[] = 'brak_pdf';
		}
		if ( ! $od || ! $do ) {
			self::$notices[] = 'brak_dat';
		}

		if ( $pdf_id && $od && $do && 'publish' === get_post_status( $post_id ) ) {
			foreach ( Jadlospisy_Repository::all() as $other ) {
				if ( $other['id'] !== $post_id && $other['od'] <= $do && $other['do'] >= $od ) {
					self::$notices[] = 'nakladanie';
					break;
				}
			}
		}
	}

	private static function update_meta( $post_id, $key, $value ) {
		if ( '' === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, $value );
		}
	}

	/**
	 * Pusty tytuł (albo tytuł wygenerowany wcześniej z dat) zastępujemy tytułem z aktualnych dat.
	 */
	public static function auto_title( $data, $postarr ) {
		if ( Jadlospisy_Post_Type::NAME !== $data['post_type'] || ! self::nonce_ok() ) {
			return $data;
		}

		list( $od, $do ) = self::posted_range();
		if ( ! $od || ! $do ) {
			return $data;
		}

		$title    = trim( wp_unslash( $data['post_title'] ) );
		$post_id  = empty( $postarr['ID'] ) ? 0 : (int) $postarr['ID'];
		$was_auto = $post_id && get_post_meta( $post_id, Jadlospisy_Post_Type::META_AUTO, true );

		// Tytuł z automatu, którego redaktor nie ruszał, aktualizujemy razem z datami.
		if ( '' === $title || ( $was_auto && get_post_field( 'post_title', $post_id, 'raw' ) === $title ) ) {
			$data['post_title'] = wp_slash( Jadlospisy_Repository::auto_title( $od, $do ) );
		}

		return $data;
	}

	public static function redirect( $location ) {
		if ( self::$notices ) {
			$location = add_query_arg( 'jadlospisy', implode( ',', array_unique( self::$notices ) ), $location );
		}
		return $location;
	}

	public static function notices() {
		$screen = get_current_screen();
		// phpcs:ignore WordPress.Security.NonceVerification -- tylko odczyt kodów komunikatów.
		if ( ! $screen || Jadlospisy_Post_Type::NAME !== $screen->post_type || 'post' !== $screen->base || empty( $_GET['jadlospisy'] ) ) {
			return;
		}

		$texts = array(
			'brak_pdf'   => array( 'warning', __( 'Nie wybrano pliku PDF – ten jadłospis nie pokaże się na stronie, dopóki go nie dodasz.', 'jadlospisy' ) ),
			'brak_dat'   => array( 'warning', __( 'Uzupełnij obie daty – bez nich jadłospis nie pokaże się na stronie.', 'jadlospisy' ) ),
			'zamienione' => array( 'info', __( 'Data końcowa była wcześniejsza niż początkowa, więc zamieniliśmy je miejscami. Sprawdź, czy okres się zgadza.', 'jadlospisy' ) ),
			'nakladanie' => array( 'info', __( 'Ten jadłospis nakłada się datami na inny opublikowany jadłospis. Jako aktualny pokaże się ten, który zaczyna się później.', 'jadlospisy' ) ),
		);

		// phpcs:ignore WordPress.Security.NonceVerification
		$codes = explode( ',', sanitize_text_field( wp_unslash( $_GET['jadlospisy'] ) ) );
		foreach ( $codes as $code ) {
			if ( isset( $texts[ $code ] ) ) {
				printf(
					'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
					esc_attr( $texts[ $code ][0] ),
					esc_html( $texts[ $code ][1] )
				);
			}
		}
	}

	public static function assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || Jadlospisy_Post_Type::NAME !== $screen->post_type ) {
			return;
		}

		wp_enqueue_style( 'jadlospisy-admin', JADLOSPISY_URL . 'assets/admin.css', array(), JADLOSPISY_VERSION );

		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_script( 'jadlospisy-admin', JADLOSPISY_URL . 'assets/admin.js', array( 'jquery' ), JADLOSPISY_VERSION, true );
		wp_localize_script(
			'jadlospisy-admin',
			'jadlospisyAdmin',
			array(
				'frameTitle'  => __( 'Wybierz jadłospis w PDF', 'jadlospisy' ),
				'frameButton' => __( 'Użyj tego pliku', 'jadlospisy' ),
				'noFile'      => __( 'Nie wybrano pliku.', 'jadlospisy' ),
				'notPdf'      => __( 'Ten plik nie jest PDF-em. Wybierz plik w formacie PDF.', 'jadlospisy' ),
				/* Ile dni (łącznie z pierwszym) podpowiadać po wybraniu daty początkowej. */
				'defaultDays' => (int) apply_filters( 'jadlospisy_domyslna_dlugosc', 7 ),
			)
		);
	}

	public static function title_placeholder( $text, $post ) {
		if ( Jadlospisy_Post_Type::NAME === $post->post_type ) {
			return __( 'Tytuł (opcjonalnie – powstanie z dat)', 'jadlospisy' );
		}
		return $text;
	}

	public static function messages( $messages ) {
		$saved = __( 'Jadłospis zapisany.', 'jadlospisy' );

		$messages[ Jadlospisy_Post_Type::NAME ] = array(
			0  => '',
			1  => __( 'Jadłospis zaktualizowany.', 'jadlospisy' ),
			4  => __( 'Jadłospis zaktualizowany.', 'jadlospisy' ),
			6  => __( 'Jadłospis opublikowany.', 'jadlospisy' ),
			7  => $saved,
			8  => $saved,
			9  => __( 'Publikacja jadłospisu zaplanowana.', 'jadlospisy' ),
			10 => __( 'Szkic jadłospisu zapisany.', 'jadlospisy' ),
		);

		return $messages;
	}

	/* ------------------------------------------------------------------ */
	/* Lista jadłospisów                                                   */
	/* ------------------------------------------------------------------ */

	public static function columns( $columns ) {
		$new = array();
		foreach ( $columns as $key => $label ) {
			if ( 'date' === $key ) {
				continue;
			}
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['jadlospis_okres']  = __( 'Okres', 'jadlospisy' );
				$new['jadlospis_status'] = __( 'Na stronie', 'jadlospisy' );
				$new['jadlospis_pdf']    = __( 'PDF', 'jadlospisy' );
			}
		}
		return $new;
	}

	public static function column( $column, $post_id ) {
		switch ( $column ) {
			case 'jadlospis_okres':
				$od = get_post_meta( $post_id, Jadlospisy_Post_Type::META_OD, true );
				$do = get_post_meta( $post_id, Jadlospisy_Post_Type::META_DO, true );
				echo ( Jadlospisy_Repository::is_date( $od ) && Jadlospisy_Repository::is_date( $do ) )
					? esc_html( Jadlospisy_Repository::format_range( $od, $do ) )
					: '<span class="jadlospisy-status jadlospisy-status--brak">' . esc_html__( 'brak dat', 'jadlospisy' ) . '</span>';
				break;

			case 'jadlospis_status':
				$item = Jadlospisy_Repository::item( $post_id );
				if ( ! $item ) {
					echo '<span class="jadlospisy-status jadlospisy-status--brak">' . esc_html__( 'niekompletny', 'jadlospisy' ) . '</span>';
				} elseif ( 'publish' !== get_post_status( $post_id ) ) {
					echo '<span class="jadlospisy-status">' . esc_html__( 'nieopublikowany', 'jadlospisy' ) . '</span>';
				} else {
					$status = Jadlospisy_Repository::status( $item );
					$labels = array(
						'aktualny'    => __( 'Aktualny', 'jadlospisy' ),
						'nadchodzacy' => __( 'Nadchodzący', 'jadlospisy' ),
						'archiwalny'  => __( 'Archiwum', 'jadlospisy' ),
					);
					printf( '<span class="jadlospisy-status jadlospisy-status--%1$s">%2$s</span>', esc_attr( $status ), esc_html( $labels[ $status ] ) );
				}
				break;

			case 'jadlospis_pdf':
				$pdf_id = (int) get_post_meta( $post_id, Jadlospisy_Post_Type::META_PDF, true );
				$url    = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
				if ( $url ) {
					printf( '<a href="%1$s" target="_blank" rel="noopener">%2$s</a>', esc_url( $url ), esc_html( Jadlospisy_Repository::file_meta( $pdf_id ) ) );
				} else {
					echo '<span class="jadlospisy-status jadlospisy-status--brak">' . esc_html__( 'brak pliku', 'jadlospisy' ) . '</span>';
				}
				break;
		}
	}

	public static function sortable_columns( $columns ) {
		$columns['jadlospis_okres'] = 'jadlospis_okres';
		return $columns;
	}

	/** Lista domyślnie od najnowszego okresu; wpisy bez dat nie znikają. */
	public static function list_order( $query ) {
		if ( ! $query->is_main_query() || Jadlospisy_Post_Type::NAME !== $query->get( 'post_type' ) ) {
			return;
		}

		$orderby = $query->get( 'orderby' );
		if ( '' !== $orderby && 'jadlospis_okres' !== $orderby ) {
			return;
		}

		$order = 'ASC' === strtoupper( (string) $query->get( 'order' ) ) ? 'ASC' : 'DESC';

		$query->set(
			'meta_query',
			array(
				'relation' => 'OR',
				'okres'    => array(
					'key'     => Jadlospisy_Post_Type::META_OD,
					'compare' => 'EXISTS',
				),
				array(
					'key'     => Jadlospisy_Post_Type::META_OD,
					'compare' => 'NOT EXISTS',
				),
			)
		);
		$query->set(
			'orderby',
			array(
				'okres' => $order,
				'date'  => $order,
			)
		);
	}
}
