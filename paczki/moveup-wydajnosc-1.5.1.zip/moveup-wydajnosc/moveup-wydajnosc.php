<?php
/**
 * Plugin Name: moveUP – Wydajność
 * Description: Poprawki szybkości strony, których nie da się ustawić w panelu: własne, odchudzone fonty strony z wp-content/uploads/moveup-wydajnosc/fonty/fonty.json (albo – gdy tego folderu nie ma – z assets/fonty/ wtyczki) (@font-face w <head> zamiast osobnego CSS motywu Kadence), bez preloadu fontów Kadence, defer dla skryptów Kadence na końcu strony (animacje AOS, akordeon), małe pliki CSS z serwera strony wpisane w kod strony (bez kilkunastu zapytań blokujących wyświetlanie), preload obrazu LCP (np. tła hero) i limit wpisywanego CSS z wp-content/uploads/moveup-wydajnosc/ustawienia.json.
 * Version: 1.5.1
 * Author: moveUP Agency
 * Text Domain: moveup-wydajnosc
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-wydajnosc' );

define( 'MU_WYD_VER', '1.5.1' );

/**
 * Folder fontów: najpierw folder strony wp-content/uploads/moveup-wydajnosc/fonty/ (pliki tej strony – aktualizacje
 * wtyczki go nie ruszają), a gdy go nie ma – assets/fonty/ wtyczki (jak do wersji 1.3). Zwraca [ścieżka, adres URL].
 */
function mu_wyd_fonty_folder() {
	static $folder = null;
	if ( null === $folder ) {
		$up     = wp_upload_dir( null, false );
		$strona = trailingslashit( $up['basedir'] ) . 'moveup-wydajnosc/fonty/';
		$folder = file_exists( $strona . 'fonty.json' )
			? array( $strona, trailingslashit( $up['baseurl'] ) . 'moveup-wydajnosc/fonty/' )
			: array( __DIR__ . '/assets/fonty/', plugins_url( 'assets/fonty/', __FILE__ ) );
		$folder = apply_filters( 'moveup_wydajnosc_fonty_folder', $folder );
	}
	return $folder;
}

/**
 * Fonty strony z fonty.json w folderze fontów: [{ family, style, weight, file, preload? }].
 * Pliki to fonty zmienne przycięte do znaków potrzebnych po polsku (jeden plik na krój) – patrz readme.txt.
 * Pusta lista = fonty zostają takie, jak ustawił motyw.
 */
function mu_wyd_fonty() {
	static $fonty = null;
	if ( null === $fonty ) {
		$plik  = mu_wyd_fonty_folder()[0] . 'fonty.json';
		$fonty = file_exists( $plik ) ? json_decode( (string) file_get_contents( $plik ), true ) : array();
		$fonty = apply_filters( 'moveup_wydajnosc_fonty', is_array( $fonty ) ? $fonty : array() );
	}
	return $fonty;
}

/**
 * Ustawienia tej strony z wp-content/uploads/moveup-wydajnosc/ustawienia.json (folder strony – aktualizacje wtyczki go nie ruszają):
 * {
 *   "inline_css_limit": 18000,                 // limit pliku CSS wpisywanego w stronę (bajty), domyślnie 15000
 *   "defer": ["kadence-blocks-advanced-form"],  // dodatkowe skrypty (uchwyty) z defer – tylko te, które same czekają na DOMContentLoaded
 *   "preload_obrazy": [                        // obrazy LCP odkrywane dopiero z CSS (np. tło hero) – <link rel="preload"> na górze <head>
 *     { "href": "2025/07/hero-mobile.svg",     // względem folderu uploads albo pełny adres
 *       "media": "(max-width: 767px)",         // opcjonalnie
 *       "strony": "glowna" }                   // "glowna" (domyślnie), "wszystkie" albo lista ID stron
 *   ]
 * }
 * Brak pliku = zachowanie jak w 1.4.
 */
function mu_wyd_ustawienia() {
	static $u = null;
	if ( null === $u ) {
		$plik = trailingslashit( wp_upload_dir( null, false )['basedir'] ) . 'moveup-wydajnosc/ustawienia.json';
		$u    = file_exists( $plik ) ? json_decode( (string) file_get_contents( $plik ), true ) : array();
		$u    = apply_filters( 'moveup_wydajnosc_ustawienia', is_array( $u ) ? $u : array() );
	}
	return $u;
}

add_action( 'wp_head', 'mu_wyd_preload_obrazy', 1 );

function mu_wyd_preload_obrazy() {
	$baza = trailingslashit( wp_upload_dir( null, false )['baseurl'] );
	foreach ( (array) ( mu_wyd_ustawienia()['preload_obrazy'] ?? array() ) as $o ) {
		if ( empty( $o['href'] ) ) {
			continue;
		}
		$strony = $o['strony'] ?? 'glowna';
		if ( 'glowna' === $strony && ! is_front_page() ) {
			continue;
		}
		if ( is_array( $strony ) && ! is_page( array_map( 'intval', $strony ) ) ) {
			continue;
		}
		$href = preg_match( '~^https?://~', $o['href'] ) ? $o['href'] : $baza . ltrim( $o['href'], '/' );
		printf(
			'<link rel="preload" as="image" href="%s"%s fetchpriority="high">' . "\n",
			esc_url( $href ),
			empty( $o['media'] ) ? '' : ' media="' . esc_attr( $o['media'] ) . '"'
		);
	}
}

add_action( 'init', function () {
	if ( ! mu_wyd_fonty() ) {
		return;
	}
	// Kadence: bez preloadu i bez własnego pliku CSS z fontami – zastępuje je @font-face poniżej.
	add_filter( 'kadence_local_fonts_preload', '__return_false' );
	add_filter( 'style_loader_tag', function ( $tag, $handle ) {
		return 'kadence-fonts-gfonts' === $handle ? '' : $tag;
	}, 10, 2 );
	add_action( 'wp_head', 'mu_wyd_font_face', 2 );
} );

function mu_wyd_font_face() {
	$url = mu_wyd_fonty_folder()[1];
	$css = '';
	foreach ( mu_wyd_fonty() as $f ) {
		if ( empty( $f['family'] ) || empty( $f['file'] ) ) {
			continue;
		}
		if ( ! empty( $f['preload'] ) ) { // tylko font tekstu z pierwszego ekranu – każdy preload zabiera łącze CSS-owi
			printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $url . $f['file'] . '?ver=' . MU_WYD_VER ) );
		}
		$css .= sprintf(
			"@font-face{font-family:'%s';font-style:%s;font-weight:%s;font-display:swap;src:url(%s) format('woff2')}",
			esc_attr( $f['family'] ),
			esc_attr( $f['style'] ?? 'normal' ),
			esc_attr( $f['weight'] ?? '400' ),
			esc_url( $url . $f['file'] . '?ver=' . MU_WYD_VER )
		);
	}
	if ( $css ) {
		echo '<style id="moveup-fonty">' . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- wartości oczyszczone wyżej
	}
}

// Skrypty na końcu strony, które same czekają na DOMContentLoaded – defer zamiast blokowania parsera.
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	$defer = apply_filters( 'moveup_wydajnosc_defer', array_merge( array( 'kadence-aos', 'kadence-blocks-accordion' ), (array) ( mu_wyd_ustawienia()['defer'] ?? array() ) ) );
	if ( in_array( $handle, $defer, true ) && false === strpos( $tag, ' defer' ) && false === strpos( $tag, ' async' ) ) {
		$tag = str_replace( ' src=', ' defer src=', $tag );
	}
	return $tag;
}, 10, 2 );

/**
 * Małe arkusze CSS z serwera strony (motyw, bloki Kadence, własne wtyczki) wpisane w <style> w miejscu <link>.
 * Kadence ładuje kilkanaście plików po 1–6 KB – każdy to osobne zapytanie blokujące wyświetlanie strony.
 * Kolejność stylów się nie zmienia (ten sam punkt w kodzie), więc wygląd zostaje – w odróżnieniu od łączenia
 * i minifikacji CSS w LiteSpeed, które przy Kadence psuło układ. Ścieżki url(…) są zamieniane na adresy bezwzględne.
 * Limit rozmiaru pliku: filtr moveup_wydajnosc_inline_css_limit (bajty, 0 = wyłączone), wyjątki: moveup_wydajnosc_inline_css_bez.
 */
add_filter( 'style_loader_tag', 'mu_wyd_inline_css', 20, 4 );

function mu_wyd_inline_css( $tag, $handle, $href, $media ) {
	if ( is_admin() || is_customize_preview() || '' === $tag || ! $href ) {
		return $tag;
	}
	$limit = (int) apply_filters( 'moveup_wydajnosc_inline_css_limit', (int) ( mu_wyd_ustawienia()['inline_css_limit'] ?? 15000 ) );
	$bez   = (array) apply_filters( 'moveup_wydajnosc_inline_css_bez', array() );
	if ( $limit <= 0 || in_array( $handle, $bez, true ) || ! in_array( $media, array( 'all', 'screen', '' ), true ) ) {
		return $tag;
	}
	$plik = mu_wyd_sciezka( $href );
	if ( ! $plik || ! is_readable( $plik ) || filesize( $plik ) > $limit ) {
		return $tag;
	}
	$css = (string) file_get_contents( $plik );
	if ( '' === trim( $css ) || false !== stripos( $css, '</style' ) ) {
		return $tag;
	}
	// url(względny) → adres bezwzględny względem katalogu pliku CSS
	$baza = trailingslashit( dirname( strtok( $href, '?' ) ) );
	$css  = preg_replace_callback( '/url\(\s*([\'"]?)(?!data:|https?:|\/\/|\/|#)([^\'")]+)\1\s*\)/i', function ( $m ) use ( $baza ) {
		return 'url(' . $m[1] . $baza . $m[2] . $m[1] . ')';
	}, $css );
	if ( null !== $css ) {
		$css = preg_replace( '~/\*# sourceMappingURL=[^*]*\*/~', '', $css );
	}
	if ( null === $css || '' === trim( $css ) ) { // błąd wyrażenia – zostaje zwykły <link>
		return $tag;
	}
	return sprintf( '<style id="%s-css"%s>%s</style>' . "\n", esc_attr( $handle ), 'all' === $media || '' === $media ? '' : ' media="' . esc_attr( $media ) . '"', $css );
}

/** Adres pliku z serwera strony → ścieżka na dysku (tylko wp-content i wp-includes, bez plików zewnętrznych). */
function mu_wyd_sciezka( $href ) {
	$url = strtok( set_url_scheme( $href, 'https' ), '?' );
	$map = array(
		set_url_scheme( content_url( '/' ), 'https' )  => trailingslashit( WP_CONTENT_DIR ),
		set_url_scheme( includes_url( '/' ), 'https' ) => trailingslashit( ABSPATH . WPINC ),
	);
	foreach ( $map as $u => $d ) {
		if ( 0 === strpos( $url, $u ) ) {
			$sc = realpath( $d . substr( $url, strlen( $u ) ) );
			return ( $sc && 0 === strpos( $sc, realpath( $d ) ) && '.css' === substr( $sc, -4 ) ) ? $sc : '';
		}
	}
	return '';
}
