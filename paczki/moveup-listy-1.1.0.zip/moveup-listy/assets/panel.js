/* moveUP – Listy: panel listy (karty wpisów, kategorie, wklejanie z tekstu). Dane: window.mulKonfig, zapis: ukryte pole JSON. */
( function () {
	'use strict';
	var K = window.mulKonfig, P = window.muListyParser;
	if ( ! K || ! P ) { return; }

	var licznik = 0;
	var stan = {
		kategorie: ( K.dane.kategorie || [] ).map( function ( k ) { return Object.assign( {}, k ); } ),
		wpisy: ( K.dane.wpisy || [] ).map( function ( w ) { return Object.assign( { _id: ++licznik }, w ); } ),
		filtr: '',
		szukaj: '',
		otwarte: {},
		zmiany: false
	};
	if ( K.kategorie && stan.kategorie.length ) { stan.filtr = stan.kategorie[0].id; }

	// pola listy (z ustawień): tablica w kolejności; podgląd karty – pierwsze pola tekstowe/daty
	var POLA = K.pola || [];
	var DEF = {};
	POLA.forEach( function ( p ) { DEF[ p.klucz ] = p; } );
	var GLOWNE = POLA.slice().sort( function ( a, b ) { return ( +a.linia || 0 ) - ( +b.linia || 0 ); } )
		.filter( function ( p ) { return p.typ === 'tekst' || p.typ === 'data'; } ).slice( 0, 3 ).map( function ( p ) { return p.klucz; } );
	function polaWpisu( w ) { return P.polaKategorii( POLA, K.kategorie ? w.k : '' ); }

	var $ = function ( s, r ) { return ( r || document ).querySelector( s ); };
	var el = function ( tag, atr, dzieci ) {
		var e = document.createElement( tag );
		Object.keys( atr || {} ).forEach( function ( k ) {
			if ( k === 'text' ) { e.textContent = atr[k]; }
			else if ( k.indexOf( 'on' ) === 0 ) { e.addEventListener( k.slice( 2 ), atr[k] ); }
			else if ( atr[k] !== false && atr[k] !== null && atr[k] !== undefined ) { e.setAttribute( k, atr[k] === true ? '' : atr[k] ); }
		} );
		( dzieci || [] ).forEach( function ( d ) { if ( d ) { e.appendChild( typeof d === 'string' ? document.createTextNode( d ) : d ); } } );
		return e;
	};

	function zmieniono() {
		stan.zmiany = true;
		$( '#mul-stan' ).textContent = 'Masz niezapisane zmiany';
	}
	window.addEventListener( 'beforeunload', function ( e ) { if ( stan.zmiany ) { e.preventDefault(); e.returnValue = ''; } } );

	function nazwaKat( id ) {
		for ( var i = 0; i < stan.kategorie.length; i++ ) { if ( stan.kategorie[i].id === id ) { return stan.kategorie[i].nazwa; } }
		return '';
	}
	function widoczny( w ) {
		if ( K.kategorie && stan.filtr && w.k !== stan.filtr ) { return false; }
		if ( stan.szukaj ) {
			var t = POLA.map( function ( p ) { return w[ p.klucz ] || ''; } ).join( ' ' ).toLowerCase();
			return t.indexOf( stan.szukaj ) > -1;
		}
		return true;
	}
	function podsumowanie( w ) {
		var g = GLOWNE.map( function ( k ) { return w[k]; } ).filter( Boolean );
		return g.length ? g.join( ' · ' ) : '(nowy wpis)';
	}

	/* ---------- filtr kategorii ---------- */
	function rysujFiltr() {
		var f = $( '#mul-filtr' );
		if ( ! f ) { return; }
		f.innerHTML = '';
		var przycisk = function ( id, nazwa, n ) {
			return el( 'button', { type: 'button', class: 'button' + ( stan.filtr === id ? ' button-primary' : '' ), 'aria-pressed': stan.filtr === id ? 'true' : 'false', onclick: function () { stan.filtr = id; rysuj(); } }, [ nazwa + ' (' + n + ')' ] );
		};
		stan.kategorie.forEach( function ( k ) {
			f.appendChild( przycisk( k.id, k.nazwa, stan.wpisy.filter( function ( w ) { return w.k === k.id; } ).length ) );
		} );
		f.appendChild( przycisk( '', 'Wszystkie', stan.wpisy.length ) );
		var akt = f.querySelector( '.button-primary' );
		if ( akt && f.scrollWidth > f.clientWidth ) { f.scrollLeft = akt.offsetLeft - 12; }
	}

	/* ---------- karty wpisów ---------- */
	/* Format pola daty: „dzien” (kropki przy wpisywaniu + kalendarz) albo „rok” (dowolny tekst: 2025, od 2015, listopad 2019).
	   Starsze ustawienia bez formatu: „rok”, gdy nazwa pola zawiera „rok”. */
	function formatDaty( def ) {
		if ( def.format === 'rok' || def.format === 'dzien' ) { return def.format; }
		return /rok/i.test( def.etykieta || '' ) ? 'rok' : 'dzien';
	}
	var SCHEMAT = /^[a-z][a-z0-9+.\-]*:/i;

	function pole( w, klucz, def ) {
		var id = 'mul-' + w._id + '-' + klucz;
		var wiele = def.typ === 'linie' || def.typ === 'linki';
		var dzien = def.typ === 'data' && formatDaty( def ) === 'dzien';
		var input;
		var zapisz = function () {
			w[klucz] = input.value;
			var s = input.closest( '.mul-karta' ).querySelector( '.mul-pods' );
			if ( s ) { s.textContent = podsumowanie( w ); }
			zmieniono();
		};
		var kursorNaKoniec = function () { try { input.setSelectionRange( input.value.length, input.value.length ); } catch ( x ) {} };
		input = el( wiele ? 'textarea' : 'input', {
			id: id,
			class: 'large-text',
			type: wiele ? null : ( def.typ === 'url' ? 'url' : 'text' ),
			rows: wiele ? 3 : null,
			inputmode: def.typ === 'url' ? 'url' : null,
			autocomplete: 'off',
			placeholder: def.typ === 'url' ? 'https://' : ( def.typ === 'data' ? ( dzien ? 'dd.mm.rrrr' : 'np. 2025' ) : null ),
			oninput: function ( e ) {
				var v = input.value;
				if ( def.typ === 'url' && e.inputType === 'insertText' && v && ! SCHEMAT.test( v ) && 'https://'.indexOf( v.toLowerCase() ) !== 0 && 'http://'.indexOf( v.toLowerCase() ) !== 0 ) {
					// wpisywanie (nie wklejanie): adres od razu z https://
					input.value = 'https://' + v;
					kursorNaKoniec();
				}
				if ( dzien && e.inputType === 'insertText' && e.data ) {
					if ( /^\d$/.test( e.data ) && ( /^\d{2}$/.test( v ) || /^\d{2}\.\d{2}$/.test( v ) ) ) {
						input.value = v + '.';              // po dniu i miesiącu – kropka
					} else if ( /[\-\/.]/.test( e.data ) && /\.[\-\/.]$/.test( v ) ) {
						// tuż po automatycznej kropce: „-” zamienia ją (zakres 09-10.12.2024), druga kropka/ukośnik – bez dubla
						input.value = e.data === '-' ? v.slice( 0, -2 ) + '-' : v.slice( 0, -1 );
					}
					kursorNaKoniec();
				}
				zapisz();
			},
			onblur: function () {
				var v = input.value.trim();
				if ( def.typ === 'url' ) {
					v = v.replace( /\s+/g, '' );
					if ( v === 'https://' || v === 'http://' ) { v = ''; }
					else if ( v && ! SCHEMAT.test( v ) ) { v = 'https://' + v.replace( /^\/+/, '' ); }
				}
				if ( def.typ === 'data' && v ) { v = P.normalizujDate( v.replace( /\.$/, '' ) ); }
				if ( v !== input.value ) { input.value = v; zapisz(); }
			}
		} );
		input.value = w[klucz] || '';
		var pole = input;
		if ( dzien ) {
			// kalendarz: ukryte <input type="date"> + przycisk; wybór → dd.mm.rrrr
			var wybor = el( 'input', { type: 'date', class: 'mul-data-wybor', tabindex: '-1', 'aria-hidden': 'true', onchange: function ( e ) {
				var m = String( e.target.value ).match( /^(\d{4})-(\d{2})-(\d{2})$/ );
				if ( m ) { input.value = m[3] + '.' + m[2] + '.' + m[1]; zapisz(); input.focus(); }
			} } );
			var przycisk = el( 'button', { type: 'button', class: 'mul-kalendarz', 'aria-label': 'Wybierz datę z kalendarza', title: 'Wybierz z kalendarza', onclick: function () {
				var m = input.value.match( /(\d{1,2})\.(\d{1,2})\.(\d{4})/ );
				wybor.value = m ? m[3] + '-' + ( '0' + m[2] ).slice( -2 ) + '-' + ( '0' + m[1] ).slice( -2 ) : '';
				try { wybor.showPicker(); } catch ( x ) { wybor.focus(); wybor.click(); }
			} }, [ el( 'span', { class: 'dashicons dashicons-calendar-alt', 'aria-hidden': 'true' } ) ] );
			pole = el( 'span', { class: 'mul-data' }, [ input, przycisk, wybor ] );
		}
		return el( 'p', { class: 'mul-pole mul-pole-' + def.typ }, [
			el( 'label', { for: id, text: def.etykieta } ),
			pole,
			def.pomoc ? el( 'span', { class: 'description', text: def.pomoc } ) : null
		] );
	}

	function przesun( w, kier, fokus ) {
		var i = stan.wpisy.indexOf( w );
		var j = i + kier;
		while ( j >= 0 && j < stan.wpisy.length && ! widoczny( stan.wpisy[j] ) ) { j += kier; }
		if ( j < 0 || j >= stan.wpisy.length ) { return; }
		stan.wpisy.splice( i, 1 );
		stan.wpisy.splice( j, 0, w );
		zmieniono();
		rysuj();
		var b = document.querySelector( '[data-karta="' + w._id + '"] ' + ( fokus || '[data-kier="' + kier + '"]' ) );
		if ( b ) { b.focus(); }
	}

	function karta( w, nr ) {
		var otwarta = !! stan.otwarte[ w._id ];
		var cialo = el( 'div', { class: 'mul-cialo', hidden: ! otwarta } );
		polaWpisu( w ).forEach( function ( p ) { cialo.appendChild( pole( w, p.klucz, p ) ); } );
		var akcje = el( 'div', { class: 'mul-akcje' }, [
			K.kategorie ? ( function () {
				var s = el( 'select', { 'aria-label': 'Kategoria', onchange: function ( e ) { w.k = e.target.value; zmieniono(); rysuj(); } } );
				stan.kategorie.forEach( function ( k ) { var o = el( 'option', { value: k.id, text: k.nazwa } ); if ( k.id === w.k ) { o.selected = true; } s.appendChild( o ); } );
				return s;
			}() ) : null,
			el( 'button', { type: 'button', class: 'button', 'data-kier': '-1', 'aria-label': 'Przesuń wyżej', title: 'Wyżej', onclick: function () { przesun( w, -1 ); } }, [ '↑' ] ),
			el( 'button', { type: 'button', class: 'button', 'data-kier': '1', 'aria-label': 'Przesuń niżej', title: 'Niżej', onclick: function () { przesun( w, 1 ); } }, [ '↓' ] ),
			el( 'button', { type: 'button', class: 'button-link button-link-delete', onclick: function () {
				if ( ! window.confirm( 'Usunąć wpis „' + podsumowanie( w ) + '”?' ) ) { return; }
				stan.wpisy.splice( stan.wpisy.indexOf( w ), 1 ); zmieniono(); rysuj();
			} }, [ 'Usuń' ] )
		] );
		var naglowek = el( 'button', { type: 'button', class: 'mul-naglowek', 'aria-expanded': otwarta ? 'true' : 'false', onclick: function ( e ) {
			stan.otwarte[ w._id ] = ! stan.otwarte[ w._id ];
			cialo.hidden = ! stan.otwarte[ w._id ];
			e.currentTarget.setAttribute( 'aria-expanded', stan.otwarte[ w._id ] ? 'true' : 'false' );
		} }, [ el( 'span', { class: 'mul-nr', text: nr + '.' } ), el( 'span', { class: 'mul-pods', text: podsumowanie( w ) } ), el( 'span', { class: 'mul-edytuj', text: 'Edytuj' } ) ] );
		var uchwyt = el( 'button', { type: 'button', class: 'mul-uchwyt', 'aria-label': 'Przeciągnij, żeby zmienić kolejność (na klawiaturze: strzałki w górę i w dół)', title: 'Przeciągnij, żeby zmienić kolejność', onkeydown: function ( e ) {
			if ( e.key === 'ArrowUp' || e.key === 'ArrowDown' ) { e.preventDefault(); przesun( w, e.key === 'ArrowUp' ? -1 : 1, '.mul-uchwyt' ); }
		} }, [ el( 'span', { class: 'dashicons dashicons-menu', 'aria-hidden': 'true' } ) ] );
		return el( 'article', { class: 'mul-karta', 'data-karta': w._id }, [ el( 'div', { class: 'mul-gora' }, [ uchwyt, naglowek, akcje ] ), cialo ] );
	}

	function rysujWpisy() {
		var box = $( '#mul-wpisy' );
		box.innerHTML = '';
		var nr = 0;
		stan.wpisy.forEach( function ( w ) {
			if ( ! widoczny( w ) ) { return; }
			box.appendChild( karta( w, ++nr ) );
		} );
		if ( ! nr ) { box.appendChild( el( 'p', { class: 'mul-pusto', text: stan.szukaj ? 'Nic nie znaleziono.' : 'Brak wpisów – dodaj pierwszy albo wklej listę z tekstu.' } ) ); }
	}

	/* ---------- przeciąganie kart za uchwyt (mysz i dotyk – zdarzenia pointer) ---------- */
	var ciag = null;
	function wpisPoId( id ) { for ( var i = 0; i < stan.wpisy.length; i++ ) { if ( String( stan.wpisy[i]._id ) === String( id ) ) { return stan.wpisy[i]; } } return null; }
	document.addEventListener( 'pointerdown', function ( e ) {
		var u = e.target.closest( '.mul-uchwyt' );
		if ( ! u || ( e.pointerType === 'mouse' && e.button !== 0 ) ) { return; }
		var karta = u.closest( '.mul-karta' );
		var r = karta.getBoundingClientRect();
		e.preventDefault();
		var miejsce = el( 'div', { class: 'mul-miejsce' } );
		miejsce.style.height = r.height + 'px';
		karta.parentNode.insertBefore( miejsce, karta );
		karta.classList.add( 'mul-ciagniety' );
		karta.style.width = r.width + 'px';
		karta.style.left = r.left + 'px';
		karta.style.top = r.top + 'px';
		ciag = { karta: karta, miejsce: miejsce, dy: e.clientY - r.top, y: e.clientY, y0: e.clientY, uchwyt: u, id: e.pointerId };
		try { u.setPointerCapture( e.pointerId ); } catch ( x ) {}
		( function przewijaj() {
			if ( ! ciag ) { return; }
			// przewijanie przy krawędzi ekranu – dopiero po przesunięciu o 24 px w jej stronę (nie od razu po chwyceniu)
			var krok = ciag.y < 90 && ciag.y < ciag.y0 - 24 ? -14 : ( ciag.y > window.innerHeight - 90 && ciag.y > ciag.y0 + 24 ? 14 : 0 );
			if ( krok ) { window.scrollBy( 0, krok ); ustawMiejsce(); }
			window.requestAnimationFrame( przewijaj );
		}() );
	} );
	function ustawMiejsce() {
		var karty = [].slice.call( document.querySelectorAll( '#mul-wpisy .mul-karta:not(.mul-ciagniety)' ) );
		for ( var i = 0; i < karty.length; i++ ) {
			var r = karty[i].getBoundingClientRect();
			if ( ciag.y < r.top + r.height / 2 ) { karty[i].parentNode.insertBefore( ciag.miejsce, karty[i] ); return; }
		}
		if ( karty.length ) { karty[ karty.length - 1 ].after( ciag.miejsce ); }
	}
	document.addEventListener( 'pointermove', function ( e ) {
		if ( ! ciag || e.pointerId !== ciag.id ) { return; }
		e.preventDefault();
		ciag.y = e.clientY;
		ciag.karta.style.top = ( e.clientY - ciag.dy ) + 'px';
		ustawMiejsce();
	} );
	function koniec( e ) {
		if ( ! ciag || e.pointerId !== ciag.id ) { return; }
		var c = ciag; ciag = null;
		var w = wpisPoId( c.karta.getAttribute( 'data-karta' ) );
		var nast = c.miejsce.nextElementSibling;
		while ( nast && ( ! nast.classList.contains( 'mul-karta' ) || nast === c.karta ) ) { nast = nast.nextElementSibling; }
		var poprz = c.miejsce.previousElementSibling;
		while ( poprz && ( ! poprz.classList.contains( 'mul-karta' ) || poprz === c.karta ) ) { poprz = poprz.previousElementSibling; }
		var stara = stan.wpisy.indexOf( w );
		stan.wpisy.splice( stara, 1 );
		var cel = nast ? stan.wpisy.indexOf( wpisPoId( nast.getAttribute( 'data-karta' ) ) ) : ( poprz ? stan.wpisy.indexOf( wpisPoId( poprz.getAttribute( 'data-karta' ) ) ) + 1 : stara );
		stan.wpisy.splice( cel, 0, w );
		if ( cel !== stara ) { zmieniono(); }
		rysuj();
		var u = document.querySelector( '[data-karta="' + w._id + '"] .mul-uchwyt' );
		if ( u ) { u.focus( { preventScroll: true } ); }
	}
	document.addEventListener( 'pointerup', koniec );
	document.addEventListener( 'pointercancel', koniec );

	/* ---------- kategorie ---------- */
	/** Nowa kategoria na wybranym miejscu (po indeksie; -1 = na końcu) – pole nazwy od razu do wpisania. */
	function dodajKategorie( po ) {
		var id = 'kat-' + Date.now().toString( 36 );
		var gdzie = po < 0 ? stan.kategorie.length : po + 1;
		stan.kategorie.splice( gdzie, 0, { id: id, nazwa: 'Nowa kategoria', naglowek: '' } );
		zmieniono(); rysuj();
		var p = document.querySelectorAll( '#mul-kat-lista .mul-kat' )[ gdzie ].querySelector( 'input' );
		p.focus(); p.select();
	}

	function rysujKategorie() {
		var box = $( '#mul-kat-lista' );
		if ( ! box ) { return; }
		box.innerHTML = '';
		stan.kategorie.forEach( function ( k, i ) {
			var n = stan.wpisy.filter( function ( w ) { return w.k === k.id; } ).length;
			var wiersz = el( 'div', { class: 'mul-kat' }, [
				el( 'p', { class: 'mul-pole' }, [ el( 'label', { for: 'mul-kn-' + i, text: K.zakladki ? 'Nazwa (tytuł zakładki)' : 'Nazwa' } ), el( 'input', { id: 'mul-kn-' + i, class: 'large-text', type: 'text', value: k.nazwa, oninput: function ( e ) { k.nazwa = e.target.value; zmieniono(); rysujFiltr(); } } ) ] ),
				el( 'p', { class: 'mul-pole' }, [ el( 'label', { for: 'mul-kh-' + i, text: K.zakladki ? 'Nagłówek nad listą' : 'Nagłówek grupy (opcjonalnie)' } ), el( 'input', { id: 'mul-kh-' + i, class: 'large-text', type: 'text', value: k.naglowek || '', oninput: function ( e ) { k.naglowek = e.target.value; zmieniono(); } } ) ] ),
				el( 'div', { class: 'mul-akcje' }, [
					el( 'span', { class: 'mul-ile', text: ( i + 1 ) + '. · ' + n + ' wpisów' } ),
					el( 'button', { type: 'button', class: 'button', title: 'Nowa kategoria zaraz pod tą (na ' + ( i + 2 ) + '. miejscu)', onclick: function () { dodajKategorie( i ); } }, [ '+ Dodaj poniżej' ] ),
					el( 'button', { type: 'button', class: 'button', 'aria-label': 'Kategoria wyżej', disabled: i === 0, onclick: function () { stan.kategorie.splice( i - 1, 0, stan.kategorie.splice( i, 1 )[0] ); zmieniono(); rysuj(); } }, [ '↑' ] ),
					el( 'button', { type: 'button', class: 'button', 'aria-label': 'Kategoria niżej', disabled: i === stan.kategorie.length - 1, onclick: function () { stan.kategorie.splice( i + 1, 0, stan.kategorie.splice( i, 1 )[0] ); zmieniono(); rysuj(); } }, [ '↓' ] ),
					el( 'button', { type: 'button', class: 'button-link button-link-delete', disabled: n > 0, title: n > 0 ? 'Najpierw przenieś albo usuń wpisy tej kategorii' : '', onclick: function () {
						if ( window.confirm( 'Usunąć kategorię „' + k.nazwa + '”?' ) ) { stan.kategorie.splice( i, 1 ); if ( stan.filtr === k.id ) { stan.filtr = stan.kategorie.length ? stan.kategorie[0].id : ''; } zmieniono(); rysuj(); }
					} }, [ 'Usuń' ] )
				] )
			] );
			box.appendChild( wiersz );
		} );
		var sel = $( '#mul-wklej-kat' );
		if ( sel ) {
			var b = sel.value;
			sel.innerHTML = '';
			stan.kategorie.forEach( function ( k ) { sel.appendChild( el( 'option', { value: k.id, text: k.nazwa } ) ); } );
			sel.value = b || stan.filtr || ( stan.kategorie[0] && stan.kategorie[0].id ) || '';
		}
	}

	function rysuj() {
		var c = $( '[data-mul="cofnij"]' );
		if ( c ) { c.disabled = ! historia.length; }
		rysujFiltr();
		rysujKategorie();
		rysujWpisy();
	}

	/* ---------- dodawanie, sortowanie ---------- */
	function wstaw( wpisy, kat, tryb ) {
		if ( tryb === 'zastap' ) {
			stan.wpisy = stan.wpisy.filter( function ( w ) { return K.kategorie ? w.k !== kat : false; } );
		}
		var idx = -1;
		stan.wpisy.forEach( function ( w, i ) {
			if ( ! K.kategorie || w.k === kat ) {
				if ( tryb === 'dol' ) { idx = i + 1; } else if ( idx === -1 ) { idx = i; }
			}
		} );
		if ( idx === -1 ) { idx = tryb === 'dol' ? stan.wpisy.length : 0; }
		Array.prototype.splice.apply( stan.wpisy, [ idx, 0 ].concat( wpisy ) );
		zmieniono();
	}

	function nowyWpis() {
		var w = { _id: ++licznik, k: K.kategorie ? ( stan.filtr || ( stan.kategorie[0] && stan.kategorie[0].id ) || '' ) : '' };
		POLA.forEach( function ( p ) { w[ p.klucz ] = ''; } );
		stan.szukaj = '';
		var s = $( '[data-mul="szukaj"]' ); if ( s ) { s.value = ''; }
		wstaw( [ w ], w.k, 'gora' );
		stan.otwarte[ w._id ] = true;
		rysuj();
		var f = document.querySelector( '[data-karta="' + w._id + '"] input, [data-karta="' + w._id + '"] textarea' );
		if ( f ) { f.focus(); }
	}

	/* Sortowanie widocznych wpisów (wybrana kategoria) w ich miejscach na liście. Przed każdym sortowaniem kolejność
	   trafia do historii – „Cofnij sortowanie” przywraca ją krok po kroku (wpisy dodane w międzyczasie zostają na górze). */
	var historia = [];
	var porownajTekst = function ( a, b ) { return String( a || '' ).localeCompare( String( b || '' ), 'pl', { sensitivity: 'base' } ); };
	function sortuj( tryb ) {
		var sloty = [], grupa = [];
		stan.wpisy.forEach( function ( w, i ) { if ( widoczny( w ) ) { sloty.push( i ); grupa.push( w ); } } );
		if ( grupa.length < 2 ) { return; }
		historia.push( stan.wpisy.slice() );
		var dane = grupa.map( function ( w, i ) { return { w: w, i: i, k: P.kluczDaty( w[ K.poleDaty ] ) }; } );
		dane.sort( function ( a, b ) {
			if ( tryb !== 'data' ) {
				// najpierw wybrane pole alfabetycznie (bez wielkości liter), w ramach tej samej wartości od najnowszych
				var m = porownajTekst( a.w[ tryb ], b.w[ tryb ] );
				if ( m ) { return m; }
			}
			return b.k - a.k || a.i - b.i;
		} );
		dane.forEach( function ( x, i ) { stan.wpisy[ sloty[i] ] = x.w; } );
		zmieniono();
		rysuj();
		$( '#mul-stan' ).textContent = ( tryb !== 'data' ? 'Ułożono po polu „' + ( DEF[ tryb ] ? DEF[ tryb ].etykieta : tryb ) + '”' : 'Ułożono od najnowszych' ) + ' – „Cofnij sortowanie” przywróci poprzednią kolejność';
	}
	function cofnijSortowanie() {
		var poprzednia = historia.pop();
		if ( ! poprzednia ) { return; }
		var teraz = stan.wpisy;
		var nowe = teraz.filter( function ( w ) { return poprzednia.indexOf( w ) === -1; } );   // dodane po sortowaniu
		var stare = poprzednia.filter( function ( w ) { return teraz.indexOf( w ) > -1; } );    // bez usuniętych po sortowaniu
		stan.wpisy = nowe.concat( stare );
		zmieniono();
		rysuj();
		$( '#mul-stan' ).textContent = 'Przywrócono kolejność sprzed sortowania';
	}

	/* ---------- wklejanie ---------- */
	var rozpoznane = [];
	function podglad() {
		var tekst = $( '#mul-tekst' ).value;
		var kat = $( '#mul-wklej-kat' ) ? $( '#mul-wklej-kat' ).value : '';
		rozpoznane = P.rozpoznaj( tekst, POLA, stan.kategorie, kat );
		var box = $( '#mul-podglad' );
		box.innerHTML = '';
		if ( ! rozpoznane.length ) { box.appendChild( el( 'p', { text: 'Nic nie rozpoznano – wpisy oddziel pustą linią.' } ) ); return; }
		var pola = POLA.map( function ( p ) { return p.klucz; } );
		var tab = el( 'table', { class: 'widefat striped mul-tabela' } );
		var th = el( 'tr', {}, [ el( 'th', { text: 'Dodać' } ) ].concat( K.kategorie ? [ el( 'th', { text: 'Kategoria' } ) ] : [] ).concat( pola.map( function ( k ) { return el( 'th', { text: DEF[k].etykieta } ); } ) ).concat( [ el( 'th', { text: 'Do sprawdzenia' } ) ] ) );
		tab.appendChild( el( 'thead', {}, [ th ] ) );
		var tb = el( 'tbody' );
		rozpoznane.forEach( function ( r, i ) {
			r.dodaj = true;
			var cb = el( 'input', { type: 'checkbox', checked: true, 'aria-label': 'Dodać wpis ' + ( i + 1 ), onchange: function ( e ) { r.dodaj = e.target.checked; } } );
			var tr = el( 'tr', { class: r.uwagi.length ? 'mul-uwaga' : '' }, [ el( 'td', { 'data-label': 'Dodać' }, [ cb ] ) ]
				.concat( K.kategorie ? [ el( 'td', { 'data-label': 'Kategoria', text: nazwaKat( r.kat ) || '–' } ) ] : [] )
				.concat( pola.map( function ( k ) { return el( 'td', { 'data-label': DEF[k].etykieta, text: r.pola[k] || '' } ); } ) )
				.concat( [ el( 'td', { 'data-label': 'Do sprawdzenia', text: r.uwagi.join( ', ' ) } ) ] ) );
			tb.appendChild( tr );
		} );
		tab.appendChild( tb );
		box.appendChild( el( 'div', { class: 'mul-przewin' }, [ tab ] ) );
		box.appendChild( el( 'p', {}, [ el( 'button', { type: 'button', class: 'button button-primary', onclick: function () {
			var tryb = $( '#mul-wklej-tryb' ).value;
			var wybrane = rozpoznane.filter( function ( r ) { return r.dodaj; } );
			if ( ! wybrane.length ) { return; }
			if ( tryb === 'zastap' && ! window.confirm( 'Zastąpić ' + ( K.kategorie ? 'wpisy w kategorii „' + nazwaKat( kat ) + '”' : 'całą listę' ) + ' ' + wybrane.length + ' wklejonymi wpisami?' ) ) { return; }
			// wpisy mogą trafić do różnych kategorii (linie z nazwą kategorii w tekście)
			var grupy = {};
			wybrane.forEach( function ( r ) { var k = K.kategorie ? ( r.kat || kat ) : ''; ( grupy[k] = grupy[k] || [] ).push( Object.assign( { _id: ++licznik, k: k }, r.pola ) ); } );
			Object.keys( grupy ).forEach( function ( k ) { wstaw( grupy[k], k, tryb ); } );
			if ( K.kategorie ) { stan.filtr = Object.keys( grupy )[0]; }
			$( '#mul-tekst' ).value = '';
			box.innerHTML = '';
			$( '#mul-wklej' ).hidden = true;
			rysuj();
			$( '#mul-stan' ).textContent = 'Dodano ' + wybrane.length + ' wpisów – sprawdź i kliknij „Zapisz zmiany”';
		} }, [ 'Wstaw do listy' ] ) ] ) );
	}

	/* ---------- przyciski ---------- */
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-mul]' );
		if ( ! b || b.tagName === 'INPUT' ) { return; }
		var a = b.getAttribute( 'data-mul' );
		if ( a === 'dodaj' ) { nowyWpis(); }
		if ( a === 'wklej' ) { var o = $( '#mul-wklej' ); o.hidden = ! o.hidden; if ( ! o.hidden ) { rysujKategorie(); $( '#mul-tekst' ).focus(); } }
		if ( a === 'kategorie' ) { var k = $( '#mul-kategorie' ); k.hidden = ! k.hidden; }
		if ( a === 'sortuj' ) { sortuj( 'data' ); }
		if ( a === 'cofnij' ) { cofnijSortowanie(); }
		if ( a === 'rozpoznaj' ) { podglad(); }
		if ( a === 'kat-dodaj' ) { dodajKategorie( -1 ); }
	} );
	var sortujPo = $( '[data-mul="sortuj-po"]' );
	if ( sortujPo ) { sortujPo.addEventListener( 'change', function () { if ( sortujPo.value ) { sortuj( sortujPo.value ); sortujPo.value = ''; } } ); }
	var szukaj = $( '[data-mul="szukaj"]' );
	if ( szukaj ) { szukaj.addEventListener( 'input', function () { stan.szukaj = szukaj.value.trim().toLowerCase(); rysujWpisy(); } ); }

	$( '#mul-form' ).addEventListener( 'submit', function () {
		$( '#mul-dane' ).value = JSON.stringify( {
			kategorie: stan.kategorie,
			wpisy: stan.wpisy.map( function ( w ) { var c = Object.assign( {}, w ); delete c._id; return c; } )
		} );
		stan.zmiany = false;
	} );

	rysuj();
}() );
