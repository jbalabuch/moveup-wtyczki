/**
 * moveUP – Listy: rozpoznawanie wklejonego tekstu na podstawie pól listy (panel i test w node).
 *
 * Pola listy: [{ klucz, etykieta, typ: tekst|data|url|linie|linki, linia, styl: zwykly|pogrubiony|cudzyslow, wymagane, kategorie: [] }].
 * Wpisy oddzielone pustą linią, układ jak na stronie (pola w kolejności linii):
 *   – adres (http…, www.) → pole typu „url” (pierwszy adres) albo „linki” (wszystkie, z etykietą „Artykuł: https://…”),
 *   – linie przed adresem → pola z linii przed polem „url”, linie po adresie → pola po nim (np. dopisek),
 *   – pierwsza linia: gdy w niej jest pole „data” i pole tekstowe – podział „Medium, 28.05.2025”; gdy sama data – data na początku linii,
 *   – pozostałe linie po kolei do kolejnych pól; ostatnie pole bierze resztę (kilka linii – każda osobno, tekst – sklejone spacją).
 * Wiersz z tabulatorami (Excel) – kolumny po kolei do pól. Linia z samą nazwą kategorii przełącza kategorię kolejnych wpisów.
 * Wynik: [{ pola, kat, uwagi, zrodlo }] – uwagi = puste pola „ważne” (pomarańczowe w podglądzie).
 */
( function ( global ) {
	'use strict';

	var MIESIACE = { stycz: 1, lut: 2, mar: 3, kwie: 4, maj: 5, czerw: 6, lip: 7, sierp: 8, wrze: 9, 'paźdz': 10, pazdz: 10, listop: 11, grud: 12 };
	var URL_RE = /(https?:\/\/[^\s<>"„”]+|www\.[^\s<>"„”]+)/i;
	var DATA_RE = /(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{2,4})/;
	var MIES = '(?:stycze|stycz|luty|lut|marz|marc|kwie|maj|czerw|lip|sierp|wrze|pa[źz]dziern|listopad|grud)[a-ząćęłńóśźż]*';
	// data na początku linii (sama data): zakresy, dd.mm.rrrr, „28 października 2025”, rok, „od 2015”, „2019–2020”
	var DATA_START = new RegExp( '^((?:\\d{1,2}(?:\\.\\d{1,2})?(?:\\.\\d{2,4})?\\s*[-–]\\s*)?\\d{1,2}\\.\\d{1,2}\\.\\d{2,4}|\\d{1,2}\\s+[a-ząćęłńóśźż]+\\s+\\d{4}|(?:od\\s+)?(?:19|20)\\d{2}(?:\\s*[-–]\\s*(?:19|20)\\d{2})?)(?![\\d.])\\s*[:,–-]?\\s*(.*)$', 'i' );

	function dwa( n ) { n = String( n ); return n.length < 2 ? '0' + n : n; }

	/** Data do zapisu: 28.05.25 → 28.05.2025, 28 maja 2025 → 28.05.2025, lata „2019 - 2020” → „2019–2020”; inne bez zmian poza spacjami. */
	function normalizujDate( s ) {
		s = String( s || '' ).trim();
		if ( /^(?:od\s+)?(?:19|20)\d{2}(?:\s*[-–]\s*(?:19|20)\d{2})?$/i.test( s ) ) {
			return s.replace( /\s*[-–]\s*/, '–' ).replace( /\s+/g, ' ' );
		}
		s = s.replace( /\s*[–-]\s*/g, '-' ).replace( /\s+/g, ' ' );
		var m = s.match( /^(\d{1,2})[.\/](\d{1,2})[.\/](\d{2,4})$/ );
		if ( m ) {
			var r = m[3].length === 2 ? '20' + m[3] : m[3];
			return dwa( m[1] ) + '.' + dwa( m[2] ) + '.' + r;
		}
		m = s.match( /^(\d{1,2})\s+([a-ząćęłńóśźż]+)\s+(\d{4})$/i );
		if ( m ) {
			var mies = 0, k;
			for ( k in MIESIACE ) { if ( m[2].toLowerCase().indexOf( k ) === 0 ) { mies = MIESIACE[ k ]; } }
			if ( mies ) { return dwa( m[1] ) + '.' + dwa( mies ) + '.' + m[3]; }
		}
		return s;
	}

	/** Klucz sortowania z dowolnej daty/roku: RRRRMMDD (zakres – pierwszy dzień), 0 gdy brak. */
	function kluczDaty( s ) {
		s = String( s || '' );
		var rok = s.match( /(19|20)\d{2}/g );
		if ( ! rok ) { return 0; }
		var r = rok[ rok.length - 1 ];
		var m = s.match( /(\d{1,2})\.(\d{1,2})/ );
		var dzien = m ? +m[1] : 1, mies = m ? +m[2] : 1;
		var zakres = s.match( /^(\d{1,2})-\d{1,2}\.(\d{1,2})/ );
		if ( zakres ) { dzien = +zakres[1]; mies = +zakres[2]; }
		return +( r + dwa( mies ) + dwa( dzien ) );
	}

	/** Cudzysłowy: zewnętrzne zdejmij (wyświetlanie dodaje „…”), zbędny dwukropek na końcu też. */
	function bezCudzyslowow( s ) {
		s = String( s || '' ).trim().replace( /\s*:\s*$/, '' ).trim();
		var o = '„"“”\'’‘', z = '”"“\'’‘';
		if ( s.length > 1 && o.indexOf( s[0] ) > -1 && z.indexOf( s[ s.length - 1 ] ) > -1 ) {
			s = s.slice( 1, -1 ).trim();
		} else if ( s.length > 1 && o.indexOf( s[0] ) > -1 && ( s.match( /[„"“”]/g ) || [] ).length % 2 === 1 ) {
			s = s.slice( 1 ).trim();
		}
		return s;
	}

	function tekstLinii( s ) {
		return String( s || '' ).replace( / /g, ' ' ).replace( /[ \t]+/g, ' ' ).trim();
	}

	function bloki( tekst ) {
		var linie = String( tekst || '' ).replace( /\r\n?/g, '\n' ).split( '\n' );
		var wynik = [], biezacy = [];
		linie.forEach( function ( l ) {
			if ( /^\s*$/.test( l ) ) {
				if ( biezacy.length ) { wynik.push( biezacy ); biezacy = []; }
				return;
			}
			biezacy.push( l.indexOf( '\t' ) > -1 ? l : tekstLinii( l ) );
		} );
		if ( biezacy.length ) { wynik.push( biezacy ); }
		return wynik;
	}

	/** Adres złamany na dwie linie (kopiowanie z PDF/strony) – sklejany. */
	function sklejAdresy( linie ) {
		var w = [];
		linie.forEach( function ( l ) {
			var p = w.length ? w[ w.length - 1 ] : '';
			if ( p && URL_RE.test( p ) && /[\-\/_=?&%]$/.test( p ) && l.indexOf( ' ' ) === -1 && ! URL_RE.test( l ) ) {
				w[ w.length - 1 ] = p + l;
			} else {
				w.push( l );
			}
		} );
		return w;
	}

	function kategoriaZLinii( l, kategorie ) {
		var n = tekstLinii( l ).replace( /:$/, '' ).toLowerCase();
		for ( var i = 0; i < ( kategorie || [] ).length; i++ ) {
			var k = kategorie[ i ];
			if ( n === String( k.nazwa || '' ).toLowerCase() || ( k.naglowek && n === String( k.naglowek ).replace( /:$/, '' ).toLowerCase() ) ) {
				return k.id;
			}
		}
		return '';
	}

	/** Pola w kolejności linii (stabilnie). */
	function wKolejnosci( pola ) {
		return pola.map( function ( p, i ) { return { p: p, i: i }; } )
			.sort( function ( a, b ) { return ( +a.p.linia || 0 ) - ( +b.p.linia || 0 ) || a.i - b.i; } )
			.map( function ( x ) { return x.p; } );
	}

	function czyTekstowe( p ) { return p.typ === 'tekst' || p.typ === 'linie' || p.typ === 'data'; }

	/** Wartość pola z linii: cudzysłów – zdjęty, data – ujednolicona. */
	function wartosc( p, s ) {
		if ( p.typ === 'data' ) { return normalizujDate( s ); }
		if ( p.styl === 'cudzyslow' ) { return bezCudzyslowow( s ); }
		return s;
	}

	/** Linie do pól po kolei; ostatnie pole (albo pole „kilka linii”) bierze resztę (kilka linii – \n, tekst – spacja). */
	function poKolei( pola, linie, w ) {
		pola.forEach( function ( p, i ) {
			if ( ! linie.length ) { return; }
			var ostatnie = i === pola.length - 1;
			if ( ostatnie || p.typ === 'linie' ) {
				var zostaw = ostatnie ? 0 : pola.length - 1 - i;
				var reszta = linie.splice( 0, Math.max( 1, linie.length - zostaw ) );
				w[ p.klucz ] = p.typ === 'linie' ? reszta.join( '\n' ) : wartosc( p, reszta.join( ' ' ) );
				return;
			}
			w[ p.klucz ] = wartosc( p, linie.shift() );
		} );
	}

	/** Pierwsza linia z polem daty i tekstem: „Medium, 28.05.2025 (reportaż):”, „Radio X 3 maja 2026”, „Cosmopolitan październik 2019”. */
	function podzielTekstData( l ) {
		l = l.replace( /:\s*$/, '' );
		var m = l.match( /^(.*?),\s*((?:\d{1,2}[.\-\/]\d{1,2}[.\-\/]\d{2,4}|\d{1,2}\s+[a-ząćęłńóśźż]+\s+\d{4}|[a-ząćęłńóśźż]+\s+\d{4}|\d{4}).*)$/i );
		if ( m ) { return [ tekstLinii( m[1] ), normalizujDate( m[2] ) ]; }
		m = l.match( new RegExp( '^(.*?\\S)\\s+(\\d{1,2}\\.\\d{1,2}\\.\\d{4}|(?:\\d{1,2}\\s+)?' + MIES + '\\s+\\d{4})$', 'i' ) );
		if ( m ) { return [ m[1].replace( /,$/, '' ), normalizujDate( m[2] ) ]; }
		return [ l, '' ];
	}

	function rozpoznajWpis( linieWe, pola ) {
		var w = {}, uwagi = [];
		pola.forEach( function ( p ) { w[ p.klucz ] = ''; } );
		var kol = wKolejnosci( pola );
		var poleUrl = kol.filter( function ( p ) { return p.typ === 'url'; } )[0];
		var poleLinki = kol.filter( function ( p ) { return p.typ === 'linki'; } )[0];

		if ( linieWe.length === 1 && linieWe[0].indexOf( '\t' ) > -1 ) {
			// Excel: kolumny po kolei (adresy do pól adresowych, daty do pól daty)
			var wolne = kol.filter( czyTekstowe );
			linieWe[0].split( '\t' ).map( tekstLinii ).forEach( function ( c ) {
				if ( ! c ) { return; }
				if ( URL_RE.test( c ) && poleUrl && ! w[ poleUrl.klucz ] ) { w[ poleUrl.klucz ] = c.match( URL_RE )[0]; return; }
				if ( URL_RE.test( c ) && poleLinki ) { w[ poleLinki.klucz ] += ( w[ poleLinki.klucz ] ? '\n' : '' ) + c.match( URL_RE )[0]; return; }
				var d = ( DATA_RE.test( c ) || /^\d{4}$/.test( c ) ) && wolne.filter( function ( p ) { return p.typ === 'data' && ! w[ p.klucz ]; } )[0];
				var p = d || wolne.filter( function ( q ) { return q.typ !== 'data' && ! w[ q.klucz ]; } )[0];
				if ( p ) { w[ p.klucz ] = wartosc( p, c ); }
			} );
		} else {
			var linie = sklejAdresy( linieWe.map( tekstLinii ) );
			var przed = [], po = [], poAdresie = false;
			linie.forEach( function ( l, i ) {
				var u = l.match( URL_RE );
				if ( u && poleUrl && ! w[ poleUrl.klucz ] ) {
					w[ poleUrl.klucz ] = u[0].replace( /[.,;)]+$/, '' );
					var obok = tekstLinii( l.replace( u[0], '' ).replace( /[:–-]\s*$/, '' ) );
					if ( obok && i > 0 ) { przed.push( obok ); }
					poAdresie = true;
					return;
				}
				if ( u && poleLinki ) {
					var et = tekstLinii( l.replace( u[0], '' ) ).replace( /:\s*$/, '' );
					w[ poleLinki.klucz ] += ( w[ poleLinki.klucz ] ? '\n' : '' ) + ( et ? et + ': ' : '' ) + u[0].replace( /[.,;)]+$/, '' );
					return;
				}
				( poAdresie ? po : przed ).push( l );
			} );
			var granica = poleUrl ? +poleUrl.linia : Infinity;
			var polaPrzed = kol.filter( function ( p ) { return czyTekstowe( p ) && ( +p.linia || 0 ) <= granica && p !== poleUrl; } );
			var polaPo = kol.filter( function ( p ) { return czyTekstowe( p ) && ( +p.linia || 0 ) > granica; } );

			if ( przed.length && polaPrzed.length ) {
				var nr = +polaPrzed[0].linia || 0;
				var grupa = polaPrzed.filter( function ( p ) { return ( +p.linia || 0 ) === nr; } );
				var data = grupa.filter( function ( p ) { return p.typ === 'data'; } )[0];
				var inne = grupa.filter( function ( p ) { return p.typ !== 'data'; } );
				if ( data && inne.length ) {
					var dz = podzielTekstData( przed.shift() );
					w[ inne[0].klucz ] = wartosc( inne[0], dz[0] );
					w[ data.klucz ] = dz[1];
				} else if ( data ) {
					var m = przed[0].match( DATA_START );
					if ( m ) {
						w[ data.klucz ] = normalizujDate( m[1] );
						if ( m[2] ) { przed[0] = m[2]; } else { przed.shift(); }
					}
				} else {
					poKolei( grupa, przed.splice( 0, 1 ), w );
				}
				polaPrzed = polaPrzed.filter( function ( p ) { return grupa.indexOf( p ) === -1; } );
			}
			poKolei( polaPrzed, przed, w );
			if ( po.length && polaPo.length ) { poKolei( polaPo, po, w ); }
		}
		pola.forEach( function ( p ) {
			if ( p.wymagane && ! String( w[ p.klucz ] || '' ).trim() ) { uwagi.push( 'brak: ' + String( p.etykieta || p.klucz ).toLowerCase() ); }
		} );
		return { pola: w, uwagi: uwagi };
	}

	/** Pola dla kategorii (pole bez listy kategorii = we wszystkich). */
	function polaKategorii( pola, kat ) {
		return pola.filter( function ( p ) { return ! p.kategorie || ! p.kategorie.length || ! kat || p.kategorie.indexOf( kat ) > -1; } );
	}

	/**
	 * @param {string} tekst
	 * @param {Array} pola pola listy
	 * @param {Array} kategorie [{id,nazwa,naglowek}]
	 * @param {string} katDomyslna
	 */
	function rozpoznaj( tekst, pola, kategorie, katDomyslna ) {
		var kat = katDomyslna || '';
		var wynik = [];
		bloki( tekst ).forEach( function ( b ) {
			var k = kategoriaZLinii( b[0], kategorie );
			if ( k ) {
				kat = k;
				b = b.slice( 1 );
				if ( ! b.length ) { return; }
			}
			// nagłówek kolumn z Excela (tabulatory, bez adresu, zawiera nazwę któregoś pola) – pomiń
			if ( b[0].indexOf( '\t' ) > -1 && ! URL_RE.test( b[0] ) && pola.some( function ( p ) { var e = String( p.etykieta || '' ).toLowerCase().split( ' ' )[0]; return e && b[0].toLowerCase().split( '\t' ).map( tekstLinii ).indexOf( e ) > -1; } ) ) {
				b = b.slice( 1 );
				if ( ! b.length ) { return; }
			}
			var czesci = b.length > 1 && b.every( function ( l ) { return l.indexOf( '\t' ) > -1; } ) ? b.map( function ( l ) { return [ l ]; } ) : [ b ];
			czesci.forEach( function ( c ) {
				var r = rozpoznajWpis( c.slice(), polaKategorii( pola, kat ) );
				wynik.push( { pola: r.pola, kat: kat, uwagi: r.uwagi, zrodlo: c.join( '\n' ) } );
			} );
		} );
		return wynik;
	}

	var api = { rozpoznaj: rozpoznaj, polaKategorii: polaKategorii, normalizujDate: normalizujDate, kluczDaty: kluczDaty, bezCudzyslowow: bezCudzyslowow };
	if ( typeof module !== 'undefined' && module.exports ) { module.exports = api; } else { global.muListyParser = api; }
}( this ) );
