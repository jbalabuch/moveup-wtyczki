/* moveUP – Listy: blok „Lista moveUP” – wybór listy i kategorii, podgląd z serwera. Bez kroku budowania (wp.element). */
( function ( wp ) {
	var el = wp.element.createElement;
	var be = wp.blockEditor, C = wp.components;
	var SSR = wp.serverSideRender;
	var D = window.mulBlok || { listy: [] };

	wp.blocks.registerBlockType( 'moveup/lista', {
		edit: function ( p ) {
			var a = p.attributes;
			var lista = D.listy.filter( function ( l ) { return l.id === a.lista; } )[0];
			var opcjeList = [ { label: '— wybierz listę —', value: '' } ].concat( D.listy.map( function ( l ) { return { label: l.nazwa, value: l.id }; } ) );
			var opcjeKat = lista && lista.kategorie.length ? [ { label: lista.zakladki ? 'wszystkie (zakładki)' : 'wszystkie', value: '' } ].concat( lista.kategorie.map( function ( k ) { return { label: k.nazwa, value: k.id }; } ) ) : null;
			return el( wp.element.Fragment, {},
				el( be.InspectorControls, {},
					el( C.PanelBody, { title: 'Lista', initialOpen: true },
						el( C.SelectControl, { label: 'Która lista', value: a.lista, options: opcjeList, onChange: function ( v ) { p.setAttributes( { lista: v, kategoria: '' } ); } } ),
						opcjeKat ? el( C.SelectControl, { label: 'Kategoria', value: a.kategoria, options: opcjeKat, onChange: function ( v ) { p.setAttributes( { kategoria: v } ); } } ) : null,
						el( 'p', {}, el( 'a', { href: D.ustawienia, target: '_blank' }, 'Ustawienia list (wygląd, odstępy)' ) ),
						a.lista ? el( 'p', {}, el( 'a', { href: 'admin.php?page=moveup-listy-' + a.lista, target: '_blank' }, 'Edytuj wpisy tej listy' ) ) : null
					)
				),
				el( 'div', be.useBlockProps(),
					a.lista ? el( SSR, { block: 'moveup/lista', attributes: a } ) :
						el( C.Placeholder, { icon: 'list-view', label: 'Lista moveUP', instructions: 'Wybierz listę (wywiady, konferencje, publikacje…).' },
							el( C.SelectControl, { value: a.lista, options: opcjeList, onChange: function ( v ) { p.setAttributes( { lista: v } ); } } ) )
				)
			);
		},
		save: function () { return null; }
	} );
}( window.wp ) );
