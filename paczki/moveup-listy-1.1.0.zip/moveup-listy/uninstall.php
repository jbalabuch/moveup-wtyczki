<?php
/**
 * moveUP – Listy: usunięcie wtyczki NIE kasuje danych list (wpisy zostają w bazie na wypadek ponownej instalacji).
 * Dane: opcje mu_listy i mu_listy_dane_* – usuwać ręcznie, świadomie.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
