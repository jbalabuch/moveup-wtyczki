=== moveUP – Listy ===
Contributors: moveUP Agency
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

Listy wpisów edytowane w panelu zamiast długich bloków tekstu. Pierwsze wdrożenie: mariabanaszak.pl (Wywiady – 7 zakładek, 138 wpisów; Konferencje i szkolenia; Publikacje).

== Co robi ==

– Pola wpisu ustawiane dla każdej listy (Ustawienia → Listy → Pola wpisu): nazwa, typ (tekst, data/rok, link, kilka linii, kilka linków z etykietą), numer linii (kilka pól w jednej linii), wygląd (zwykły, pogrubiony, w cudzysłowie „…”), tekst przed (np. „, ”) i po polu (np. „:” – tylko gdy niżej coś jest), podpowiedź, „ważne” (ostrzeżenie przy wklejaniu), ograniczenie do wybranych kategorii, format daty (dzień: kropki przy wpisywaniu i kalendarz; rok / dowolny tekst). Gotowe zestawy pól (assets/szablony-pol.json): wywiady i media, konferencje i wydarzenia, publikacje, prosta lista – do wczytania i zmiany. Wartości usuniętego pola zostają w bazie.
– Kategorie: jako zakładki Kadence (lista z szablonem zakładek) albo grupy z nagłówkiem na jednej liście („SPOTKANIA AUTORSKIE:”). Nowa kategoria = nowa zakładka (kopia wyglądu pierwszej); „+ Dodaj poniżej” wstawia ją we wskazanym miejscu, strzałki zmieniają kolejność zakładek.
– Pola w karcie wpisu: link – szare „https://” jako podpowiedź, przy wpisywaniu dopisywane od pierwszego znaku, wklejony adres bez zmian, „www.…” uzupełniane przy wyjściu z pola; data – kropki po dniu i miesiącu, „-” po kropce dla zakresów (09-10.12.2024), 4.5.26 → 04.05.2026, przycisk kalendarza.
– Panel: menu Listy → karty wpisów (na telefonie jedna kolumna), filtr kategorii, szukanie, przeciąganie za uchwyt (mysz i dotyk – zdarzenia pointer, przewijanie przy krawędzi; na uchwycie strzałki klawiatury), strzałki kolejności, „Sortuj od najnowszych”, „Sortuj po…” (dowolne pole tekstowe alfabetycznie, w nim od najnowszych), „Cofnij sortowanie” (krok po kroku, wpisy dodane w międzyczasie zostają), „Przywróć wersję sprzed ostatniego zapisu”.
– Wklej z tekstu: wpisy oddzielone pustą linią w układzie jak na stronie albo wiersze z Excela; podgląd z polami i uwagami („brak daty”), tryb dodaj na górze / na końcu / zastąp. Daty: 28.05.25 → 28.05.2025, „28 maja 2025” → 28.05.2025; cudzysłowy wokół tytułu zdejmowane (strona dodaje „…”); adresy złamane przy kopiowaniu – sklejane.
– Na stronie: [moveup_lista lista="id"] w bloku tekstu (wygląd bloku bez zmian), [moveup_lista lista="id" kategoria="…"], [moveup_lista lista="id" uklad="zakladki"] – cały blok zakładek z szablonu; CSS bloków w <head>.
– Po zapisie czyści cache tylko stron z daną listą (LiteSpeed).

== Ustawienia ==

Ustawienia → Listy – do klikania, karta na każdą listę:
– Lista: nazwa, kategorie, układ (lista z grupami albo zakładki), wygląd zakładek – wzór z dowolnego bloku zakładek Kadence na stronie lub we wzorcu (pierwszy nagłówek w zakładce = nagłówek kategorii, ostatni blok tekstu = lista).
– Wygląd wpisów: odstęp między wpisami (px; puste = pusta linia), odstęp przed kolejną grupą (px; puste = dwie puste linie), tekst linku (puste = adres), pogrubienie pierwszej linii, linki w nowej karcie. Domyślne wartości = wygląd jak w zwykłym tekście.
– Na stronie: gdzie lista jest użyta, wstawka do skopiowania; usunięcie listy razem z wpisami.
– Pola wpisu: edytor pól (jak wyżej), „+ Dodaj pole”, „Wczytaj zestaw pól”, podgląd pierwszego wpisu.
– Nowa lista: nazwa, zestaw pól na start, kategorie, układ – od razu w menu Listy.
– Zaawansowane (dla moveUP): wszystkie ustawienia w JSON.

Blok „Lista moveUP” (edytor bloków): wybór listy i kategorii w panelu bocznym, podgląd na żywo, marginesy, odstępy wewnętrzne, wielkość i kolor tekstu z ustawień bloku. Wstawka [moveup_lista lista="…"] dalej działa (np. wewnątrz bloku tekstu Kadence).

== Aktualizacje ==

Z https://github.com/jbalabuch/moveup-wtyczki (wtyczki.json) – Kokpit → Aktualizacje.

== Zmiany ==

= 1.1.0 =
Pola wpisu definiowane dla każdej listy (zamiast trzech stałych rodzajów) z ograniczeniem do kategorii, parser i sortowanie oparte na polach. Ustawienia do klikania zamiast JSON (listy, kategorie, układ, wzór zakładek ze strony, wygląd: odstępy, tekst linku, pogrubienie, nowa karta), nowa lista i usuwanie listy, blok „Lista moveUP” w edytorze, przeciąganie wpisów, sortowanie po medium i cofanie sortowania.

= 1.0.0 =
Pierwsza wersja (mariabanaszak.pl).
