<?php
/**
 * Plugin Name: moveUP – Listy
 * Description: Listy wpisów edytowane w panelu zamiast długich bloków tekstu: wywiady i występy w mediach (z kategoriami jako zakładki), konferencje i wydarzenia, publikacje. Dodawanie i edycja w kartach (także na telefonie), kolejność strzałkami, sortowanie po dacie, „Wklej z tekstu” – system sam rozpozna pola. Na stronie te same bloki Kadence co wcześniej. Menu Listy, ustawienia (do klikania): Ustawienia → Listy, na stronie: blok „Lista moveUP” albo [moveup_lista lista="…"].
 * Version: 1.1.0
 * Author: moveUP Agency
 * Text Domain: moveup-listy
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-listy' );

define( 'MUL_VER', '1.1.0' );
define( 'MUL_URL', plugin_dir_url( __FILE__ ) );
define( 'MUL_OPCJA', 'mu_listy' );          // ustawienia list: [ id => { nazwa, typ, kategorie, uklad, szablon } ]
define( 'MUL_DANE', 'mu_listy_dane_' );     // dane listy: { kategorie: [ {id, nazwa, naglowek, zakladka} ], wpisy: [ {k, pola…} ] }

require_once __DIR__ . '/includes/dane.php';
require_once __DIR__ . '/includes/wyswietlanie.php';
require_once __DIR__ . '/includes/blok.php';
if ( is_admin() ) {
	require_once __DIR__ . '/includes/panel.php';
	require_once __DIR__ . '/includes/ustawienia.php';
}
