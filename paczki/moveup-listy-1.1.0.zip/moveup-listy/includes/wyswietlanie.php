<?php
/**
 * moveUP – Listy: wyświetlanie.
 *
 * [moveup_lista lista="konferencje"]                 – wpisy jako tekst (wstawka w bloku tekstu Kadence – wygląd bloku bez zmian)
 * [moveup_lista lista="wywiady" kategoria="podcasty"] – tylko jedna kategoria
 * [moveup_lista lista="wywiady" uklad="zakladki"]    – cały blok zakładek Kadence z szablonu listy: kategoria = zakładka
 *
 * Wpis: pierwsza linia pogrubiona, kolejne pod nią, wpisy rozdzielone pustą linią – jak w dotychczasowych blokach.
 */

defined( 'ABSPATH' ) || exit;

/** Tytuł w „…”, chyba że już zaczyna się polskim cudzysłowem (np. „MonArt” (reportaż)). Cytat w środku ("…") zostaje. */
function mul_w_cudzyslowie( $t ) {
	if ( '' === $t ) {
		return '';
	}
	return 0 === strpos( $t, '„' ) ? $t : '„' . $t . '”';
}

function mul_link_html( $url, $etykieta = '', $wyg = array() ) {
	$wyg  = wp_parse_args( $wyg, mul_wyglad_domyslny() );
	$cel  = $wyg['nowa_karta'] ? ' target="_blank" rel="noreferrer noopener"' : '';
	$opis = '' !== $wyg['link_tekst'] ? $wyg['link_tekst'] : $url;
	$a    = '<a href="' . esc_url( $url ) . '"' . $cel . '>' . esc_html( $opis ) . '</a>';
	return '' !== $etykieta ? esc_html( $etykieta ) . ': ' . $a : $a;
}

/** Pierwsza linia wpisu – pogrubiona albo nie (ustawienie listy). */
function mul_pierwsza( $t, $wyg ) {
	return ! empty( $wyg['pogrubienie'] ) ? '<strong>' . esc_html( $t ) . '</strong>' : esc_html( $t );
}

/**
 * HTML jednego wpisu z pól listy (linie rozdzielone <br>):
 * pola z tej samej „linii” łączone tekstem „przed”; linia pogrubiona, gdy jej pierwsze pole jest „pogrubione”;
 * „w cudzysłowie” – „…”; tekst „po” (np. dwukropek) – tylko gdy niżej we wpisie coś jest; „kilka linii” i „kilka linków” – każda osobno.
 */
function mul_wpis_html( $pola, $w, $wyg = array() ) {
	$wyg  = wp_parse_args( $wyg, mul_wyglad_domyslny() );
	$kol  = array_values( $pola );
	$kol  = array_map( null, array_keys( $kol ), $kol );
	usort( $kol, function ( $a, $b ) { return ( (int) $a[1]['linia'] <=> (int) $b[1]['linia'] ) ?: ( $a[0] <=> $b[0] ); } );
	// linie wpisu: [ [ 'pola' => [ [pole, wartość] ], 'nr' => n ] ]
	$linie = array();
	foreach ( $kol as $x ) {
		$p = $x[1];
		$v = trim( (string) ( $w[ $p['klucz'] ] ?? '' ) );
		if ( '' === $v ) {
			continue;
		}
		$nr = (int) $p['linia'];
		if ( in_array( $p['typ'], array( 'linie', 'linki' ), true ) ) {
			foreach ( array_filter( explode( "\n", $v ), 'strlen' ) as $j => $l ) {
				$linie[] = array( 'nr' => $nr, 'pola' => array( array( $p, $l ) ), 'osobna' => true );
			}
			continue;
		}
		$ost = end( $linie );
		if ( $ost && $ost['nr'] === $nr && empty( $ost['osobna'] ) ) {
			$linie[ count( $linie ) - 1 ]['pola'][] = array( $p, $v );
		} else {
			$linie[] = array( 'nr' => $nr, 'pola' => array( array( $p, $v ) ) );
		}
	}
	$html = array();
	$n    = count( $linie );
	foreach ( $linie as $i => $linia ) {
		$czesci = array();
		foreach ( $linia['pola'] as $j => $pv ) {
			list( $p, $v ) = $pv;
			if ( 'url' === $p['typ'] ) {
				$t = mul_link_html( $v, '', $wyg );
			} elseif ( 'linki' === $p['typ'] ) {
				$t = preg_match( '~^(.*?):\s*(https?://\S+)$~', $v, $m ) ? mul_link_html( $m[2], $m[1], $wyg ) : mul_link_html( $v, '', $wyg );
			} else {
				$t = esc_html( 'cudzyslow' === $p['styl'] ? mul_w_cudzyslowie( $v ) : $v );
			}
			if ( '' !== $p['po'] && $i < $n - 1 && $j === count( $linia['pola'] ) - 1 ) {
				$t .= esc_html( $p['po'] );
			}
			$czesci[] = ( $j > 0 ? esc_html( $p['przed'] ) : '' ) . $t;
		}
		$l      = implode( '', $czesci );
		$html[] = 'pogrubiony' === $linia['pola'][0][0]['styl'] ? '<strong>' . $l . '</strong>' : $l;
	}
	return implode( '<br>', $html );
}

/** Wpisy listy (albo jednej kategorii) jako HTML do bloku tekstu. Kategorie z nagłówkiem (np. „SPOTKANIA AUTORSKIE:”) – nagłówek przed grupą. */
function mul_wpisy_html( $id, $kategoria = '' ) {
	$lista = mul_lista( $id );
	if ( ! $lista ) {
		return '';
	}
	$d     = mul_dane( $id );
	$wyg   = $lista['wyglad'];
	$pola  = mul_pola( $lista );
	// odstęp między wpisami: pusta linia (domyślnie) albo wpisy jako bloki z marginesem w px
	$wpisy = function ( $kat ) use ( $d, $pola, $wyg ) {
		$h = array();
		foreach ( $d['wpisy'] as $w ) {
			if ( null === $kat || ( $w['k'] ?? '' ) === $kat ) {
				$h[] = mul_wpis_html( $pola, $w, $wyg );
			}
		}
		if ( '' === $wyg['odstep'] ) {
			return implode( '<br><br>', $h );
		}
		$n = count( $h );
		foreach ( $h as $i => $x ) {
			$h[ $i ] = '<span class="mul-wpis" style="display:block' . ( $i < $n - 1 ? ';margin-bottom:' . (int) $wyg['odstep'] . 'px' : '' ) . '">' . $x . '</span>';
		}
		return implode( '', $h );
	};
	if ( '' !== $kategoria || ! $lista['kategorie'] || ! $d['kategorie'] ) {
		return $wpisy( '' !== $kategoria ? $kategoria : null );
	}
	// cała lista z kategoriami w jednym bloku: grupy po kolei, nagłówek grupy pogrubiony
	$czesci = array();
	foreach ( $d['kategorie'] as $i => $k ) {
		$h = $wpisy( $k['id'] );
		if ( '' === $h ) {
			continue;
		}
		// nagłówek grupy, pod nim ten sam odstęp co między wpisami
		$nag      = '' !== $k['naglowek'] ? mul_pierwsza( $k['naglowek'], $wyg ) . ( '' === $wyg['odstep'] ? '<br><br>' : '<span style="display:block;height:' . (int) $wyg['odstep'] . 'px"></span>' ) : '';
		$czesci[] = $nag . $h;
	}
	// odstęp przed kolejną grupą: domyślnie dwie puste linie (jak dotąd); w px – pusty blok tej wysokości
	if ( '' !== $wyg['odstep_grupy'] ) {
		$sep = '<span style="display:block;height:' . (int) $wyg['odstep_grupy'] . 'px"></span>';
	} elseif ( '' === $wyg['odstep'] ) {
		$sep = '<br><br><br>';
	} else {
		$sep = '<span style="display:block;height:' . ( 2 * (int) $wyg['odstep'] ) . 'px"></span>';
	}
	return implode( $sep, $czesci );
}

/* -------------------------------------------------------------------------
 * Zakładki Kadence z szablonu
 * ---------------------------------------------------------------------- */

/** Bloki o nazwie (rekurencyjnie) – referencje do modyfikacji. */
function mul_bloki_ref( array &$bloki, $nazwa, array &$wynik ) {
	foreach ( $bloki as &$b ) {
		if ( ( $b['blockName'] ?? '' ) === $nazwa ) {
			$wynik[] = &$b;
		}
		if ( ! empty( $b['innerBlocks'] ) ) {
			mul_bloki_ref( $b['innerBlocks'], $nazwa, $wynik );
		}
	}
}

/** Zmiana treści statycznego bloku (np. advancedheading): tekst między pierwszym znacznikiem otwierającym a ostatnim zamykającym. */
function mul_ustaw_tresc( array &$b, $html ) {
	$zamien = function ( $s ) use ( $html ) {
		return preg_replace( '~^(\s*<(\w+)[^>]*>).*(</\2>\s*)$~s', '${1}' . str_replace( array( '\\', '$' ), array( '\\\\', '\\$' ), $html ) . '$3', $s );
	};
	$b['innerHTML'] = $zamien( $b['innerHTML'] );
	foreach ( $b['innerContent'] as $i => $c ) {
		if ( is_string( $c ) && '' !== trim( $c ) ) {
			$b['innerContent'][ $i ] = $zamien( $c );
		}
	}
}

/** Kopia zakładki z nowymi uniqueID (nowa kategoria – wygląd jak pierwsza zakładka). */
function mul_klonuj_zakladke( $tab, $sufiks ) {
	$s = serialize_block( $tab );
	preg_match_all( '/"uniqueID":"([^"]+)"/', $s, $m );
	foreach ( array_unique( $m[1] ) as $uid ) {
		$nowe = substr( $uid, 0, max( 0, strlen( $uid ) - 3 ) ) . $sufiks;
		$s    = str_replace( $uid, $nowe, $s );
	}
	$b = parse_blocks( $s );
	return $b[0];
}

/** Kotwica zakładki jak w Kadence: małe litery, bez znaków spoza a-z0-9. */
function mul_kotwica( $t ) {
	return preg_replace( '/[^a-z0-9]/', '', strtolower( $t ) );
}

/** Znaczniki bloku zakładek Kadence dla listy z kategoriami. '' gdy brak szablonu. */
function mul_zakladki_markup( $id ) {
	$lista = mul_lista( $id );
	if ( ! $lista || '' === $lista['szablon'] ) {
		return '';
	}
	$bloki = array_values( array_filter( parse_blocks( $lista['szablon'] ), function ( $b ) { return 'kadence/tabs' === $b['blockName']; } ) );
	if ( ! $bloki ) {
		return '';
	}
	$t       = $bloki[0];
	$wzory   = $t['innerBlocks'];
	$tytuly  = $t['attrs']['titles'] ?? array();
	$d       = mul_dane( $id );
	$kat     = array_values( $d['kategorie'] );
	$n       = count( $kat );
	if ( ! $n ) {
		return '';
	}
	$taby       = array();
	$nowe_tytuly = array();
	$li         = array();
	preg_match( '~<li\b.*?</li>~s', $t['innerContent'][0], $wzor_li );
	foreach ( $kat as $i => $k ) {
		$nr  = $i + 1;
		$z   = isset( $k['zakladka'] ) && isset( $wzory[ $k['zakladka'] ] ) ? (int) $k['zakladka'] : null;
		$tab = null !== $z ? $wzory[ $z ] : mul_klonuj_zakladke( $wzory[0], substr( md5( $k['id'] ), 0, 3 ) );
		// numer zakładki
		$tab['attrs']['id'] = $nr;
		foreach ( $tab['innerContent'] as $j => $c ) {
			if ( is_string( $c ) ) {
				$tab['innerContent'][ $j ] = preg_replace( '/kt-inner-tab-\d+(?=\s)/', 'kt-inner-tab-' . $nr, $c );
			}
		}
		$tab['innerHTML'] = preg_replace( '/kt-inner-tab-\d+(?=\s)/', 'kt-inner-tab-' . $nr, $tab['innerHTML'] );
		// nagłówek i wpisy: pierwszy i ostatni blok advancedheading w zakładce
		$h = array();
		mul_bloki_ref( $tab['innerBlocks'], 'kadence/advancedheading', $h );
		if ( count( $h ) >= 2 ) {
			mul_ustaw_tresc( $h[0], esc_html( $k['naglowek'] ) );
			mul_ustaw_tresc( $h[ count( $h ) - 1 ], mul_wpisy_html( $id, $k['id'] ) );
		}
		unset( $h );
		$taby[] = $tab;
		// tytuł zakładki
		$tt          = $tytuly[ null !== $z ? $z : 0 ] ?? ( $tytuly[0] ?? array() );
		$tt['text']  = $k['nazwa'];
		$nowe_tytuly[] = $tt;
		if ( $wzor_li ) {
			$kot  = mul_kotwica( $k['nazwa'] );
			$l    = $wzor_li[0];
			$l    = preg_replace( '/\bid="tab-[^"]*"/', 'id="tab-' . $kot . '"', $l );
			$l    = preg_replace( '/href="#tab-[^"]*"/', 'href="#tab-' . $kot . '"', $l );
			$l    = preg_replace( '/kt-title-item-\d+/', 'kt-title-item-' . $nr, $l );
			$l    = preg_replace( '/kt-tab-title-\d+/', 'kt-tab-title-' . $nr, $l );
			$l    = preg_replace( '/data-tab="\d+"/', 'data-tab="' . $nr . '"', $l );
			$l    = preg_replace( '/kt-tab-title-(?:active|inactive)/', 1 === $nr ? 'kt-tab-title-active' : 'kt-tab-title-inactive', $l );
			$l    = preg_replace( '~(<span class="kt-title-text">).*?(</span>)~s', '${1}' . esc_html( $k['nazwa'] ) . '$2', $l );
			$li[] = $l;
		}
	}
	$t['attrs']['titles']     = $nowe_tytuly;
	$t['attrs']['tabCount']   = $n;
	$t['attrs']['currentTab'] = 1;
	$otw                      = $t['innerContent'][0];
	if ( $li ) {
		$otw = preg_replace( '~(<ul\b[^>]*class="[^"]*kt-tabs-title-list[^"]*"[^>]*>).*?(</ul>)~s', '${1}' . str_replace( array( '\\', '$' ), array( '\\\\', '\\$' ), implode( '', $li ) ) . '$2', $otw );
	}
	$otw = preg_replace( '/kt-tabs-has-\d+-tabs/', 'kt-tabs-has-' . $n . '-tabs', $otw );
	$otw = preg_replace( '/kb-tab-title-columns-\d+/', 'kb-tab-title-columns-' . $n, $otw );
	$zam = end( $t['innerContent'] );
	$sep = ( isset( $t['innerContent'][2] ) && is_string( $t['innerContent'][2] ) ) ? $t['innerContent'][2] : '';
	$ic  = array( $otw );
	foreach ( $taby as $i => $tab ) {
		$ic[] = null;
		if ( $i < $n - 1 ) {
			$ic[] = $sep;
		}
	}
	$ic[]               = $zam;
	$t['innerContent']  = $ic;
	$t['innerBlocks']   = $taby;
	return serialize_block( $t );
}

add_shortcode( 'moveup_lista', function ( $a ) {
	$a = shortcode_atts( array( 'lista' => '', 'kategoria' => '', 'uklad' => '' ), $a, 'moveup_lista' );
	$id = sanitize_key( $a['lista'] );
	if ( 'zakladki' === $a['uklad'] ) {
		$m = mul_zakladki_markup( $id );
		return '' !== $m ? do_blocks( $m ) : '';
	}
	return mul_wpisy_html( $id, sanitize_key( $a['kategoria'] ) );
} );

/**
 * CSS bloków z zakładek do <head> (Kadence buduje CSS tylko z bloków zapisanych w treści – bez tego <style> w treści).
 * Ten sam punkt co Kadence (frontend_inline_css, 20).
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! is_singular() || ! class_exists( 'Kadence_Blocks_Frontend' ) ) {
		return;
	}
	$c = (string) get_post_field( 'post_content', get_queried_object_id() );
	// blok „Lista moveUP” w układzie zakładek
	if ( false !== strpos( $c, '<!-- wp:moveup/lista' ) && preg_match_all( '/<!-- wp:moveup\/lista (\{.*?\}) \/-->/', $c, $bl ) ) {
		foreach ( $bl[1] as $j ) {
			$a  = json_decode( $j, true );
			$id = sanitize_key( $a['lista'] ?? '' );
			$l  = $id ? mul_lista( $id ) : null;
			if ( $l && 'zakladki' === $l['uklad'] && empty( $a['kategoria'] ) ) {
				$markup = mul_zakladki_markup( $id );
				if ( '' !== $markup ) {
					Kadence_Blocks_Frontend::get_instance()->frontend_css_parse( parse_blocks( $markup ) );
				}
			}
		}
	}
	if ( false === strpos( $c, '[moveup_lista' ) ) {
		return;
	}
	preg_match_all( '/' . get_shortcode_regex( array( 'moveup_lista' ) ) . '/', $c, $m, PREG_SET_ORDER );
	foreach ( $m as $s ) {
		$a = shortcode_parse_atts( $s[3] );
		$a = is_array( $a ) ? $a : array();
		if ( 'zakladki' !== ( $a['uklad'] ?? '' ) ) {
			continue;
		}
		$markup = mul_zakladki_markup( sanitize_key( $a['lista'] ?? '' ) );
		if ( '' !== $markup ) {
			Kadence_Blocks_Frontend::get_instance()->frontend_css_parse( parse_blocks( $markup ) );
		}
	}
}, 21 );
