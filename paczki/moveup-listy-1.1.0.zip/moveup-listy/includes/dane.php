<?php
/**
 * moveUP – Listy: typy list (pola), ustawienia i dane.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pola listy – każda lista ma własne pola (Ustawienia → Listy). Pole:
 *   klucz (w danych), etykieta, typ: tekst | data | url | linie (kilka linii) | linki (kilka linii „Etykieta: adres”),
 *   linia (w której linii wpisu stoi; kilka pól w jednej linii – łączone tekstem „przed”), styl: zwykly | pogrubiony | cudzyslow,
 *   przed (np. „, ”), po (np. „:” – tylko gdy niżej w wpisie coś jest), pomoc, wymagane (podgląd wklejania ostrzega), kategorie (puste = wszystkie).
 * Gotowe zestawy pól (do wczytania i zmiany): assets/szablony-pol.json – ten sam plik czyta parser w przeglądarce.
 */
function mul_typy_pol() {
	return array( 'tekst' => 'Tekst', 'data' => 'Data / rok', 'url' => 'Link (adres)', 'linie' => 'Kilka linii', 'linki' => 'Kilka linków (z etykietą)' );
}

function mul_style_pol() {
	return array( 'zwykly' => 'zwykły', 'pogrubiony' => 'pogrubiony', 'cudzyslow' => 'w cudzysłowie „…”' );
}

function mul_szablony_pol() {
	static $s = null;
	if ( null === $s ) {
		$s = json_decode( (string) file_get_contents( dirname( __DIR__ ) . '/assets/szablony-pol.json' ), true );
		$s = is_array( $s ) ? $s : array();
	}
	return $s;
}

/** Pola listy (zapisane albo – dla starszych ustawień – z szablonu „typ”). */
function mul_pola( $lista ) {
	if ( ! empty( $lista['pola'] ) && is_array( $lista['pola'] ) ) {
		return $lista['pola'];
	}
	$sz = mul_szablony_pol();
	return $sz[ $lista['typ'] ?? 'media' ]['pola'] ?? ( $sz['prosta']['pola'] ?? array() );
}

/** Tekst „przed/po” – spacje zostają (np. „, ”), bez znaczników, do 20 znaków. */
function mul_separator( $s ) {
	// bez wp_strip_all_tags() – ta obcina spacje na brzegach, a „, ” musi zostać ze spacją
	return mb_substr( strip_tags( str_replace( array( "\r", "\n", "\t" ), ' ', (string) $s ) ), 0, 20 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.strip_tags_strip_tags
}

/** Oczyszczenie pól z formularza/JSON: klucze unikalne (nowe – z etykiety), znane typy i style. */
function mul_oczysc_pola( $pola ) {
	$typy   = mul_typy_pol();
	$style  = mul_style_pol();
	$wynik  = array();
	$klucze = array();
	foreach ( (array) $pola as $p ) {
		if ( ! is_array( $p ) || ! empty( $p['usun'] ) ) {
			continue;
		}
		$et = sanitize_text_field( $p['etykieta'] ?? '' );
		if ( '' === $et ) {
			continue;
		}
		$k = sanitize_key( $p['klucz'] ?? '' );
		if ( '' === $k ) {
			$k = sanitize_key( str_replace( ' ', '-', remove_accents( strtolower( $et ) ) ) );
		}
		if ( in_array( $k, array( 'k', '_id' ), true ) || '' === $k ) {
			$k = 'pole';
		}
		$baza = $k;
		$i    = 2;
		while ( in_array( $k, $klucze, true ) ) {
			$k = $baza . '-' . $i++;
		}
		$klucze[] = $k;
		$wynik[]  = array(
			'klucz'     => $k,
			'etykieta'  => $et,
			'typ'       => isset( $typy[ $p['typ'] ?? '' ] ) ? $p['typ'] : 'tekst',
			// format pola daty: „dzien” (kropki przy wpisywaniu + kalendarz) albo „rok” (dowolny tekst); bez ustawienia – „rok”, gdy nazwa zawiera „rok”
			'format'    => in_array( $p['format'] ?? '', array( 'dzien', 'rok' ), true ) ? $p['format'] : ( false !== mb_stripos( $et, 'rok' ) ? 'rok' : 'dzien' ),
			'linia'     => max( 1, min( 20, (int) ( $p['linia'] ?? 1 ) ) ),
			'styl'      => isset( $style[ $p['styl'] ?? '' ] ) ? $p['styl'] : 'zwykly',
			'przed'     => mul_separator( $p['przed'] ?? '' ),
			'po'        => mul_separator( $p['po'] ?? '' ),
			'pomoc'     => sanitize_text_field( $p['pomoc'] ?? '' ),
			'wymagane'  => ! empty( $p['wymagane'] ),
			'kategorie' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $p['kategorie'] ?? array() ) ) ) ),
		);
	}
	return $wynik;
}

/** Pole daty do sortowania „od najnowszych” – pierwsze pole typu data. */
function mul_pole_daty( $pola ) {
	foreach ( $pola as $p ) {
		if ( 'data' === $p['typ'] ) {
			return $p['klucz'];
		}
	}
	return '';
}

/** Ustawienia wszystkich list. */
function mul_listy() {
	$o = get_option( MUL_OPCJA, array() );
	return is_array( $o ) ? $o : array();
}

/**
 * Wygląd listy – domyślne wartości dają dokładnie dotychczasowy wygląd (pusta linia między wpisami, pierwsza linia pogrubiona,
 * adres jako tekst linku, nowa karta). Odstępy w px: puste = pusta linia jak w tekście.
 */
function mul_wyglad_domyslny() {
	return array(
		'odstep'       => '',   // między wpisami: '' = pusta linia, liczba = px
		'odstep_grupy' => '',   // przed nagłówkiem grupy (kolejne grupy): '' = dwie puste linie, liczba = px
		'pogrubienie'  => 1,    // pierwsza linia wpisu pogrubiona
		'link_tekst'   => '',   // '' = adres; inaczej ten tekst (np. „Obejrzyj”, „Przeczytaj”)
		'nowa_karta'   => 1,    // linki w nowej karcie
	);
}

function mul_lista( $id ) {
	$l = mul_listy();
	if ( ! isset( $l[ $id ] ) ) {
		return null;
	}
	$w           = wp_parse_args( $l[ $id ], array( 'nazwa' => $id, 'typ' => 'media', 'kategorie' => false, 'uklad' => 'tekst', 'szablon' => '', 'wyglad' => array() ) );
	$w['wyglad'] = wp_parse_args( (array) $w['wyglad'], mul_wyglad_domyslny() );
	return $w;
}

/** Oczyszczenie ustawień jednej listy (z formularza albo JSON). */
function mul_oczysc_liste( $l, $stara = array() ) {
	$typy = mul_szablony_pol();
	$wyg  = (array) ( $l['wyglad'] ?? array() );
	$px   = function ( $v ) { return '' === trim( (string) $v ) ? '' : (string) max( 0, min( 200, (int) $v ) ); };
	return array(
		'nazwa'     => sanitize_text_field( $l['nazwa'] ?? '' ),
		'typ'       => isset( $typy[ $l['typ'] ?? '' ] ) ? $l['typ'] : 'media',
		'kategorie' => ! empty( $l['kategorie'] ),
		'uklad'     => 'zakladki' === ( $l['uklad'] ?? '' ) ? 'zakladki' : 'tekst',
		'szablon'   => (string) ( $l['szablon'] ?? ( $stara['szablon'] ?? '' ) ),
		'pola'      => isset( $l['pola'] ) ? mul_oczysc_pola( $l['pola'] ) : ( $stara['pola'] ?? mul_pola( array( 'typ' => $l['typ'] ?? 'media' ) ) ),
		'wyglad'    => array(
			'odstep'       => $px( $wyg['odstep'] ?? '' ),
			'odstep_grupy' => $px( $wyg['odstep_grupy'] ?? '' ),
			'pogrubienie'  => empty( $wyg['pogrubienie'] ) ? 0 : 1,
			'link_tekst'   => sanitize_text_field( $wyg['link_tekst'] ?? '' ),
			'nowa_karta'   => empty( $wyg['nowa_karta'] ) ? 0 : 1,
		),
	);
}

/** Pierwszy blok zakładek Kadence ze strony – wzór wyglądu zakładek listy. '' gdy brak. */
function mul_szablon_ze_strony( $post_id ) {
	$znajdz = function ( $bloki ) use ( &$znajdz ) {
		foreach ( $bloki as $b ) {
			if ( 'kadence/tabs' === $b['blockName'] ) {
				return $b;
			}
			$r = $znajdz( $b['innerBlocks'] );
			if ( $r ) {
				return $r;
			}
		}
		return null;
	};
	$t = $znajdz( parse_blocks( (string) get_post_field( 'post_content', $post_id ) ) );
	return $t ? serialize_block( $t ) : '';
}

/** Strony i wzorce z blokiem zakładek Kadence – do wyboru wzoru. */
function mul_strony_z_zakladkami() {
	global $wpdb;
	return $wpdb->get_results( "SELECT ID, post_title, post_type FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('page','post','wp_block','kadence_element') AND post_content LIKE '%<!-- wp:kadence/tabs %' ORDER BY post_title" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

function mul_dane( $id ) {
	$d = get_option( MUL_DANE . $id, array() );
	$d = is_array( $d ) ? $d : array();
	return array(
		'kategorie' => isset( $d['kategorie'] ) && is_array( $d['kategorie'] ) ? $d['kategorie'] : array(),
		'wpisy'     => isset( $d['wpisy'] ) && is_array( $d['wpisy'] ) ? $d['wpisy'] : array(),
	);
}

/** Klucz sortowania z daty/roku: RRRRMMDD (zakres – pierwszy dzień), 0 gdy brak. Ta sama reguła co parser.js. */
function mul_klucz_daty( $s ) {
	$s = (string) $s;
	if ( ! preg_match_all( '/(?:19|20)\d{2}/', $s, $r ) ) {
		return 0;
	}
	$rok   = end( $r[0] );
	$dzien = 1;
	$mies  = 1;
	if ( preg_match( '/^(\d{1,2})-\d{1,2}\.(\d{1,2})/', $s, $z ) ) {
		$dzien = (int) $z[1];
		$mies  = (int) $z[2];
	} elseif ( preg_match( '/(\d{1,2})\.(\d{1,2})/', $s, $m ) ) {
		$dzien = (int) $m[1];
		$mies  = (int) $m[2];
	}
	return (int) sprintf( '%s%02d%02d', $rok, $mies, $dzien );
}

/** Tekst jednej linii: bez znaczników, białe znaki zwinięte, myślnik „ - ” → „ – ”. */
function mul_tekst( $s ) {
	$s = wp_strip_all_tags( (string) $s );
	$s = preg_replace( '/\s+/u', ' ', $s );
	$s = str_replace( ' - ', ' – ', $s );
	return trim( $s );
}

function mul_linie( $s ) {
	$l = array_filter( array_map( 'mul_tekst', preg_split( '/\r\n|\r|\n/', (string) $s ) ), 'strlen' );
	return implode( "\n", $l );
}

/** Adres: bez białych znaków (adres złamany przy kopiowaniu), tylko http(s). */
function mul_url( $s ) {
	$s = preg_replace( '/\s+/', '', (string) $s );
	if ( '' !== $s && ! preg_match( '~^https?://~i', $s ) ) {
		$s = 'https://' . ltrim( $s, '/' );
	}
	return esc_url_raw( $s, array( 'http', 'https' ) );
}

/** Oczyszczenie danych listy z panelu (JSON) – tylko znane pola typu. */
function mul_oczysc_dane( $lista, $d ) {
	$pola = array();
	foreach ( mul_pola( $lista ) as $p ) {
		$pola[ $p['klucz'] ] = $p;
	}
	$w    = array( 'kategorie' => array(), 'wpisy' => array() );
	$ids  = array();
	foreach ( (array) ( $d['kategorie'] ?? array() ) as $k ) {
		$nazwa = mul_tekst( $k['nazwa'] ?? '' );
		if ( '' === $nazwa ) {
			continue;
		}
		$id = sanitize_key( $k['id'] ?? '' );
		if ( '' === $id ) {
			$id = sanitize_key( remove_accents( $nazwa ) );
		}
		while ( in_array( $id, $ids, true ) ) {
			$id .= '-2';
		}
		$ids[]  = $id;
		$kat    = array( 'id' => $id, 'nazwa' => $nazwa, 'naglowek' => mul_tekst( $k['naglowek'] ?? '' ) );
		if ( isset( $k['zakladka'] ) && '' !== $k['zakladka'] && null !== $k['zakladka'] ) {
			$kat['zakladka'] = (int) $k['zakladka'];
		}
		$w['kategorie'][] = $kat;
	}
	foreach ( (array) ( $d['wpisy'] ?? array() ) as $wp ) {
		$nowy = array( 'k' => sanitize_key( $wp['k'] ?? '' ) );
		if ( $lista['kategorie'] && ! in_array( $nowy['k'], $ids, true ) ) {
			$nowy['k'] = $ids[0] ?? '';
		}
		$pusty = true;
		// pola spoza ustawień (np. pole chwilowo usunięte) – zostają, żeby nic nie przepadło
		foreach ( (array) $wp as $klucz => $v ) {
			$klucz = sanitize_key( $klucz );
			if ( '' !== $klucz && 'k' !== $klucz && ! isset( $pola[ $klucz ] ) && is_scalar( $v ) && '' !== (string) $v ) {
				$nowy[ $klucz ] = mul_linie( $v );
			}
		}
		foreach ( $pola as $klucz => $pole ) {
			$v = $wp[ $klucz ] ?? '';
			switch ( $pole['typ'] ) {
				case 'url':
					$v = mul_url( $v );
					break;
				case 'linie':
					$v = mul_linie( $v );
					break;
				case 'linki':
					$linki = array();
					foreach ( preg_split( '/\r\n|\r|\n/', (string) $v ) as $l ) {
						if ( preg_match( '~^(.*?)(?::\s*)?((?:https?://|www\.)\S.*)$~i', trim( $l ), $m ) ) {
							$u = mul_url( $m[2] );
							if ( $u ) {
								$linki[] = ( '' !== mul_tekst( $m[1] ) ? mul_tekst( rtrim( $m[1], ': ' ) ) . ': ' : '' ) . $u;
							}
						}
					}
					$v = implode( "\n", $linki );
					break;
				default:
					$v = mul_tekst( $v );
			}
			$nowy[ $klucz ] = $v;
			if ( '' !== $v ) {
				$pusty = false;
			}
		}
		if ( ! $pusty ) {
			$w['wpisy'][] = $nowy;
		}
	}
	return $w;
}

/** Strony z wstawką listy – do odświeżenia cache po zapisie. */
function mul_strony_z_lista( $id ) {
	global $wpdb;
	$sc   = '%' . $wpdb->esc_like( '[moveup_lista' ) . '%' . $wpdb->esc_like( '"' . $id . '"' ) . '%';
	$blok = '%' . $wpdb->esc_like( '<!-- wp:moveup/lista {' ) . '%' . $wpdb->esc_like( '"lista":"' . $id . '"' ) . '%';
	return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type NOT IN ('revision') AND ( post_content LIKE %s OR post_content LIKE %s )", $sc, $blok ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

function mul_zapisz_dane( $id, $dane ) {
	update_option( MUL_DANE . $id, $dane, false );
	foreach ( mul_strony_z_lista( $id ) as $p ) {
		do_action( 'litespeed_purge_post', $p );
		clean_post_cache( $p );
	}
}
