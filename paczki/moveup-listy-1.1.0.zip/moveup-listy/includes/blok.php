<?php
/**
 * moveUP – Listy: blok „Lista moveUP” (edytor bloków) – wybór listy i kategorii w panelu bocznym, podgląd z serwera,
 * marginesy, odstępy wewnętrzne, wielkość i kolor tekstu z ustawień bloku (supports WordPressa).
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	wp_register_script( 'moveup-listy-blok', MUL_URL . 'assets/blok.js', array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ), MUL_VER . '.' . (int) @filemtime( dirname( __DIR__ ) . '/assets/blok.js' ), true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	register_block_type(
		'moveup/lista',
		array(
			'api_version'     => 3,
			'title'           => 'Lista moveUP',
			'description'     => 'Lista wpisów z menu Listy (wywiady, konferencje, publikacje…).',
			'category'        => 'widgets',
			'icon'            => 'list-view',
			'keywords'        => array( 'lista', 'wywiady', 'publikacje', 'konferencje' ),
			'editor_script'   => 'moveup-listy-blok',
			'attributes'      => array(
				'lista'     => array( 'type' => 'string', 'default' => '' ),
				'kategoria' => array( 'type' => 'string', 'default' => '' ),
			),
			'supports'        => array(
				'html'       => false,
				'spacing'    => array( 'margin' => true, 'padding' => true ),
				'typography' => array( 'fontSize' => true, 'lineHeight' => true ),
				'color'      => array( 'text' => true, 'link' => true, 'background' => false ),
			),
			'render_callback' => 'mul_blok_render',
		)
	);
} );

/** Listy i kategorie do panelu bloku. */
add_action( 'enqueue_block_editor_assets', function () {
	$dane = array();
	foreach ( mul_listy() as $id => $l ) {
		$l      = mul_lista( $id );
		$dane[] = array(
			'id'        => $id,
			'nazwa'     => $l['nazwa'],
			'zakladki'  => 'zakladki' === $l['uklad'],
			'kategorie' => $l['kategorie'] ? array_map( function ( $k ) { return array( 'id' => $k['id'], 'nazwa' => $k['nazwa'] ); }, mul_dane( $id )['kategorie'] ) : array(),
		);
	}
	wp_add_inline_script( 'moveup-listy-blok', 'window.mulBlok = ' . wp_json_encode( array( 'listy' => $dane, 'ustawienia' => admin_url( 'options-general.php?page=moveup-listy-ustawienia' ) ) ) . ';', 'before' );
} );

function mul_blok_render( $a ) {
	$id    = sanitize_key( $a['lista'] ?? '' );
	$kat   = sanitize_key( $a['kategoria'] ?? '' );
	$lista = $id ? mul_lista( $id ) : null;
	if ( ! $lista ) {
		return ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ? '<p>Wybierz listę w panelu bloku (po prawej).</p>' : '';
	}
	if ( 'zakladki' === $lista['uklad'] && '' === $kat && $lista['kategorie'] ) {
		$m = mul_zakladki_markup( $id );
		if ( '' !== $m ) {
			return '<div ' . get_block_wrapper_attributes( array( 'class' => 'mul-lista mul-lista-' . $id ) ) . '>' . do_blocks( $m ) . '</div>';
		}
	}
	$html = mul_wpisy_html( $id, $kat );
	return '' === $html ? '' : '<p ' . get_block_wrapper_attributes( array( 'class' => 'mul-lista mul-lista-' . $id ) ) . '>' . $html . '</p>';
}
