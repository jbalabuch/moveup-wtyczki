<?php
/**
 * moveUP – Listy: panel. Menu „Listy” → jedna podstrona na listę (Wywiady, Konferencje…).
 * Edycja w przeglądarce (panel.js), zapis całej listy jednym przyciskiem (JSON w ukrytym polu, oczyszczany po stronie serwera).
 * Ustawienia list (typ, kategorie, szablon zakładek) – Ustawienia → Listy (administrator, JSON).
 */

defined( 'ABSPATH' ) || exit;

function mul_uprawnienie() {
	return apply_filters( 'moveup_listy_uprawnienie', 'edit_pages' );
}

add_action( 'admin_menu', function () {
	$listy = mul_listy();
	if ( $listy ) {
		$pierwsza = array_key_first( $listy );
		add_menu_page( 'Listy', 'Listy', mul_uprawnienie(), 'moveup-listy-' . $pierwsza, 'mul_strona_listy', 'dashicons-list-view', 21 );
		foreach ( $listy as $id => $l ) {
			add_submenu_page( 'moveup-listy-' . $pierwsza, $l['nazwa'] ?? $id, $l['nazwa'] ?? $id, mul_uprawnienie(), 'moveup-listy-' . $id, 'mul_strona_listy' );
		}
	}
	add_options_page( 'Listy – ustawienia', 'Listy', 'manage_options', 'moveup-listy-ustawienia', 'mul_strona_ustawien' );
} );

function mul_biezaca_lista() {
	$p = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	return 0 === strpos( $p, 'moveup-listy-' ) ? substr( $p, strlen( 'moveup-listy-' ) ) : '';
}

add_action( 'admin_enqueue_scripts', function () {
	$id = mul_biezaca_lista();
	if ( 'ustawienia' === $id ) {
		wp_enqueue_style( 'moveup-listy-panel', MUL_URL . 'assets/panel.css', array(), MUL_VER . '.' . (int) @filemtime( dirname( __DIR__ ) . '/assets/panel.css' ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return;
	}
	if ( ! $id || ! mul_lista( $id ) ) {
		return;
	}
	// wersja z daty zmiany pliku – serwer każe trzymać pliki rok w pamięci przeglądarki, więc bez tego poprawka nie dociera
	$v = function ( $plik ) { return MUL_VER . '.' . (int) @filemtime( dirname( __DIR__ ) . '/assets/' . $plik ); }; // phpcs:ignore WordPress.PHP.NoSilencedErrors
	wp_enqueue_style( 'moveup-listy-panel', MUL_URL . 'assets/panel.css', array(), $v( 'panel.css' ) );
	wp_enqueue_script( 'moveup-listy-parser', MUL_URL . 'assets/parser.js', array(), $v( 'parser.js' ), true );
	wp_enqueue_script( 'moveup-listy-panel', MUL_URL . 'assets/panel.js', array( 'moveup-listy-parser' ), $v( 'panel.js' ), true );
} );

/** Zapis listy (POST z panelu). */
add_action( 'admin_init', function () {
	if ( empty( $_POST['mul_zapisz'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$id = sanitize_key( wp_unslash( $_POST['mul_lista'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	check_admin_referer( 'mul_zapisz_' . $id );
	if ( ! current_user_can( mul_uprawnienie() ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	$lista = mul_lista( $id );
	$d     = json_decode( wp_unslash( $_POST['mul_dane'] ?? '' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- oczyszczane w mul_oczysc_dane()
	if ( ! $lista || ! is_array( $d ) ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'moveup-listy-' . $id, 'mul' => 'blad' ), admin_url( 'admin.php' ) ) );
		exit;
	}
	// poprzednia wersja – do przywrócenia linkiem pod listą
	update_option( MUL_DANE . $id . '_kopia', array( 'czas' => time(), 'dane' => mul_dane( $id ) ), false );
	$nowe = mul_oczysc_dane( $lista, $d );
	mul_zapisz_dane( $id, $nowe );
	wp_safe_redirect( add_query_arg( array( 'page' => 'moveup-listy-' . $id, 'mul' => 'ok', 'n' => count( $nowe['wpisy'] ) ), admin_url( 'admin.php' ) ) );
	exit;
} );

/** Przywrócenie poprzedniej wersji (przed ostatnim zapisem). */
add_action( 'admin_init', function () {
	if ( empty( $_GET['mul_przywroc'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$id = sanitize_key( wp_unslash( $_GET['mul_przywroc'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	check_admin_referer( 'mul_przywroc_' . $id );
	if ( ! current_user_can( mul_uprawnienie() ) || ! mul_lista( $id ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	$k = get_option( MUL_DANE . $id . '_kopia' );
	if ( is_array( $k ) && isset( $k['dane'] ) ) {
		$teraz = mul_dane( $id );
		mul_zapisz_dane( $id, $k['dane'] );
		update_option( MUL_DANE . $id . '_kopia', array( 'czas' => time(), 'dane' => $teraz ), false );
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'moveup-listy-' . $id, 'mul' => 'przywrocono' ), admin_url( 'admin.php' ) ) );
	exit;
} );

function mul_strona_listy() {
	$id    = mul_biezaca_lista();
	$lista = mul_lista( $id );
	if ( ! $lista ) {
		echo '<div class="wrap"><h1>Listy</h1><p>Brak listy.</p></div>';
		return;
	}
	$pola  = mul_pola( $lista );
	$dane  = mul_dane( $id );
	$kopia = get_option( MUL_DANE . $id . '_kopia' );
	$stron = mul_strony_z_lista( $id );
	$konfig = array(
		'lista'     => $id,
		'typ'       => $lista['typ'],
		'kategorie' => (bool) $lista['kategorie'],
		'zakladki'  => 'zakladki' === $lista['uklad'],
		'pola'      => $pola,
		'poleDaty'  => mul_pole_daty( $pola ),
		'dane'      => $dane,
	);
	$msg = isset( $_GET['mul'] ) ? sanitize_key( wp_unslash( $_GET['mul'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="wrap mul">
		<h1 class="wp-heading-inline"><?php echo esc_html( $lista['nazwa'] ); ?></h1>
		<?php foreach ( $stron as $p ) : ?>
			<a class="page-title-action" href="<?php echo esc_url( get_permalink( $p ) ); ?>" target="_blank">Zobacz na stronie</a>
		<?php endforeach; ?>
		<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<a class="page-title-action" href="<?php echo esc_url( admin_url( 'options-general.php?page=moveup-listy-ustawienia#lista-' . $id ) ); ?>">Ustawienia listy</a>
		<?php endif; ?>
		<hr class="wp-header-end">
		<?php if ( 'ok' === $msg ) : ?>
			<div class="notice notice-success is-dismissible"><p>Zapisano (<?php echo (int) ( $_GET['n'] ?? 0 ); // phpcs:ignore ?> wpisów). Strona pokazuje już nową wersję.</p></div>
		<?php elseif ( 'przywrocono' === $msg ) : ?>
			<div class="notice notice-success is-dismissible"><p>Przywrócono wersję sprzed ostatniego zapisu.</p></div>
		<?php elseif ( 'blad' === $msg ) : ?>
			<div class="notice notice-error"><p>Nie udało się zapisać – nic nie zmieniono. Spróbuj jeszcze raz.</p></div>
		<?php endif; ?>

		<form method="post" id="mul-form">
			<?php wp_nonce_field( 'mul_zapisz_' . $id ); ?>
			<input type="hidden" name="mul_lista" value="<?php echo esc_attr( $id ); ?>">
			<input type="hidden" name="mul_zapisz" value="1">
			<textarea name="mul_dane" id="mul-dane" hidden></textarea>

			<div class="mul-pasek">
				<button type="button" class="button button-primary" data-mul="dodaj">+ Dodaj wpis</button>
				<button type="button" class="button" data-mul="wklej">Wklej z tekstu</button>
				<?php if ( mul_pole_daty( $pola ) ) : ?>
					<button type="button" class="button" data-mul="sortuj">Sortuj od najnowszych</button>
				<?php endif; ?>
				<?php $tekstowe = array_filter( $pola, function ( $p ) { return 'tekst' === $p['typ']; } ); ?>
				<?php if ( $tekstowe ) : ?>
					<label class="mul-sortuj-po"><span class="screen-reader-text">Sortuj po polu</span>
						<select data-mul="sortuj-po" title="Alfabetycznie po wybranym polu, a w ramach tej samej wartości – od najnowszych">
							<option value="">Sortuj po…</option>
							<?php foreach ( $tekstowe as $p ) : ?><option value="<?php echo esc_attr( $p['klucz'] ); ?>"><?php echo esc_html( $p['etykieta'] ); ?> (A–Z)</option><?php endforeach; ?>
						</select>
					</label>
				<?php endif; ?>
				<button type="button" class="button" data-mul="cofnij" disabled title="Przywraca kolejność sprzed ostatniego sortowania">Cofnij sortowanie</button>
				<?php if ( $lista['kategorie'] ) : ?>
					<button type="button" class="button" data-mul="kategorie">Kategorie</button>
				<?php endif; ?>
				<label class="mul-szukaj"><span class="screen-reader-text">Szukaj</span><input type="search" placeholder="Szukaj…" data-mul="szukaj"></label>
			</div>

			<?php if ( $lista['kategorie'] ) : ?>
				<div class="mul-filtr" role="group" aria-label="Kategoria" id="mul-filtr"></div>
			<?php endif; ?>

			<section class="mul-okno" id="mul-wklej" hidden>
				<h2>Wklej z tekstu</h2>
				<p class="description"><?php echo wp_kses_post( mul_pomoc_wklejania( $pola, (bool) $lista['kategorie'] ) ); ?></p>
				<textarea id="mul-tekst" rows="10" class="large-text" placeholder="Wklej tutaj…"></textarea>
				<div class="mul-opcje">
					<?php if ( $lista['kategorie'] ) : ?>
						<label>Kategoria <select id="mul-wklej-kat"></select></label>
					<?php endif; ?>
					<label>Co zrobić <select id="mul-wklej-tryb"><option value="gora">dodaj na górze</option><option value="dol">dodaj na końcu</option><option value="zastap">zastąp wpisy<?php echo $lista['kategorie'] ? ' w tej kategorii' : ''; ?></option></select></label>
					<button type="button" class="button" data-mul="rozpoznaj">Rozpoznaj</button>
				</div>
				<div id="mul-podglad"></div>
			</section>

			<?php if ( $lista['kategorie'] ) : ?>
				<section class="mul-okno" id="mul-kategorie" hidden>
					<h2>Kategorie</h2>
					<p class="description"><?php echo $lista['uklad'] === 'zakladki' ? 'Każda kategoria to zakładka na stronie. Nazwa = tytuł zakładki, nagłówek = tekst nad listą w zakładce.' : 'Kategorie to grupy na liście. Nagłówek (np. SPOTKANIA AUTORSKIE:) pokazuje się nad grupą; pierwsza grupa zwykle bez nagłówka.'; ?></p>
					<div id="mul-kat-lista"></div>
					<p><button type="button" class="button" data-mul="kat-dodaj">+ Dodaj kategorię na końcu</button></p>
				</section>
			<?php endif; ?>

			<div id="mul-wpisy" class="mul-wpisy" aria-live="polite"></div>

			<div class="mul-zapis">
				<span id="mul-stan" class="mul-stan"></span>
				<button type="submit" class="button button-primary button-hero">Zapisz zmiany</button>
			</div>
		</form>
		<?php if ( is_array( $kopia ) && ! empty( $kopia['czas'] ) ) : ?>
			<p class="mul-kopia">Coś poszło nie tak? <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'page' => 'moveup-listy-' . $id, 'mul_przywroc' => $id ), admin_url( 'admin.php' ) ), 'mul_przywroc_' . $id ) ); ?>" onclick="return confirm('Przywrócić wersję sprzed ostatniego zapisu?');">Przywróć wersję sprzed ostatniego zapisu</a> (<?php echo esc_html( wp_date( 'j.m.Y H:i', $kopia['czas'] ) ); ?>).</p>
		<?php endif; ?>
	</div>
	<script>window.mulKonfig = <?php echo wp_json_encode( $konfig, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;</script>
	<?php
}

function mul_pomoc_wklejania( $pola, $kategorie ) {
	// układ z pól listy: „Medium, Data” → „Tytuł” → Link …
	$linie = array();
	foreach ( $pola as $p ) {
		$linie[ (int) $p['linia'] ][] = $p;
	}
	ksort( $linie );
	$opis = array();
	foreach ( $linie as $l ) {
		$t = '';
		foreach ( $l as $j => $p ) {
			$t .= ( $j ? esc_html( $p['przed'] ? $p['przed'] : ' ' ) : '' ) . esc_html( $p['etykieta'] ) . ( in_array( $p['typ'], array( 'linie', 'linki' ), true ) ? ' (każda linia osobno)' : '' );
		}
		$opis[] = '<code>' . $t . '</code>';
	}
	return 'Każdy wpis oddziel pustą linią. Układ jak na stronie: ' . implode( ' → ', $opis ) . '. Linki rozpoznają się same (http…, www.), daty też (28.05.2025, 28.05.25, 28 maja 2025). Albo wiersze z Excela – kolumny w tej kolejności.'
		. ( $kategorie ? ' Linia z samą nazwą kategorii przenosi kolejne wpisy do tej kategorii.' : '' )
		. ' Przed wstawieniem zobaczysz podgląd – na pomarańczowo to, co warto sprawdzić. Nic nie zapisze się bez „Zapisz zmiany”.';
}
