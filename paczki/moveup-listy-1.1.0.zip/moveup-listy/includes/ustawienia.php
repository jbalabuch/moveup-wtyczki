<?php
/**
 * moveUP – Listy: Ustawienia → Listy – listy do klikania (nazwa, typ, kategorie, układ, wzór zakładek, wygląd),
 * nowa lista, usunięcie listy, gdzie lista jest na stronie. JSON – tylko w „Zaawansowane”.
 */

defined( 'ABSPATH' ) || exit;

/** Zapis formularza ustawień (przed wyświetleniem menu – nowa lista od razu w menu „Listy”). */
add_action( 'admin_init', function () {
	if ( empty( $_POST['mul_ustawienia'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	check_admin_referer( 'mul_ustawienia' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	$post   = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- oczyszczane niżej
	$stare  = mul_listy();
	$nowe   = array();
	$komunikat = 'zapisano';

	// Zaawansowane: cały JSON (gdy zmieniony)
	if ( isset( $post['mul_json'] ) && trim( $post['mul_json'] ) !== trim( (string) ( $post['mul_json_przed'] ?? '' ) ) ) {
		$k = json_decode( $post['mul_json'], true );
		if ( ! is_array( $k ) ) {
			wp_safe_redirect( admin_url( 'options-general.php?page=moveup-listy-ustawienia&mul=json' ) );
			exit;
		}
		foreach ( $k as $id => $l ) {
			$id = sanitize_key( $id );
			if ( $id && 'ustawienia' !== $id && is_array( $l ) ) {
				$nowe[ $id ] = mul_oczysc_liste( $l, $stare[ $id ] ?? array() );
			}
		}
		update_option( MUL_OPCJA, $nowe, false );
		wp_safe_redirect( admin_url( 'options-general.php?page=moveup-listy-ustawienia&mul=zapisano' ) );
		exit;
	}

	foreach ( $stare as $id => $l ) {
		$f = $post['listy'][ $id ] ?? null;
		if ( ! is_array( $f ) ) {
			$nowe[ $id ] = $l;
			continue;
		}
		if ( ! empty( $f['usun'] ) ) {
			delete_option( MUL_DANE . $id );
			delete_option( MUL_DANE . $id . '_kopia' );
			$komunikat = 'usunieto';
			continue;
		}
		$f['wyglad'] = $f['wyglad'] ?? array();
		// wzór zakładek: „bez zmian” – zostaje zapisany; numer strony – pobierz z niej blok zakładek
		$f['szablon'] = $l['szablon'] ?? '';
		$wzor         = (string) ( $f['wzor'] ?? '' );
		if ( 'brak' === $wzor ) {
			$f['szablon'] = '';
		} elseif ( ctype_digit( $wzor ) ) {
			$sz = mul_szablon_ze_strony( (int) $wzor );
			if ( '' !== $sz ) {
				$f['szablon'] = $sz;
			}
		}
		$czysta = mul_oczysc_liste( $f, $l );
		if ( '' === $czysta['nazwa'] ) {
			$czysta['nazwa'] = $l['nazwa'] ?? $id;
		}
		$nowe[ $id ] = $czysta;
	}

	// nowa lista
	$n = $post['nowa'] ?? array();
	if ( '' !== trim( (string) ( $n['nazwa'] ?? '' ) ) ) {
		$id = sanitize_key( str_replace( ' ', '-', remove_accents( strtolower( $n['nazwa'] ) ) ) );
		$id = $id ? $id : 'lista';
		if ( 'ustawienia' === $id ) {
			$id = 'lista-ustawienia';
		}
		$baza = $id;
		$i    = 2;
		while ( isset( $nowe[ $id ] ) || isset( $stare[ $id ] ) ) {
			$id = $baza . '-' . $i++;
		}
		$n['wyglad'] = array( 'pogrubienie' => 1, 'nowa_karta' => 1 );
		$nowe[ $id ] = mul_oczysc_liste( $n );
		if ( $nowe[ $id ]['kategorie'] ) {
			update_option( MUL_DANE . $id, array( 'kategorie' => array( array( 'id' => 'ogolne', 'nazwa' => 'Ogólne', 'naglowek' => '' ) ), 'wpisy' => array() ), false );
		}
		$komunikat = 'dodano-' . $id;
	}

	update_option( MUL_OPCJA, $nowe, false );
	foreach ( array_keys( $nowe ) as $id ) {
		foreach ( mul_strony_z_lista( $id ) as $p ) {
			do_action( 'litespeed_purge_post', $p );
		}
	}
	wp_safe_redirect( admin_url( 'options-general.php?page=moveup-listy-ustawienia&mul=' . rawurlencode( $komunikat ) ) );
	exit;
} );

/** Pole: etykieta nad polem, opis pod nim. */
function mul_u_pole( $etykieta, $html, $opis = '', $klasa = '' ) {
	echo '<div class="mul-pole ' . esc_attr( $klasa ) . '"><label>' . esc_html( $etykieta ) . '</label>' . $html . ( $opis ? '<span class="description">' . wp_kses_post( $opis ) . '</span>' : '' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- $html składany z esc_* niżej
}

function mul_u_wybor( $nazwa, $wartosc, $opcje ) {
	$h = '<select name="' . esc_attr( $nazwa ) . '">';
	foreach ( $opcje as $k => $v ) {
		$h .= '<option value="' . esc_attr( $k ) . '"' . selected( (string) $wartosc, (string) $k, false ) . '>' . esc_html( $v ) . '</option>';
	}
	return $h . '</select>';
}

/** Jeden wiersz edytora pól (też wzór dla „+ Dodaj pole” – indeks __I__). */
function mul_u_wiersz_pola( $n, $i, $p, $kategorie ) {
	$p    = wp_parse_args( $p, array( 'klucz' => '', 'etykieta' => '', 'typ' => 'tekst', 'format' => '', 'linia' => 1, 'styl' => 'zwykly', 'przed' => '', 'po' => '', 'pomoc' => '', 'wymagane' => false, 'kategorie' => array() ) );
	$b    = $n . '[pola][' . $i . ']';
	$pole = function ( $etykieta, $html, $klasa = '' ) {
		return '<label class="mul-pd ' . $klasa . '"><span>' . esc_html( $etykieta ) . '</span>' . $html . '</label>';
	};
	$h  = '<div class="mul-pole-def" data-mul-pole>';
	$h .= '<input type="hidden" name="' . esc_attr( $b ) . '[klucz]" value="' . esc_attr( $p['klucz'] ) . '">';
	$h .= '<div class="mul-pd-akcje"><button type="button" class="button" data-mul-pole-ruch="-1" aria-label="Pole wyżej">↑</button><button type="button" class="button" data-mul-pole-ruch="1" aria-label="Pole niżej">↓</button></div>';
	$h .= $pole( 'Nazwa pola', '<input type="text" name="' . esc_attr( $b ) . '[etykieta]" value="' . esc_attr( $p['etykieta'] ) . '" placeholder="np. Autor">', 'mul-pd-szer' );
	$h .= $pole( 'Typ', mul_u_wybor( $b . '[typ]', $p['typ'], mul_typy_pol() ) );
	$format = '' !== $p['format'] ? $p['format'] : ( false !== mb_stripos( (string) $p['etykieta'], 'rok' ) ? 'rok' : 'dzien' );
	$h .= $pole( 'Format daty', mul_u_wybor( $b . '[format]', $format, array( 'dzien' => 'dzień (kropki, kalendarz)', 'rok' => 'rok / dowolny tekst' ) ), 'mul-pd-format' );
	$h .= $pole( 'Linia', '<input type="number" min="1" max="20" name="' . esc_attr( $b ) . '[linia]" value="' . esc_attr( $p['linia'] ) . '" title="W której linii wpisu – kilka pól z tym samym numerem stoi w jednej linii">', 'mul-pd-waskie' );
	$h .= $pole( 'Wygląd', mul_u_wybor( $b . '[styl]', $p['styl'], mul_style_pol() ) );
	$h .= $pole( 'Przed', '<input type="text" name="' . esc_attr( $b ) . '[przed]" value="' . esc_attr( $p['przed'] ) . '" placeholder="np. , " title="Tekst przed polem, gdy w tej samej linii jest wcześniejsze pole">', 'mul-pd-waskie' );
	$h .= $pole( 'Po', '<input type="text" name="' . esc_attr( $b ) . '[po]" value="' . esc_attr( $p['po'] ) . '" placeholder="np. :" title="Tekst po polu – tylko gdy niżej we wpisie coś jest">', 'mul-pd-waskie' );
	$h .= $pole( 'Podpowiedź w panelu', '<input type="text" name="' . esc_attr( $b ) . '[pomoc]" value="' . esc_attr( $p['pomoc'] ) . '">', 'mul-pd-szer' );
	$h .= '<label class="mul-check mul-pd"><input type="checkbox" name="' . esc_attr( $b ) . '[wymagane]" value="1"' . checked( $p['wymagane'], true, false ) . '> ważne (ostrzeż, gdy puste)</label>';
	if ( $kategorie ) {
		$wyb = array_values( array_intersect( (array) $p['kategorie'], array_column( $kategorie, 'id' ) ) );
		$h  .= '<details class="mul-pd mul-pd-kat"><summary>Kategorie: ' . ( $wyb ? 'tylko ' . count( $wyb ) . ' wybrane' : 'wszystkie' ) . '</summary><fieldset><legend class="screen-reader-text">Tylko w kategoriach</legend><p class="description">Zaznacz, jeśli pole ma być tylko przy wpisach wybranych kategorii (nic = we wszystkich).</p>';
		foreach ( $kategorie as $k ) {
			$h .= '<label class="mul-check"><input type="checkbox" name="' . esc_attr( $b ) . '[kategorie][]" value="' . esc_attr( $k['id'] ) . '"' . checked( in_array( $k['id'], (array) $p['kategorie'], true ), true, false ) . '> ' . esc_html( $k['nazwa'] ) . '</label>';
		}
		$h .= '</fieldset></details>';
	}
	$h .= '<label class="mul-check mul-pd mul-pd-usun"><input type="checkbox" name="' . esc_attr( $b ) . '[usun]" value="1"> usuń pole (wpisane wartości zostają w bazie)</label>';
	return $h . '</div>';
}

function mul_strona_ustawien() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$listy  = mul_listy();
	$szabl  = mul_szablony_pol();
	$typy   = array_map( function ( $t ) { return $t['nazwa']; }, $szabl );
	$zakl   = mul_strony_z_zakladkami();
	$msg    = isset( $_GET['mul'] ) ? sanitize_text_field( wp_unslash( $_GET['mul'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="wrap mul mul-ustawienia">
		<h1>Listy – ustawienia</h1>
		<?php if ( 'zapisano' === $msg ) : ?>
			<div class="notice notice-success is-dismissible"><p>Zapisano ustawienia. Strony z listami pokazują już nową wersję.</p></div>
		<?php elseif ( 'usunieto' === $msg ) : ?>
			<div class="notice notice-success is-dismissible"><p>Lista usunięta.</p></div>
		<?php elseif ( 0 === strpos( $msg, 'dodano-' ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>Dodano listę. Wpisy dodasz w menu <a href="<?php echo esc_url( admin_url( 'admin.php?page=moveup-listy-' . substr( $msg, 7 ) ) ); ?>">Listy</a>, a na stronę wstawisz ją blokiem „Lista moveUP”.</p></div>
		<?php elseif ( 'json' === $msg ) : ?>
			<div class="notice notice-error"><p>To nie jest poprawny JSON – nic nie zmieniono.</p></div>
		<?php endif; ?>
		<p>Listy wpisów (wywiady, konferencje, publikacje…) edytowane w menu <strong>Listy</strong>. Tu ustawiasz, czym jest każda lista i jak wygląda na stronie. Na stronę wstawiasz ją blokiem <strong>„Lista moveUP”</strong> w edytorze (szukaj: „lista”).</p>

		<form method="post" id="mul-ustawienia">
			<?php wp_nonce_field( 'mul_ustawienia' ); ?>
			<input type="hidden" name="mul_ustawienia" value="1">

			<?php foreach ( $listy as $id => $l ) : $l = mul_lista( $id ); $n = 'listy[' . $id . ']'; $w = $l['wyglad']; $dane = mul_dane( $id ); $strony = mul_strony_z_lista( $id ); ?>
				<section class="mul-okno mul-lista-ust" id="lista-<?php echo esc_attr( $id ); ?>">
					<h2><?php echo esc_html( $l['nazwa'] ); ?> <span class="mul-ile">(<?php echo count( $dane['wpisy'] ); ?> wpisów<?php echo $l['kategorie'] ? ', ' . count( $dane['kategorie'] ) . ' kategorii' : ''; ?>)</span></h2>
					<p class="mul-linki-listy"><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=moveup-listy-' . $id ) ); ?>">Edytuj wpisy</a>
						<?php foreach ( $strony as $p ) : ?><a class="button" href="<?php echo esc_url( get_permalink( $p ) ); ?>" target="_blank">Na stronie: <?php echo esc_html( get_the_title( $p ) ); ?></a><?php endforeach; ?>
					</p>

					<h3>Lista</h3>
					<div class="mul-siatka">
						<?php
						mul_u_pole( 'Nazwa', '<input type="text" class="large-text" name="' . esc_attr( $n ) . '[nazwa]" value="' . esc_attr( $l['nazwa'] ) . '">', 'w menu Listy' );
						echo '<input type="hidden" name="' . esc_attr( $n ) . '[typ]" value="' . esc_attr( $l['typ'] ) . '">';
						mul_u_pole( 'Kategorie', '<label class="mul-check"><input type="checkbox" name="' . esc_attr( $n ) . '[kategorie]" value="1"' . checked( $l['kategorie'], true, false ) . '> wpisy w kategoriach</label>', 'np. Podcasty, Programy śniadaniowe… – kategorie dodajesz przy wpisach („Kategorie”)' );
						mul_u_pole( 'Układ na stronie', mul_u_wybor( $n . '[uklad]', $l['uklad'], array( 'tekst' => 'Lista (kategorie jako grupy z nagłówkiem)', 'zakladki' => 'Zakładki – każda kategoria to zakładka' ) ), 'zakładki tylko przy włączonych kategoriach' );
						$opcje = array();
						if ( '' !== $l['szablon'] ) {
							$opcje[''] = 'zapisany wzór (bez zmian)';
						}
						$opcje['brak'] = '— brak wzoru (lista z grupami) —';
						foreach ( $zakl as $z ) {
							$opcje[ (string) $z->ID ] = 'z bloku zakładek: ' . ( $z->post_title ? $z->post_title : '#' . $z->ID );
						}
						mul_u_pole( 'Wygląd zakładek', mul_u_wybor( $n . '[wzor]', '' !== $l['szablon'] ? '' : 'brak', $opcje ), 'Zakładki wyglądają jak wybrany blok zakładek Kadence (kolory, odstępy, ikony). Ułóż go raz na dowolnej stronie albo we wzorcu i wybierz tutaj – w każdej zakładce pierwszy nagłówek = nagłówek kategorii, ostatni blok tekstu = lista.', 'mul-tylko-zakladki' );
						?>
					</div>

					<h3>Pola wpisu</h3>
					<p class="description">Jakie pola ma każdy wpis i jak stoją na stronie. Pola z tym samym numerem linii są w jednej linii (np. „Medium” i „Data” z tekstem „, ” przed datą). „Po” – np. dwukropek po tytule, gdy pod nim jest link. Pole ograniczone do kategorii pokazuje się w panelu tylko przy wpisach tych kategorii.</p>
					<div class="mul-pola-def" data-mul-pola="<?php echo esc_attr( $n ); ?>">
						<?php foreach ( mul_pola( $l ) as $i => $p ) { echo mul_u_wiersz_pola( $n, $i, $p, $l['kategorie'] ? $dane['kategorie'] : array() ); } // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</div>
					<template data-mul-wzor-pola="<?php echo esc_attr( $n ); ?>"><?php echo mul_u_wiersz_pola( $n, '__I__', array(), $l['kategorie'] ? $dane['kategorie'] : array() ); // phpcs:ignore WordPress.Security.EscapeOutput ?></template>
					<p class="mul-pd-przyciski">
						<button type="button" class="button" data-mul-dodaj-pole="<?php echo esc_attr( $n ); ?>">+ Dodaj pole</button>
						<label>Wczytaj zestaw pól: <select data-mul-zestaw="<?php echo esc_attr( $n ); ?>"><option value="">— wybierz —</option><?php foreach ( $typy as $k => $nazwa ) : ?><option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $nazwa ); ?></option><?php endforeach; ?></select></label>
					</p>
					<?php if ( $dane['wpisy'] ) : ?>
						<div class="mul-podglad-wpisu"><span class="description">Pierwszy wpis z zapisanymi ustawieniami:</span><p><?php echo wp_kses_post( mul_wpis_html( mul_pola( $l ), $dane['wpisy'][0], $w ) ); ?></p></div>
					<?php endif; ?>

					<h3>Wygląd wpisów</h3>
					<div class="mul-siatka">
						<?php
						mul_u_pole( 'Odstęp między wpisami (px)', '<input type="number" min="0" max="200" step="1" name="' . esc_attr( $n ) . '[wyglad][odstep]" value="' . esc_attr( $w['odstep'] ) . '" placeholder="pusta linia">', 'puste = pusta linia, jak w zwykłym tekście' );
						mul_u_pole( 'Odstęp przed kolejną grupą (px)', '<input type="number" min="0" max="200" step="1" name="' . esc_attr( $n ) . '[wyglad][odstep_grupy]" value="' . esc_attr( $w['odstep_grupy'] ) . '" placeholder="dwie puste linie">', 'np. przed „SPOTKANIA AUTORSKIE:”; puste = dwie puste linie' );
						mul_u_pole( 'Tekst linku', '<input type="text" class="large-text" name="' . esc_attr( $n ) . '[wyglad][link_tekst]" value="' . esc_attr( $w['link_tekst'] ) . '" placeholder="adres strony">', 'puste = pełny adres (jak dotąd); np. „Obejrzyj” albo „Przeczytaj”' );
						mul_u_pole( 'Opcje', '<input type="hidden" name="' . esc_attr( $n ) . '[wyglad][pogrubienie]" value="1"><label class="mul-check"><input type="checkbox" name="' . esc_attr( $n ) . '[wyglad][nowa_karta]" value="1"' . checked( $w['nowa_karta'], 1, false ) . '> linki w nowej karcie</label>', 'pogrubienie i cudzysłów ustawiasz przy polach' );
						?>
					</div>
					<p class="description">Czcionka, kolor i marginesy całego bloku – jak blok, w którym stoi lista (w edytorze strony).</p>

					<h3>Na stronie</h3>
					<p>Blok <strong>„Lista moveUP”</strong> w edytorze → wybierz „<?php echo esc_html( $l['nazwa'] ); ?>”. Albo wstawka (np. w bloku tekstu): <code class="mul-kod"><?php echo esc_html( 'zakladki' === $l['uklad'] ? '[moveup_lista lista="' . $id . '" uklad="zakladki"]' : '[moveup_lista lista="' . $id . '"]' ); ?></code></p>

					<details class="mul-usun">
						<summary>Usuń listę</summary>
						<label class="mul-check"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[usun]" value="1" data-mul-usun="<?php echo esc_attr( $l['nazwa'] ); ?>"> usuń listę „<?php echo esc_html( $l['nazwa'] ); ?>” razem z <?php echo count( $dane['wpisy'] ); ?> wpisami (po „Zapisz ustawienia”; nie da się cofnąć)</label>
					</details>
				</section>
			<?php endforeach; ?>

			<section class="mul-okno" id="lista-nowa">
				<h2>Nowa lista</h2>
				<div class="mul-siatka">
					<?php
					mul_u_pole( 'Nazwa', '<input type="text" class="large-text" name="nowa[nazwa]" value="" placeholder="np. Media o nas">', 'zostaw puste, jeśli nie dodajesz' );
					mul_u_pole( 'Zestaw pól na start', mul_u_wybor( 'nowa[typ]', 'prosta', $typy ), 'pola zmienisz po dodaniu listy' );
					mul_u_pole( 'Kategorie', '<label class="mul-check"><input type="checkbox" name="nowa[kategorie]" value="1"> wpisy w kategoriach</label>' );
					mul_u_pole( 'Układ na stronie', mul_u_wybor( 'nowa[uklad]', 'tekst', array( 'tekst' => 'Lista (kategorie jako grupy z nagłówkiem)', 'zakladki' => 'Zakładki – każda kategoria to zakładka' ) ) );
					?>
				</div>
			</section>

			<details class="mul-zaawansowane">
				<summary>Zaawansowane (dla moveUP): ustawienia w JSON</summary>
				<?php $json = wp_json_encode( $listy, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?>
				<textarea name="mul_json" rows="12" class="large-text code"><?php echo esc_textarea( $json ); ?></textarea>
				<textarea name="mul_json_przed" hidden><?php echo esc_textarea( $json ); ?></textarea>
				<p class="description">Zmiana tutaj zastępuje wszystkie ustawienia powyżej.</p>
			</details>

			<div class="mul-zapis"><button type="submit" class="button button-primary button-hero">Zapisz ustawienia</button></div>
		</form>
	</div>
	<script>
	( function () {
		var f = document.getElementById( 'mul-ustawienia' );
		// pole „Wygląd zakładek” tylko przy układzie zakładek
		function pokaz() {
			f.querySelectorAll( '.mul-lista-ust' ).forEach( function ( s ) {
				var u = s.querySelector( 'select[name$="[uklad]"]' ), p = s.querySelector( '.mul-tylko-zakladki' );
				if ( u && p ) { p.hidden = u.value !== 'zakladki'; }
			} );
		}
		f.addEventListener( 'change', pokaz );
		pokaz();
		// „Format daty” tylko przy polach typu data
		function formaty() {
			f.querySelectorAll( '[data-mul-pole]' ).forEach( function ( w ) {
				var t = w.querySelector( '[name$="[typ]"]' ), fm = w.querySelector( '.mul-pd-format' );
				if ( t && fm ) { fm.hidden = t.value !== 'data'; }
			} );
		}
		f.addEventListener( 'change', formaty );
		f.addEventListener( 'click', function () { setTimeout( formaty, 0 ); } );
		formaty();
		var ZESTAWY = <?php echo wp_json_encode( $szabl, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
		function nowyWiersz( n, p ) {
			var t = f.querySelector( 'template[data-mul-wzor-pola="' + n + '"]' );
			var div = document.createElement( 'div' );
			div.innerHTML = t.innerHTML.split( '__I__' ).join( 'n' + Date.now().toString( 36 ) + Math.floor( Math.random() * 1000 ) );
			var w = div.firstElementChild;
			if ( p ) {
				[ 'klucz', 'etykieta', 'typ', 'format', 'linia', 'styl', 'przed', 'po', 'pomoc' ].forEach( function ( k ) { var e = w.querySelector( '[name$="[' + k + ']"]' ); if ( e && p[k] !== undefined ) { e.value = p[k]; } } );
				var wy = w.querySelector( '[name$="[wymagane]"]' ); if ( wy ) { wy.checked = !! p.wymagane; }
			}
			return w;
		}
		f.addEventListener( 'click', function ( e ) {
			var d = e.target.closest( '[data-mul-dodaj-pole]' );
			if ( d ) {
				var n = d.getAttribute( 'data-mul-dodaj-pole' );
				var box = f.querySelector( '[data-mul-pola="' + n + '"]' );
				var ost = box.querySelectorAll( '[name$="[linia]"]' );
				var w = nowyWiersz( n, { linia: ost.length ? +ost[ ost.length - 1 ].value + 1 : 1 } );
				box.appendChild( w );
				w.querySelector( '[name$="[etykieta]"]' ).focus();
				return;
			}
			var r = e.target.closest( '[data-mul-pole-ruch]' );
			if ( r ) {
				var wiersz = r.closest( '[data-mul-pole]' ), kier = +r.getAttribute( 'data-mul-pole-ruch' );
				var obok = kier < 0 ? wiersz.previousElementSibling : wiersz.nextElementSibling;
				if ( obok ) { if ( kier < 0 ) { obok.before( wiersz ); } else { obok.after( wiersz ); } r.focus(); }
			}
		} );
		f.addEventListener( 'change', function ( e ) {
			var z = e.target.closest( '[data-mul-zestaw]' );
			if ( ! z || ! z.value ) { return; }
			var n = z.getAttribute( 'data-mul-zestaw' ), zestaw = ZESTAWY[ z.value ];
			if ( zestaw && window.confirm( 'Zastąpić pola tej listy zestawem „' + zestaw.nazwa + '”? Wpisane wartości pól o innych nazwach zostaną w bazie, ale nie będą widoczne. Zmiana zapisze się po „Zapisz ustawienia”.' ) ) {
				var box = f.querySelector( '[data-mul-pola="' + n + '"]' );
				box.innerHTML = '';
				zestaw.pola.forEach( function ( p ) { box.appendChild( nowyWiersz( n, p ) ); } );
				f.querySelector( 'input[name="' + n + '[typ]"]' ).value = z.value;
			}
			z.value = '';
		} );
		f.addEventListener( 'submit', function ( e ) {
			var u = [].slice.call( f.querySelectorAll( '[data-mul-usun]:checked' ) ).map( function ( c ) { return '„' + c.getAttribute( 'data-mul-usun' ) + '”'; } );
			if ( u.length && ! window.confirm( 'Usunąć ' + u.join( ', ' ) + ' razem ze wszystkimi wpisami? Tego nie da się cofnąć.' ) ) { e.preventDefault(); }
		} );
	}() );
	</script>
	<?php
}
