/* moveUP – Social: panel – dodawanie i usuwanie kart, wybór zdjęcia profilu z biblioteki mediów. */
( function () {
	var licznik = Date.now();

	document.addEventListener( 'click', function ( e ) {
		var dodaj = e.target.closest( '[data-mus-dodaj]' );
		if ( dodaj ) {
			var rodzaj = dodaj.getAttribute( 'data-mus-dodaj' );
			var wzor = document.getElementById( 'mus-wzor-' + rodzaj );
			var lista = document.querySelector( '[data-mus-lista="' + rodzaj + '"]' );
			if ( wzor && lista ) {
				var html = wzor.innerHTML.replace( /__i__/g, 'n' + ( licznik++ ) );
				lista.insertAdjacentHTML( 'beforeend', html );
				var nowa = lista.lastElementChild;
				var pole = nowa.querySelector( 'input:not([type=hidden]), select' );
				if ( pole ) {
					pole.focus();
				}
			}
			return;
		}
		var usun = e.target.closest( '[data-mus-usun]' );
		if ( usun ) {
			var karta = usun.closest( '[data-mus-karta]' );
			var nazwa = karta.querySelector( 'legend' ).textContent.trim();
			if ( window.confirm( 'Usunąć „' + nazwa + '”? Zmiana zapisze się po kliknięciu „Zapisz ustawienia”.' ) ) {
				var obok = karta.nextElementSibling || karta.previousElementSibling;
				karta.remove();
				var cel = obok ? obok.querySelector( 'legend' ) : document.querySelector( '[data-mus-dodaj]' );
				if ( cel ) {
					cel.setAttribute( 'tabindex', '-1' );
					cel.focus();
				}
			}
			return;
		}
		var media = e.target.closest( '[data-mus-media]' );
		if ( media && window.wp && wp.media ) {
			var pole = media.parentNode.querySelector( 'input' );
			var okno = wp.media( { title: 'Zdjęcie profilu', library: { type: 'image' }, multiple: false, button: { text: 'Wybierz' } } );
			okno.on( 'select', function () {
				var a = okno.state().get( 'selection' ).first().toJSON();
				var rozmiar = a.sizes && ( a.sizes.thumbnail || a.sizes.medium );
				pole.value = rozmiar ? rozmiar.url : a.url;
				pole.dispatchEvent( new Event( 'change' ) );
			} );
			okno.open();
		}
	} );
} )();
