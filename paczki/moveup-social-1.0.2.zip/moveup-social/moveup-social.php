<?php
/**
 * Plugin Name: moveUP – Social
 * Description: Ostatnie posty z Facebooka i Instagrama (kanały RSS) na stronie – kilka profili w jednym feedzie, do wyboru siatka, karuzela albo lista, zdjęcia w wybranych proporcjach, data, godzina, tekst i link pod zdjęciem, obok niego albo na zdjęciu po najechaniu. Zdjęcia zapisywane na serwerze strony – odwiedzający nie łączą się z Facebookiem ani Instagramem. Ustawienia → Social, w treści: [moveup_social feed="…"].
 * Version: 1.0.2
 * Author: moveUP Agency
 * Text Domain: moveup-social
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-social' );

define( 'MUS_VER', '1.0.2' );
define( 'MUS_URL', plugin_dir_url( __FILE__ ) );
define( 'MUS_OPCJA', 'mu_social' );
define( 'MUS_CRON', 'mu_social_odswiez' );

/* -------------------------------------------------------------------------
 * Ustawienia: źródła (kanały RSS) i feedy (co i jak pokazać)
 * ---------------------------------------------------------------------- */

/** Serwisy – nazwy do tekstów linków i opisów dla czytników ekranu. */
function mus_serwisy() {
	return array(
		'facebook'  => array( 'nazwa' => 'Facebook', 'na' => 'na Facebooku', 'z' => 'z Facebooka' ),
		'instagram' => array( 'nazwa' => 'Instagram', 'na' => 'na Instagramie', 'z' => 'z Instagrama' ),
	);
}

function mus_zrodlo_domyslne() {
	return array(
		'id'       => '',
		'nazwa'    => '',          // np. @pani_od_narkotykow albo nazwa strony
		'serwis'   => 'facebook',
		'rss'      => '',
		'profil'   => '',          // adres profilu
		'awatar'   => '',          // zdjęcie profilu (biblioteka mediów)
		'przycisk' => '',          // np. „Obserwuj na Instagramie”; puste – bez przycisku
	);
}

function mus_feed_domyslny() {
	return array(
		'id'          => '',
		'nazwa'       => '',
		'zrodla'      => array(),
		'uklad'       => 'siatka',   // siatka | karuzela | lista
		'telefon'     => 'siatka',   // siatka | pasek (przewijany palcem) – układ siatki na telefonie i tablecie
		'proporcje'   => '1/1',      // 1/1 | 4/5 | 3/4 | 16/9
		'kol_d'       => 3,
		'kol_t'       => 2,
		'kol_m'       => 1,
		'liczba'      => 6,
		'wiersze'     => 0,          // 0 – wszystkie posty od razu; >0 – tyle rzędów, reszta pod „Wczytaj więcej postów”
		'szczegoly'   => 'pod',      // pod | obok | nakladka (na zdjęciu po najechaniu) | brak (same zdjęcia)
		'data'        => 1,
		'godzina'     => 0,
		'tekst'       => 'skrot',    // brak | skrot (kilka linii, „Czytaj więcej”) | caly
		'linie'       => 4,
		'zrodlo'      => 0,          // nazwa profilu przy poście (przydaje się, gdy feed ma kilka źródeł)
		'link'        => 1,          // „Zobacz post na …”
		'profile'     => 'brak',     // brak | gora – zdjęcie i nazwa profilu z przyciskiem nad postami
		'przyciski'   => 'dol',      // gora | dol | brak – gdzie przyciski „Obserwuj”; przy profile=gora na telefonie zawsze na dole
		'tytul'       => '',
		'podtytul'    => '',
		'kolor'       => '',         // akcent: nazwy, linki, data
		'p_tlo'       => '',         // przycisk: tło
		'p_tekst'     => '',         // przycisk: tekst
		'p_hover'     => '',         // przycisk: tło po najechaniu
		'p_czcionka'  => '',         // przycisk: krój (puste – jak na stronie)
		'karta'       => '',         // tło karty (pod/obok); puste – przezroczyste
		'zaokr'       => 0,          // zaokrąglenie zdjęć i kart (px)
		'odstep'      => 20,         // odstęp między postami (px), komputer
		'odstep_m'    => 12,         // telefon
		'margines'    => 0,          // odstęp wokół feedu (px), komputer
		'margines_m'  => 0,          // telefon
		'autoplay'    => 0,          // karuzela: sekundy, 0 – bez przewijania
	);
}

function mus_opcje() {
	$o = get_option( MUS_OPCJA, array() );
	$o = is_array( $o ) ? $o : array();
	return array(
		'zrodla' => array_values( array_map( function ( $z ) { return wp_parse_args( (array) $z, mus_zrodlo_domyslne() ); }, (array) ( $o['zrodla'] ?? array() ) ) ),
		'feedy'  => array_values( array_map( function ( $f ) { return wp_parse_args( (array) $f, mus_feed_domyslny() ); }, (array) ( $o['feedy'] ?? array() ) ) ),
	);
}

function mus_zrodlo( $id ) {
	foreach ( mus_opcje()['zrodla'] as $z ) {
		if ( $z['id'] === $id ) {
			return $z;
		}
	}
	return null;
}

function mus_feed( $id = '' ) {
	$feedy = mus_opcje()['feedy'];
	foreach ( $feedy as $f ) {
		if ( $f['id'] === $id ) {
			return $f;
		}
	}
	return ( '' === $id && $feedy ) ? $feedy[0] : null;
}

/** Kolor CSS (#rgb, #rrggbb, #rrggbbaa) albo pusty. */
function mus_kolor( $v ) {
	$v = trim( (string) $v );
	return preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $v ) ? strtolower( $v ) : '';
}

function mus_oczysc( $v ) {
	$v      = is_array( $v ) ? $v : array();
	$zrodla = array();
	$uzyte  = array();
	foreach ( (array) ( $v['zrodla'] ?? array() ) as $z ) {
		$z = (array) $z;
		if ( empty( $z['rss'] ) && empty( $z['nazwa'] ) ) {
			continue; // pusty wiersz
		}
		$id = sanitize_key( $z['id'] ?? '' );
		if ( ! $id || isset( $uzyte[ $id ] ) ) {
			$id = sanitize_key( sanitize_title( $z['nazwa'] ?? '' ) ) ?: 'zrodlo';
			$baza = $id;
			for ( $i = 2; isset( $uzyte[ $id ] ); $i++ ) {
				$id = $baza . '-' . $i;
			}
		}
		$uzyte[ $id ] = true;
		$zrodla[]     = array(
			'id'       => $id,
			'nazwa'    => sanitize_text_field( $z['nazwa'] ?? '' ),
			'serwis'   => 'instagram' === ( $z['serwis'] ?? '' ) ? 'instagram' : 'facebook',
			'rss'      => esc_url_raw( $z['rss'] ?? '' ),
			'profil'   => esc_url_raw( $z['profil'] ?? '' ),
			'awatar'   => esc_url_raw( $z['awatar'] ?? '' ),
			'przycisk' => sanitize_text_field( $z['przycisk'] ?? '' ),
		);
	}
	$ids   = wp_list_pluck( $zrodla, 'id' );
	$feedy = array();
	$uzyte = array();
	$licz  = function ( $x, $min, $max, $dom ) {
		return ( is_numeric( $x ) ) ? min( $max, max( $min, (int) $x ) ) : $dom;
	};
	$jeden = function ( $x, $dozwolone, $dom ) {
		return in_array( $x, $dozwolone, true ) ? $x : $dom;
	};
	foreach ( (array) ( $v['feedy'] ?? array() ) as $f ) {
		$f = wp_parse_args( (array) $f, mus_feed_domyslny() );
		$id = sanitize_key( $f['id'] ) ?: ( sanitize_key( sanitize_title( $f['nazwa'] ) ) ?: 'feed' );
		$baza = $id;
		for ( $i = 2; isset( $uzyte[ $id ] ); $i++ ) {
			$id = $baza . '-' . $i;
		}
		$uzyte[ $id ] = true;
		$d            = mus_feed_domyslny();
		$feedy[]      = array(
			'id'         => $id,
			'nazwa'      => sanitize_text_field( $f['nazwa'] ),
			'zrodla'     => array_values( array_intersect( array_map( 'sanitize_key', (array) $f['zrodla'] ), $ids ) ),
			'uklad'      => $jeden( $f['uklad'], array( 'siatka', 'karuzela', 'lista' ), 'siatka' ),
			'telefon'    => $jeden( $f['telefon'], array( 'siatka', 'pasek' ), 'siatka' ),
			'proporcje'  => $jeden( $f['proporcje'], array( '1/1', '4/5', '3/4', '16/9' ), '1/1' ),
			'kol_d'      => $licz( $f['kol_d'], 1, 6, $d['kol_d'] ),
			'kol_t'      => $licz( $f['kol_t'], 1, 4, $d['kol_t'] ),
			'kol_m'      => $licz( $f['kol_m'], 1, 3, $d['kol_m'] ),
			'liczba'     => $licz( $f['liczba'], 1, 30, $d['liczba'] ),
			'wiersze'    => $licz( $f['wiersze'], 0, 10, 0 ),
			'szczegoly'  => $jeden( $f['szczegoly'], array( 'pod', 'obok', 'nakladka', 'brak' ), 'pod' ),
			'data'       => empty( $f['data'] ) ? 0 : 1,
			'godzina'    => empty( $f['godzina'] ) ? 0 : 1,
			'tekst'      => $jeden( $f['tekst'], array( 'brak', 'skrot', 'caly' ), 'skrot' ),
			'linie'      => $licz( $f['linie'], 1, 12, 4 ),
			'zrodlo'     => empty( $f['zrodlo'] ) ? 0 : 1,
			'link'       => empty( $f['link'] ) ? 0 : 1,
			'profile'    => $jeden( $f['profile'], array( 'brak', 'gora' ), 'brak' ),
			'przyciski'  => $jeden( $f['przyciski'], array( 'gora', 'dol', 'brak' ), 'dol' ),
			'tytul'      => sanitize_text_field( $f['tytul'] ),
			'podtytul'   => sanitize_text_field( $f['podtytul'] ),
			'kolor'      => mus_kolor( $f['kolor'] ),
			'p_tlo'      => mus_kolor( $f['p_tlo'] ),
			'p_tekst'    => mus_kolor( $f['p_tekst'] ),
			'p_hover'    => mus_kolor( $f['p_hover'] ),
			'p_czcionka' => preg_replace( '/[^\p{L}0-9 ,"\'\-]/u', '', (string) $f['p_czcionka'] ),
			'karta'      => mus_kolor( $f['karta'] ),
			'zaokr'      => $licz( $f['zaokr'], 0, 40, 0 ),
			'odstep'     => $licz( $f['odstep'], 0, 60, 20 ),
			'odstep_m'   => $licz( $f['odstep_m'], 0, 40, 12 ),
			'margines'   => $licz( $f['margines'], 0, 80, 0 ),
			'margines_m' => $licz( $f['margines_m'], 0, 40, 0 ),
			'autoplay'   => $licz( $f['autoplay'], 0, 30, 0 ),
		);
	}
	return array( 'zrodla' => $zrodla, 'feedy' => $feedy );
}

/* -------------------------------------------------------------------------
 * Cron: odświeżanie źródeł co godzinę
 * ---------------------------------------------------------------------- */
register_activation_hook( __FILE__, function () {
	if ( ! wp_next_scheduled( MUS_CRON ) ) {
		wp_schedule_event( time() + 60, 'hourly', MUS_CRON );
	}
} );
register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( MUS_CRON );
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( MUS_CRON ) ) {
		wp_schedule_event( time() + 60, 'hourly', MUS_CRON );
	}
} );
add_action( MUS_CRON, 'mus_odswiez_wszystko' );

require_once __DIR__ . '/includes/pobieranie.php';
require_once __DIR__ . '/includes/wyswietlanie.php';
if ( is_admin() ) {
	require_once __DIR__ . '/includes/panel.php';
}
