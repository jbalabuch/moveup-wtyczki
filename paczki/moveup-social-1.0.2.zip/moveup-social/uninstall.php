<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
$o = get_option( 'mu_social', array() );
foreach ( (array) ( $o['zrodla'] ?? array() ) as $z ) {
	delete_option( 'mu_social_posty_' . sanitize_key( $z['id'] ?? '' ) );
}
foreach ( (array) get_option( 'mu_social_znane', array() ) as $id ) {
	delete_option( 'mu_social_posty_' . sanitize_key( $id ) );
}
delete_option( 'mu_social' );
delete_option( 'mu_social_znane' );
wp_clear_scheduled_hook( 'mu_social_odswiez' );
$k = wp_upload_dir();
foreach ( glob( trailingslashit( $k['basedir'] ) . 'moveup-social/*.webp' ) ?: array() as $plik ) {
	wp_delete_file( $plik );
}
@rmdir( trailingslashit( $k['basedir'] ) . 'moveup-social' );
