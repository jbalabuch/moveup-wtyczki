<?php
/**
 * Plugin Name: moveUP – Instrukcja
 * Description: Instrukcja obsługi strony w kokpicie: kafelki z ikonami (Kadra, Jadłospisy, Stopka…), po kliknięciu okno z opisem, co i gdzie edytować. Treść dla każdej strony osobno – Ustawienia → Instrukcja (edytor sekcji albo import JSON).
 * Version: 1.1.0
 * Author: moveUP Agency
 * Text Domain: moveup-instrukcja
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-instrukcja' );

define( 'MU_INSTR_VER', '1.1.0' );
define( 'MU_INSTR_OPCJA', 'moveup_instrukcja' );

/**
 * Treść instrukcji: [ 'tytul' => …, 'wstep' => html, 'sekcje' => [ [ 'ikona' => 'dashicons-groups', 'tytul' => …, 'tresc' => html ] ], 'stopka' => html ].
 * Ikony: nazwy Dashicons WordPressa (https://developer.wordpress.org/resource/dashicons/).
 */
function mu_instr_dane() {
	$d = get_option( MU_INSTR_OPCJA, array() );
	return is_array( $d ) ? $d : array();
}

/** Oczyszczenie importu: tylko znane pola, HTML jak we wpisach (wp_kses_post), ikona – sama nazwa klasy Dashicons. */
function mu_instr_oczysc( $d ) {
	$w = array(
		'tytul'  => sanitize_text_field( $d['tytul'] ?? 'Instrukcja strony' ),
		'wstep'  => wp_kses_post( $d['wstep'] ?? '' ),
		'stopka' => wp_kses_post( $d['stopka'] ?? '' ),
		'sekcje' => array(),
	);
	foreach ( (array) ( $d['sekcje'] ?? array() ) as $s ) {
		if ( empty( $s['tytul'] ) || empty( $s['tresc'] ) ) {
			continue;
		}
		$ikona         = preg_replace( '/[^a-z0-9-]/', '', strtolower( (string) ( $s['ikona'] ?? '' ) ) );
		$w['sekcje'][] = array(
			'ikona' => 0 === strpos( $ikona, 'dashicons-' ) ? $ikona : 'dashicons-info-outline',
			'tytul' => sanitize_text_field( $s['tytul'] ),
			'opis'  => sanitize_text_field( $s['opis'] ?? '' ),
			'tresc' => wp_kses_post( $s['tresc'] ),
		);
	}
	return $w;
}

/* -------------------------------------------------------------------------
 * Widżet w kokpicie
 * ---------------------------------------------------------------------- */

add_action( 'wp_dashboard_setup', function () {
	$d = mu_instr_dane();
	if ( empty( $d['sekcje'] ) || ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	// na samą górę pierwszej kolumny (grupa „high” – przed widżetami innych wtyczek, np. Rank Math, CookieYes)
	wp_add_dashboard_widget( 'moveup_instrukcja', esc_html( $d['tytul'] ?: 'Instrukcja strony' ), 'mu_instr_widzet', null, null, 'normal', 'high' );
}, 1 );

function mu_instr_widzet() {
	$d = mu_instr_dane();
	if ( ! empty( $d['wstep'] ) ) {
		echo '<div class="mu-instr__wstep">' . wp_kses_post( wpautop( $d['wstep'] ) ) . '</div>';
	}
	echo '<ul class="mu-instr__kafle">';
	foreach ( $d['sekcje'] as $i => $s ) {
		printf(
			'<li><button type="button" class="mu-instr__kafel" data-sekcja="%1$d" aria-haspopup="dialog"><span class="dashicons %2$s" aria-hidden="true"></span><span class="mu-instr__nazwa">%3$s</span>%4$s</button></li>',
			(int) $i,
			esc_attr( $s['ikona'] ),
			esc_html( $s['tytul'] ),
			$s['opis'] ? '<span class="mu-instr__opis">' . esc_html( $s['opis'] ) . '</span>' : ''
		);
	}
	echo '</ul>';
	foreach ( $d['sekcje'] as $i => $s ) {
		printf( '<template id="mu-instr-%1$d" data-tytul="%2$s" data-ikona="%3$s">%4$s</template>', (int) $i, esc_attr( $s['tytul'] ), esc_attr( $s['ikona'] ), wp_kses_post( wpautop( $s['tresc'] ) ) );
	}
	if ( ! empty( $d['stopka'] ) ) {
		echo '<div class="mu-instr__stopka">' . wp_kses_post( wpautop( $d['stopka'] ) ) . '</div>';
	}
	?>
	<dialog class="mu-instr__okno" aria-labelledby="mu-instr-tytul">
		<div class="mu-instr__okno-glowa">
			<span class="dashicons" aria-hidden="true"></span>
			<h2 id="mu-instr-tytul"></h2>
			<button type="button" class="mu-instr__zamknij" aria-label="<?php esc_attr_e( 'Zamknij', 'moveup-instrukcja' ); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
		</div>
		<div class="mu-instr__tresc"></div>
	</dialog>
	<?php
}

add_action( 'admin_head-index.php', function () {
	if ( empty( mu_instr_dane()['sekcje'] ) ) {
		return;
	}
	?>
	<style id="moveup-instrukcja">
	#moveup_instrukcja .inside{margin:0;padding:12px 16px 16px}
	.mu-instr__wstep p{margin:0 0 12px;color:#50575e}
	.mu-instr__kafle{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:0;padding:0;list-style:none}
	.mu-instr__kafle li{margin:0}
	.mu-instr__kafel{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:6px;width:100%;height:100%;min-height:104px;padding:14px 10px 12px;border:1px solid #dcdcde;border-radius:10px;background:#fff;color:#1d2327;font:inherit;text-align:center;cursor:pointer;transition:border-color .15s,background .15s,box-shadow .15s}
	.mu-instr__kafel:hover{border-color:var(--wp-admin-theme-color,#2271b1);background:#f6f7f7}
	.mu-instr__kafel:focus-visible{outline:2px solid var(--wp-admin-theme-color,#2271b1);outline-offset:2px}
	.mu-instr__kafel .dashicons{width:32px;height:32px;font-size:32px;color:var(--wp-admin-theme-color,#2271b1)}
	.mu-instr__nazwa{font-weight:600;font-size:13px;line-height:1.3}
	.mu-instr__opis{font-size:12px;line-height:1.35;color:#646970}
	.mu-instr__stopka p{margin:14px 0 0;color:#646970;font-size:12px}
	.mu-instr__okno{width:min(720px,calc(100vw - 32px));max-height:min(80vh,760px);padding:0;border:0;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25)}
	.mu-instr__okno::backdrop{background:rgba(0,0,0,.45)}
	.mu-instr__okno-glowa{position:sticky;top:0;display:flex;align-items:center;gap:10px;padding:16px 20px;border-bottom:1px solid #dcdcde;background:#fff}
	.mu-instr__okno-glowa>.dashicons{width:28px;height:28px;font-size:28px;color:var(--wp-admin-theme-color,#2271b1)}
	.mu-instr__okno-glowa h2{flex:1;margin:0;font-size:18px;line-height:1.3}
	.mu-instr__zamknij{display:flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border:0;border-radius:50%;background:#f0f0f1;cursor:pointer}
	.mu-instr__zamknij:hover{background:#dcdcde}
	.mu-instr__zamknij:focus-visible{outline:2px solid var(--wp-admin-theme-color,#2271b1);outline-offset:2px}
	.mu-instr__tresc{padding:16px 24px 24px;font-size:14px;line-height:1.6}
	.mu-instr__tresc p{font-size:14px;margin:0 0 12px}
	.mu-instr__tresc ul,.mu-instr__tresc ol{margin:0 0 12px 20px}
	.mu-instr__tresc ul{list-style:disc}
	.mu-instr__tresc li{margin-bottom:6px}
	.mu-instr__tresc h3{font-size:15px;margin:18px 0 8px}
	</style>
	<?php
} );

add_action( 'admin_footer-index.php', function () {
	if ( empty( mu_instr_dane()['sekcje'] ) ) {
		return;
	}
	?>
	<script id="moveup-instrukcja-js">
	( function () {
		var w = document.getElementById( 'moveup_instrukcja' );
		if ( ! w ) { return; }
		var d = w.querySelector( '.mu-instr__okno' ), ostatni = null;
		if ( ! d || typeof d.showModal !== 'function' ) { return; }
		w.querySelectorAll( '.mu-instr__kafel' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var t = document.getElementById( 'mu-instr-' + b.getAttribute( 'data-sekcja' ) );
				if ( ! t ) { return; }
				ostatni = b;
				d.querySelector( 'h2' ).textContent = t.getAttribute( 'data-tytul' );
				d.querySelector( '.mu-instr__okno-glowa > .dashicons' ).className = 'dashicons ' + t.getAttribute( 'data-ikona' );
				var tr = d.querySelector( '.mu-instr__tresc' );
				tr.innerHTML = '';
				tr.appendChild( t.content.cloneNode( true ) );
				d.showModal();
				d.scrollTop = 0;
				d.querySelector( '.mu-instr__zamknij' ).focus();
			} );
		} );
		d.querySelector( '.mu-instr__zamknij' ).addEventListener( 'click', function () { d.close(); } );
		d.addEventListener( 'click', function ( e ) { if ( e.target === d ) { d.close(); } } ); // kliknięcie w tło
		d.addEventListener( 'close', function () { if ( ostatni ) { ostatni.focus(); } } );
	} )();
	</script>
	<?php
} );

/* -------------------------------------------------------------------------
 * Ustawienia → Instrukcja: import / eksport treści (JSON)
 * ---------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'Instrukcja strony', 'Instrukcja', 'manage_options', 'moveup-instrukcja', 'mu_instr_ustawienia' );
} );

/** Ikony do wyboru w edytorze (Dashicons) – nazwa => opis. */
function mu_instr_ikony() {
	return array(
		'dashicons-edit-page' => 'Edycja strony', 'dashicons-admin-page' => 'Strona', 'dashicons-groups' => 'Ludzie / kadra',
		'dashicons-businessperson' => 'Osoba', 'dashicons-food' => 'Jedzenie / jadłospis', 'dashicons-media-document' => 'Dokument / PDF',
		'dashicons-media-text' => 'Tekst / regulamin', 'dashicons-facebook-alt' => 'Facebook', 'dashicons-instagram' => 'Instagram',
		'dashicons-screenoptions' => 'Sekcje / bloki', 'dashicons-editor-insertmore' => 'Stopka', 'dashicons-menu-alt' => 'Menu',
		'dashicons-warning' => 'Uwaga / błąd', 'dashicons-universal-access-alt' => 'Dostępność', 'dashicons-search' => 'Wyszukiwanie / SEO',
		'dashicons-shield' => 'Bezpieczeństwo / cookies', 'dashicons-lock' => 'Blokada / nie zmieniać', 'dashicons-update' => 'Aktualizacje',
		'dashicons-controls-repeat' => 'Odświeżanie / cache', 'dashicons-format-image' => 'Zdjęcia', 'dashicons-video-alt3' => 'Wideo',
		'dashicons-location' => 'Mapa / dojazd', 'dashicons-phone' => 'Telefon', 'dashicons-email' => 'E-mail', 'dashicons-calendar-alt' => 'Kalendarz',
		'dashicons-chart-bar' => 'Statystyki', 'dashicons-admin-settings' => 'Ustawienia', 'dashicons-admin-links' => 'Linki',
		'dashicons-format-chat' => 'Kontakt / pytania', 'dashicons-heart' => 'Wsparcie', 'dashicons-info-outline' => 'Informacja',
	);
}

/** Zapis z edytora: sekcje z formularza (z polem kolejności i „usuń”), posortowane wg kolejności. */
function mu_instr_z_formularza( $post ) {
	$sekcje = array();
	foreach ( (array) ( $post['sekcje'] ?? array() ) as $s ) {
		if ( ! empty( $s['usun'] ) || '' === trim( (string) ( $s['tytul'] ?? '' ) ) ) {
			continue;
		}
		$sekcje[] = array(
			'kolejnosc' => (int) ( $s['kolejnosc'] ?? 0 ),
			'ikona'     => (string) ( $s['ikona'] ?? '' ),
			'tytul'     => (string) $s['tytul'],
			'opis'      => (string) ( $s['opis'] ?? '' ),
			'tresc'     => (string) ( $s['tresc'] ?? '' ),
		);
	}
	usort( $sekcje, function ( $a, $b ) { return $a['kolejnosc'] <=> $b['kolejnosc']; } );
	return array(
		'tytul'  => (string) ( $post['tytul'] ?? '' ),
		'wstep'  => (string) ( $post['wstep'] ?? '' ),
		'stopka' => (string) ( $post['stopka'] ?? '' ),
		'sekcje' => $sekcje,
	);
}

function mu_instr_ustawienia() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$komunikat = '';
	if ( isset( $_POST['mu_instr_edytor'] ) && check_admin_referer( 'mu_instr_zapisz' ) ) {
		$z = mu_instr_oczysc( mu_instr_z_formularza( wp_unslash( $_POST ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- oczyszczane w mu_instr_oczysc()
		update_option( MU_INSTR_OPCJA, $z, false );
		$komunikat = '<div class="notice notice-success is-dismissible"><p>Instrukcja zapisana (' . count( $z['sekcje'] ) . ' sekcji) – zobacz ją w Kokpicie.</p></div>';
	} elseif ( isset( $_POST['mu_instr_json'] ) && check_admin_referer( 'mu_instr_import' ) ) {
		$d = json_decode( wp_unslash( $_POST['mu_instr_json'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- oczyszczane w mu_instr_oczysc()
		if ( is_array( $d ) && ! empty( $d['sekcje'] ) ) {
			update_option( MU_INSTR_OPCJA, mu_instr_oczysc( $d ), false );
			$komunikat = '<div class="notice notice-success is-dismissible"><p>Instrukcja zaimportowana.</p></div>';
		} else {
			$komunikat = '<div class="notice notice-error"><p>To nie jest poprawny plik JSON instrukcji – nic nie zmieniono.</p></div>';
		}
	}
	$d      = mu_instr_dane();
	$sekcje = $d['sekcje'] ?? array();
	$sekcje[] = array( 'ikona' => 'dashicons-info-outline', 'tytul' => '', 'opis' => '', 'tresc' => '', 'nowa' => true ); // pusta – do dodania nowej
	$ikony  = mu_instr_ikony();
	?>
	<div class="wrap mu-instr-edytor">
		<h1>Instrukcja strony</h1>
		<?php echo $komunikat; // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<p>Treść widżetu „Instrukcja strony” w Kokpicie. Każda sekcja to kafelek z ikoną – po kliknięciu otwiera się jej treść. Kolejność kafelków ustala pole „Kolejność” (mniejsza liczba = wcześniej).</p>
		<form method="post">
			<?php wp_nonce_field( 'mu_instr_zapisz' ); ?>
			<input type="hidden" name="mu_instr_edytor" value="1">
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="mu-instr-tytul-w">Tytuł widżetu</label></th><td><input type="text" id="mu-instr-tytul-w" name="tytul" class="regular-text" value="<?php echo esc_attr( $d['tytul'] ?? 'Instrukcja strony' ); ?>"></td></tr>
				<tr><th scope="row"><label for="mu-instr-wstep">Wstęp</label></th><td><textarea id="mu-instr-wstep" name="wstep" rows="2" class="large-text"><?php echo esc_textarea( wp_strip_all_tags( $d['wstep'] ?? '' ) ); ?></textarea><p class="description">Krótkie zdanie nad kafelkami.</p></td></tr>
				<tr><th scope="row"><label for="mu-instr-stopka">Stopka</label></th><td><textarea id="mu-instr-stopka" name="stopka" rows="2" class="large-text"><?php echo esc_textarea( wp_strip_all_tags( $d['stopka'] ?? '' ) ); ?></textarea><p class="description">Np. kontakt do pomocy technicznej – pod kafelkami.</p></td></tr>
			</table>
			<h2>Sekcje</h2>
			<?php foreach ( $sekcje as $i => $s ) : $nowa = ! empty( $s['nowa'] ); ?>
				<details class="mu-instr-sekcja"<?php echo $nowa ? '' : ''; ?>>
					<summary><span class="dashicons <?php echo esc_attr( $s['ikona'] ); ?>" aria-hidden="true"></span> <?php echo $nowa ? '<strong>+ Dodaj nową sekcję</strong>' : esc_html( $s['tytul'] ); ?></summary>
					<div class="mu-instr-sekcja__pola">
						<p><label>Tytuł<br><input type="text" name="sekcje[<?php echo (int) $i; ?>][tytul]" class="regular-text" value="<?php echo esc_attr( $s['tytul'] ); ?>"></label></p>
						<p><label>Podpis pod kafelkiem (krótko)<br><input type="text" name="sekcje[<?php echo (int) $i; ?>][opis]" class="regular-text" value="<?php echo esc_attr( $s['opis'] ?? '' ); ?>"></label></p>
						<p><label>Ikona<br><select name="sekcje[<?php echo (int) $i; ?>][ikona]" class="mu-instr-ikona">
							<?php foreach ( $ikony as $klasa => $nazwa ) : ?>
								<option value="<?php echo esc_attr( $klasa ); ?>" <?php selected( $s['ikona'], $klasa ); ?>><?php echo esc_html( $nazwa ); ?></option>
							<?php endforeach; ?>
							<?php if ( ! isset( $ikony[ $s['ikona'] ] ) ) : ?><option value="<?php echo esc_attr( $s['ikona'] ); ?>" selected><?php echo esc_html( $s['ikona'] ); ?></option><?php endif; ?>
						</select> <span class="dashicons <?php echo esc_attr( $s['ikona'] ); ?> mu-instr-podglad" aria-hidden="true"></span></label></p>
						<p><label>Kolejność<br><input type="number" name="sekcje[<?php echo (int) $i; ?>][kolejnosc]" class="small-text" value="<?php echo (int) ( ( $i + 1 ) * 10 ); ?>" step="1"></label></p>
						<div><span class="mu-instr-etykieta">Treść</span>
							<?php
							wp_editor( $s['tresc'], 'mu_instr_tresc_' . (int) $i, array(
								'textarea_name' => 'sekcje[' . (int) $i . '][tresc]',
								'textarea_rows' => 10,
								'media_buttons' => false,
								'teeny'         => true,
								'tinymce'       => array( 'toolbar1' => 'bold,italic,bullist,numlist,link,unlink,undo,redo' ),
								'quicktags'     => array( 'buttons' => 'strong,em,ul,ol,li,link' ),
							) );
							?>
						</div>
						<?php if ( ! $nowa ) : ?>
							<p><label><input type="checkbox" name="sekcje[<?php echo (int) $i; ?>][usun]" value="1"> Usuń tę sekcję</label></p>
						<?php else : ?>
							<p class="description">Wpisz tytuł i treść, a potem zapisz – sekcja pojawi się w Kokpicie, a tu pojawi się kolejne puste pole.</p>
						<?php endif; ?>
					</div>
				</details>
			<?php endforeach; ?>
			<?php submit_button( 'Zapisz instrukcję' ); ?>
		</form>

		<details class="mu-instr-zaawansowane">
			<summary>Zaawansowane: import / eksport (JSON)</summary>
			<p>Kopia całej instrukcji – możesz ją skopiować jako zapas albo przenieść na inną stronę z tą wtyczką. Wklejenie i zapisanie zastępuje obecną treść.</p>
			<form method="post">
				<?php wp_nonce_field( 'mu_instr_import' ); ?>
				<textarea name="mu_instr_json" rows="14" class="large-text code" spellcheck="false"><?php echo esc_textarea( ! empty( $d['sekcje'] ) ? wp_json_encode( $d, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : '' ); ?></textarea>
				<?php submit_button( 'Importuj JSON', 'secondary' ); ?>
			</form>
		</details>
	</div>
	<style>
	.mu-instr-sekcja{max-width:900px;margin:0 0 8px;background:#fff;border:1px solid #dcdcde;border-radius:8px}
	.mu-instr-sekcja>summary{display:flex;align-items:center;gap:8px;padding:12px 16px;cursor:pointer;font-size:14px;font-weight:600}
	.mu-instr-sekcja>summary .dashicons{color:var(--wp-admin-theme-color,#2271b1)}
	.mu-instr-sekcja__pola{padding:4px 16px 16px;border-top:1px solid #f0f0f1}
	.mu-instr-etykieta{display:block;margin:6px 0 4px}
	.mu-instr-podglad{vertical-align:middle;font-size:24px;width:24px;height:24px;color:var(--wp-admin-theme-color,#2271b1)}
	.mu-instr-zaawansowane{max-width:900px;margin-top:24px}
	.mu-instr-zaawansowane>summary{cursor:pointer;font-weight:600}
	</style>
	<script>
	document.querySelectorAll( '.mu-instr-ikona' ).forEach( function ( s ) {
		s.addEventListener( 'change', function () {
			var p = s.parentNode.querySelector( '.mu-instr-podglad' );
			if ( p ) { p.className = 'dashicons ' + s.value + ' mu-instr-podglad'; }
		} );
	} );
	</script>
	<?php
}
