=== moveUP – Wydajność ===
Contributors: moveUP Agency
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 1.6.0
License: GPLv2 or later

Poprawki szybkości strony WordPress (Kadence), których nie da się ustawić w panelu. Pierwsze wdrożenie: wyszkow.monar.org (Lighthouse mobile 85 → 93+).

== Co robi ==

– Fonty: zamiast plików Kadence (osobno podzbiór latin i latin-ext, na Wyszkowie 6 plików, ok. 240 KB) – jeden plik na krój, przycięty do znaków potrzebnych po polsku (na Wyszkowie 3 pliki, ok. 79 KB). @font-face wpisane w <head>, więc przeglądarka nie czeka na osobny plik CSS z fontami. Wyłącza preload fontów Kadence.
– Małe pliki CSS z serwera strony (do 15 KB – bloki Kadence, motyw, własne wtyczki) wpisane w kod strony w miejscu <link>, w tej samej kolejności. Na zaczerlany.monar.org: kilkanaście zapytań blokujących wyświetlanie mniej (PageSpeed: „Żądania blokujące renderowanie”). Limit: filtr moveup_wydajnosc_inline_css_limit (0 = wyłączone), wyjątki (uchwyty stylów): moveup_wydajnosc_inline_css_bez. Nie łączy i nie minifikuje – to przy Kadence psuło układ.
– Preload obrazu LCP odkrywanego dopiero z CSS (np. tło sekcji hero) i własny limit wpisywanego CSS – plik strony wp-content/uploads/moveup-wydajnosc/ustawienia.json (od 1.5.0; od 1.5.1 także "defer" – dodatkowe skrypty z defer; opis w kodzie przy mu_wyd_ustawienia). Szkoła Superwizorów TNPU: tło hero strony głównej (SVG) + CSS formularza Kadence 17 KB wpisany w stronę.
– Defer dla skryptów Kadence ładowanych na końcu strony: animacje przy przewijaniu (kadence-aos) i akordeon (kadence-blocks-accordion). Lista do zmiany filtrem moveup_wydajnosc_defer.

– CookieYes z serwera strony (od 1.6.0, ustawienia.json → "cookieyes_lokalnie": true): skrypt startowy CookieYes blokuje wyświetlanie i wymaga połączenia z drugim serwerem (cdn-cookieyes.com) – w symulacji Lighthouse FCP +0,6 s. Wtyczka trzyma kopię tego jednego pliku w wp-content/uploads/moveup-wydajnosc/cookieyes/, odświeża ją co 5 minut (ETag) i podmienia adres w znaczniku; baner, konfiguracja i logi zgód dalej idą z CookieYes. mariabanaszak.pl (staging): mediana 94 → 98. Po publikacji zmian w panelu CookieYes nowa wersja banera pojawia się najpóźniej po 5 minutach (stara działa do tego czasu). Bez świeżej kopii (6 godzin bez odświeżenia) wraca adres CookieYes. Zablokowanie skryptu w teście Lighthouse nie pokazuje tego zysku – symulator i tak dolicza połączenie.

– Leniwe ładowanie od wybranego obrazu (od 1.6.0, ustawienia.json → "obrazy_bez_lazy": 1): WordPress nie dodaje loading="lazy" trzem pierwszym obrazom treści, także gdy drugi i trzeci są poniżej pierwszego ekranu – pobierają się wtedy razem z obrazem LCP.

Ustawienia LiteSpeed Cache, które idą w parze (panel LiteSpeed → Optymalizacja strony): usuwanie emoji WordPressa, preconnect do zewnętrznych skryptów, które blokują render (np. https://cdn-cookieyes.com).

== Fonty na nowej stronie ==

1. Sprawdź w motywie kroje, style i zakres grubości (Kadence → Typografia; plik /wp-content/fonts/*.css).
2. Pobierz fonty zmienne z https://github.com/google/fonts (ofl/<nazwa>/…[wght].ttf).
3. Przytnij fontTools (pip install fonttools brotli):
   – instancer: zakres grubości z motywu, opsz przypięte do domyślnej wartości,
   – subset: U+0020-007E, U+00A0-00FF, U+0104-0107, U+0118-0119, U+0141-0144, U+015A-015B, U+0179-017C, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2010-2027, U+2030, U+2039-203A, U+20AC, U+2122, U+2190-2193, U+2212, U+FEFF, U+FFFD; hinting wyłączony, domyślne funkcje OpenType, woff2.
4. Pliki do folderu strony wp-content/uploads/moveup-wydajnosc/fonty/ + fonty.json w tym samym folderze (family, style, weight – np. "400 700", file, opcjonalnie "preload": true dla fontu tekstu z pierwszego ekranu), licencja OFL obok. Ten folder należy do strony – aktualizacje wtyczki go nie ruszają (od 1.4.0).
   Bez tego folderu wtyczka bierze fonty z assets/fonty/ w paczce (jak do 1.3 – fonty pierwszej strony z paczką; przy aktualizacji z repozytorium paczka się nadpisuje, więc fonty strony trzymaj w folderze strony).
Znaki spoza zestawu przeglądarka bierze z fontu systemowego. Pusty fonty.json = fonty zostają z motywu. Folder można też wskazać filtrem moveup_wydajnosc_fonty_folder ([ścieżka, URL]).

== Pomiar ==

Lighthouse 13 (mobile, Moto G Power). Przy uruchamianiu z wiersza poleceń na macOS dodaj flagi Chrome --disable-backgrounding-occluded-windows --disable-renderer-backgrounding --disable-features=CalculateNativeWinOcclusion – bez nich okno w tle nie rysuje klatek i FCP/LCP wychodzą zawyżone o ponad sekundę.

== Aktualizacje ==

Od wersji 1.3.0 wtyczka sama sprawdza nowe wersje w https://github.com/jbalabuch/moveup-wtyczki (plik wtyczki.json) – aktualizacja pojawia się w Kokpit → Aktualizacje, można włączyć automatyczne aktualizacje. Nagłówek „Update URI” sprawia, że WordPress nie myli wtyczki z wtyczką o tej samej nazwie na wordpress.org.
