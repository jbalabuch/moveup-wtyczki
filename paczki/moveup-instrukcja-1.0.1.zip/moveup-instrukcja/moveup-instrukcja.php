<?php
/**
 * Plugin Name: moveUP – Instrukcja
 * Description: Instrukcja obsługi strony w kokpicie: kafelki z ikonami (Kadra, Jadłospisy, Stopka…), po kliknięciu okno z opisem, co i gdzie edytować. Treść instrukcji dla każdej strony osobno – Ustawienia → Instrukcja (import pliku JSON).
 * Version: 1.0.1
 * Author: moveUP Agency
 * Text Domain: moveup-instrukcja
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-instrukcja' );

define( 'MU_INSTR_VER', '1.0.1' );
define( 'MU_INSTR_OPCJA', 'moveup_instrukcja' );

/**
 * Treść instrukcji: [ 'tytul' => …, 'wstep' => html, 'sekcje' => [ [ 'ikona' => 'dashicons-groups', 'tytul' => …, 'tresc' => html ] ], 'stopka' => html ].
 * Ikony: nazwy Dashicons WordPressa (https://developer.wordpress.org/resource/dashicons/).
 */
function mu_instr_dane() {
	$d = get_option( MU_INSTR_OPCJA, array() );
	return is_array( $d ) ? $d : array();
}

/** Oczyszczenie importu: tylko znane pola, HTML jak we wpisach (wp_kses_post), ikona – sama nazwa klasy Dashicons. */
function mu_instr_oczysc( $d ) {
	$w = array(
		'tytul'  => sanitize_text_field( $d['tytul'] ?? 'Instrukcja strony' ),
		'wstep'  => wp_kses_post( $d['wstep'] ?? '' ),
		'stopka' => wp_kses_post( $d['stopka'] ?? '' ),
		'sekcje' => array(),
	);
	foreach ( (array) ( $d['sekcje'] ?? array() ) as $s ) {
		if ( empty( $s['tytul'] ) || empty( $s['tresc'] ) ) {
			continue;
		}
		$ikona         = preg_replace( '/[^a-z0-9-]/', '', strtolower( (string) ( $s['ikona'] ?? '' ) ) );
		$w['sekcje'][] = array(
			'ikona' => 0 === strpos( $ikona, 'dashicons-' ) ? $ikona : 'dashicons-info-outline',
			'tytul' => sanitize_text_field( $s['tytul'] ),
			'opis'  => sanitize_text_field( $s['opis'] ?? '' ),
			'tresc' => wp_kses_post( $s['tresc'] ),
		);
	}
	return $w;
}

/* -------------------------------------------------------------------------
 * Widżet w kokpicie
 * ---------------------------------------------------------------------- */

add_action( 'wp_dashboard_setup', function () {
	$d = mu_instr_dane();
	if ( empty( $d['sekcje'] ) || ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	// na samą górę pierwszej kolumny (grupa „high” – przed widżetami innych wtyczek, np. Rank Math, CookieYes)
	wp_add_dashboard_widget( 'moveup_instrukcja', esc_html( $d['tytul'] ?: 'Instrukcja strony' ), 'mu_instr_widzet', null, null, 'normal', 'high' );
}, 1 );

function mu_instr_widzet() {
	$d = mu_instr_dane();
	if ( ! empty( $d['wstep'] ) ) {
		echo '<div class="mu-instr__wstep">' . wp_kses_post( wpautop( $d['wstep'] ) ) . '</div>';
	}
	echo '<ul class="mu-instr__kafle">';
	foreach ( $d['sekcje'] as $i => $s ) {
		printf(
			'<li><button type="button" class="mu-instr__kafel" data-sekcja="%1$d" aria-haspopup="dialog"><span class="dashicons %2$s" aria-hidden="true"></span><span class="mu-instr__nazwa">%3$s</span>%4$s</button></li>',
			(int) $i,
			esc_attr( $s['ikona'] ),
			esc_html( $s['tytul'] ),
			$s['opis'] ? '<span class="mu-instr__opis">' . esc_html( $s['opis'] ) . '</span>' : ''
		);
	}
	echo '</ul>';
	foreach ( $d['sekcje'] as $i => $s ) {
		printf( '<template id="mu-instr-%1$d" data-tytul="%2$s" data-ikona="%3$s">%4$s</template>', (int) $i, esc_attr( $s['tytul'] ), esc_attr( $s['ikona'] ), wp_kses_post( wpautop( $s['tresc'] ) ) );
	}
	if ( ! empty( $d['stopka'] ) ) {
		echo '<div class="mu-instr__stopka">' . wp_kses_post( wpautop( $d['stopka'] ) ) . '</div>';
	}
	?>
	<dialog class="mu-instr__okno" aria-labelledby="mu-instr-tytul">
		<div class="mu-instr__okno-glowa">
			<span class="dashicons" aria-hidden="true"></span>
			<h2 id="mu-instr-tytul"></h2>
			<button type="button" class="mu-instr__zamknij" aria-label="<?php esc_attr_e( 'Zamknij', 'moveup-instrukcja' ); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
		</div>
		<div class="mu-instr__tresc"></div>
	</dialog>
	<?php
}

add_action( 'admin_head-index.php', function () {
	if ( empty( mu_instr_dane()['sekcje'] ) ) {
		return;
	}
	?>
	<style id="moveup-instrukcja">
	#moveup_instrukcja .inside{margin:0;padding:12px 16px 16px}
	.mu-instr__wstep p{margin:0 0 12px;color:#50575e}
	.mu-instr__kafle{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:0;padding:0;list-style:none}
	.mu-instr__kafle li{margin:0}
	.mu-instr__kafel{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:6px;width:100%;height:100%;min-height:104px;padding:14px 10px 12px;border:1px solid #dcdcde;border-radius:10px;background:#fff;color:#1d2327;font:inherit;text-align:center;cursor:pointer;transition:border-color .15s,background .15s,box-shadow .15s}
	.mu-instr__kafel:hover{border-color:var(--wp-admin-theme-color,#2271b1);background:#f6f7f7}
	.mu-instr__kafel:focus-visible{outline:2px solid var(--wp-admin-theme-color,#2271b1);outline-offset:2px}
	.mu-instr__kafel .dashicons{width:32px;height:32px;font-size:32px;color:var(--wp-admin-theme-color,#2271b1)}
	.mu-instr__nazwa{font-weight:600;font-size:13px;line-height:1.3}
	.mu-instr__opis{font-size:12px;line-height:1.35;color:#646970}
	.mu-instr__stopka p{margin:14px 0 0;color:#646970;font-size:12px}
	.mu-instr__okno{width:min(720px,calc(100vw - 32px));max-height:min(80vh,760px);padding:0;border:0;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25)}
	.mu-instr__okno::backdrop{background:rgba(0,0,0,.45)}
	.mu-instr__okno-glowa{position:sticky;top:0;display:flex;align-items:center;gap:10px;padding:16px 20px;border-bottom:1px solid #dcdcde;background:#fff}
	.mu-instr__okno-glowa>.dashicons{width:28px;height:28px;font-size:28px;color:var(--wp-admin-theme-color,#2271b1)}
	.mu-instr__okno-glowa h2{flex:1;margin:0;font-size:18px;line-height:1.3}
	.mu-instr__zamknij{display:flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border:0;border-radius:50%;background:#f0f0f1;cursor:pointer}
	.mu-instr__zamknij:hover{background:#dcdcde}
	.mu-instr__zamknij:focus-visible{outline:2px solid var(--wp-admin-theme-color,#2271b1);outline-offset:2px}
	.mu-instr__tresc{padding:16px 24px 24px;font-size:14px;line-height:1.6}
	.mu-instr__tresc p{font-size:14px;margin:0 0 12px}
	.mu-instr__tresc ul,.mu-instr__tresc ol{margin:0 0 12px 20px}
	.mu-instr__tresc ul{list-style:disc}
	.mu-instr__tresc li{margin-bottom:6px}
	.mu-instr__tresc h3{font-size:15px;margin:18px 0 8px}
	</style>
	<?php
} );

add_action( 'admin_footer-index.php', function () {
	if ( empty( mu_instr_dane()['sekcje'] ) ) {
		return;
	}
	?>
	<script id="moveup-instrukcja-js">
	( function () {
		var w = document.getElementById( 'moveup_instrukcja' );
		if ( ! w ) { return; }
		var d = w.querySelector( '.mu-instr__okno' ), ostatni = null;
		if ( ! d || typeof d.showModal !== 'function' ) { return; }
		w.querySelectorAll( '.mu-instr__kafel' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var t = document.getElementById( 'mu-instr-' + b.getAttribute( 'data-sekcja' ) );
				if ( ! t ) { return; }
				ostatni = b;
				d.querySelector( 'h2' ).textContent = t.getAttribute( 'data-tytul' );
				d.querySelector( '.mu-instr__okno-glowa > .dashicons' ).className = 'dashicons ' + t.getAttribute( 'data-ikona' );
				var tr = d.querySelector( '.mu-instr__tresc' );
				tr.innerHTML = '';
				tr.appendChild( t.content.cloneNode( true ) );
				d.showModal();
				d.scrollTop = 0;
				d.querySelector( '.mu-instr__zamknij' ).focus();
			} );
		} );
		d.querySelector( '.mu-instr__zamknij' ).addEventListener( 'click', function () { d.close(); } );
		d.addEventListener( 'click', function ( e ) { if ( e.target === d ) { d.close(); } } ); // kliknięcie w tło
		d.addEventListener( 'close', function () { if ( ostatni ) { ostatni.focus(); } } );
	} )();
	</script>
	<?php
} );

/* -------------------------------------------------------------------------
 * Ustawienia → Instrukcja: import / eksport treści (JSON)
 * ---------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'Instrukcja strony', 'Instrukcja', 'manage_options', 'moveup-instrukcja', 'mu_instr_ustawienia' );
} );

function mu_instr_ustawienia() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$komunikat = '';
	if ( isset( $_POST['mu_instr_json'] ) && check_admin_referer( 'mu_instr_zapisz' ) ) {
		$d = json_decode( wp_unslash( $_POST['mu_instr_json'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- oczyszczane w mu_instr_oczysc()
		if ( is_array( $d ) ) {
			update_option( MU_INSTR_OPCJA, mu_instr_oczysc( $d ), false );
			$komunikat = '<div class="notice notice-success"><p>Instrukcja zapisana – zobacz ją w Kokpicie.</p></div>';
		} else {
			$komunikat = '<div class="notice notice-error"><p>To nie jest poprawny plik JSON instrukcji – nic nie zmieniono.</p></div>';
		}
	}
	$d = mu_instr_dane();
	?>
	<div class="wrap">
		<h1>Instrukcja strony</h1>
		<?php echo $komunikat; // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<p>Treść widżetu „Instrukcja strony” w Kokpicie (<?php echo count( $d['sekcje'] ?? array() ); ?> sekcji). Wklej treść w formacie JSON przygotowaną przez moveUP i zapisz. Pole poniżej zawiera obecną treść – możesz ją skopiować jako kopię zapasową.</p>
		<form method="post">
			<?php wp_nonce_field( 'mu_instr_zapisz' ); ?>
			<textarea name="mu_instr_json" rows="24" class="large-text code" spellcheck="false"><?php echo esc_textarea( $d ? wp_json_encode( $d, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : '' ); ?></textarea>
			<?php submit_button( 'Zapisz instrukcję' ); ?>
		</form>
	</div>
	<?php
}
