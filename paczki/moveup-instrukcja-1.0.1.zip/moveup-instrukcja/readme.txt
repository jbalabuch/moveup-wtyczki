=== moveUP – Instrukcja ===
Contributors: moveUP Agency
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later

Instrukcja obsługi strony w Kokpicie WordPressa: widżet „Instrukcja strony” na górze kokpitu, sekcje jako kafelki z ikonami, po kliknięciu okno z opisem, co i gdzie edytować.

== Treść ==

Treść jest osobna dla każdej strony: Ustawienia → Instrukcja → wklej JSON → Zapisz. Format:

{ "tytul": "Instrukcja strony", "wstep": "<p>…</p>", "stopka": "<p>…</p>",
  "sekcje": [ { "ikona": "dashicons-groups", "tytul": "Kadra", "opis": "krótki podpis pod kafelkiem", "tresc": "<p>…</p><ul><li>…</li></ul>" } ] }

Ikony: nazwy Dashicons WordPressa. HTML w treści oczyszczany jak we wpisach (wp_kses_post). Widżet widzą osoby, które mogą edytować strony.

== Aktualizacje ==

Wtyczka sama sprawdza nowe wersje w https://github.com/jbalabuch/moveup-wtyczki (plik wtyczki.json) – aktualizacja pojawia się w Kokpit → Aktualizacje.
