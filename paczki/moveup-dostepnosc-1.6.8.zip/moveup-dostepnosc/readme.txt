=== moveUP – Dostępność ===
Contributors: moveUP Agency
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.6.8
License: GPLv2 or later

Lekki panel ułatwień dostępu i wyłączanie animacji na stronie. Własny kod – funkcje wzorowane na DJ-Accessibility 1.14 (bez użycia jej kodu).

== Instalacja ==

Wtyczki → Dodaj nową → Wyślij wtyczkę → moveup-dostepnosc.zip → Włącz.
Po włączeniu WordPress otwiera Ustawienia → Dostępność z ramką „Pierwsze ustawienie”. Wtyczka sama wykrywa:
– kolor przycisku: palette1 z Kadence (zapisana paleta albo domyślna), w innych motywach kolor „primary”/„accent”/„contrast” z theme.json; ikona biała albo czarna – tak, żeby kontrast wynosił min. 3:1,
– link do deklaracji: strona /deklaracja-dostepnosci/ albo strona z „deklaracja dostępności” w tytule.
Przycisk działa od razu z tymi wartościami. Wystarczy je sprawdzić i kliknąć „Zapisz zmiany” – do tego czasu w kokpicie widać przypomnienie.

== Odsłuch strony (od 1.6.0) ==

Od 1.6.3: pasek ułatwień pod paskiem administracyjnym WordPressa (z-index 99998 dla zalogowanych – rozwijane menu „Kokpit” było pod paskiem). Od 1.6.4: „Zatrzymaj animacje” wciska pauzę w karuzelach Splide (Kadence: galerie, opinie, kadra – gdy blok ma włączony przycisk pauzy), wyłączenie opcji wznawia tylko zatrzymane przez nas. Od 1.6.6: opcja „Na telefonie karuzele nie przewijają się same” (Wygląd/animacje) – do 767 px karuzele Splide zatrzymane i bez przycisku pauzy (WCAG 2.2.2 – nic się nie przesuwa samo, więc pauza zbędna); palec, strzałki i kropki działają. Od 1.6.8: opcja „Karuzele zatrzymują się po najechaniu myszką” – Kadence wypisuje w karuzelach pauzę po najechaniu wyłączoną na sztywno; wtyczka włącza ją przed wysłaniem strony (Splide pauseOnHover, przy fokusie klawiatury też). Od 1.6.5: karuzele Splide bez niedozwolonych ról na liście slajdów (<ul role="presentation">, <li role="tabpanel"/"group">) – zwykła lista slajdów; axe aria-allowed-role i Lighthouse „Przeglądanie agentowe” (drzewo dostępności) bez błędów.

Pasek u góry – podpowiedzi (od 1.6.2): nazwa opcji pojawia się od razu po najechaniu na przycisk i przy przejściu klawiszem Tab (ciemny dymek pod przyciskiem, jak w DJ-Accessibility); zamiast atrybutu title, który przeglądarka pokazywała po ok. 1 s i tylko myszką.

Ustawienia → Dostępność → „Odsłuch strony”: przycisk „Słuchaj tekstu tej strony” na początku treści (strony i/lub wpisy, napis do zmiany). Czyta głosem przeglądarki (Web Speech API – bez zewnętrznych usług, plików audio i zgody na cookies; po polsku głos „Zosia”, jeśli jest w systemie) nagłówki, akapity i listy treści po kolei, podświetla czytany fragment i przewija do niego. Pauza / wznowienie od przerwanego fragmentu / zatrzymanie (osobny przycisk), stan ogłaszany czytnikom. Przycisk jest w HTML od razu (bez przeskoku układu), skrypt (assets/odsluch.js, ok. 4 KB) dopiero po najechaniu, fokusie albo kliknięciu. Od 1.6.1 w trakcie słuchania i pauzy przycisk zostaje na ekranie: gdy jego miejsce wyjedzie w górę, przyczepia się pod paskiem ułatwień (albo pod górną krawędzią ekranu); po „Zatrzymaj” i po przeczytaniu całości wraca na miejsce (fokus na przycisku bez przewijania strony). Przeglądarka bez syntezy mowy – przycisk się chowa. Od 1.6.7: pole „Tło pasa z przyciskiem” – kolor na całą szerokość ekranu (np. jak nagłówek i pierwsza sekcja strony, żeby między nimi nie było jaśniejszego pasa); puste – tło strony. Zastępuje „Text To Speech TTS Accessibility” (AtlasVoice, 60 KB JS) – shortcode [atlasvoice] trzeba usunąć z treści (Budy Zosine: skrypt usun-atlasvoice.php).

== Pasek u góry (od 1.5.0) ==

Ustawienia → Dostępność → Wygląd: „Pasek u góry strony”. Od wybranej szerokości ekranu (domyślnie 1024 px) zamiast okrągłego przycisku – pasek 48 px przyklejony do góry (strona przesuwa się o jego wysokość), na szerokość treści strony (Kadence: --global-content-width + marginesy), grupy rozłożone na całą szerokość: Kontrast (odwrócone kolory, odcienie szarości, ciemny, jasny, niskie i wysokie nasycenie), Tekst (podkreśl linki, wyróżnij nagłówki, czytelna czcionka), Rozmiar (tekst − / + z wartością, odstępy w tekście), Czytanie (linijka, zatrzymaj animacje, duży kursor, czytaj na głos), Przywróć ustawienia i „Więcej” (dla czytników: „Więcej ułatwień dostępu”) – pełny panel (profile, fokus, maska, obrazy i reszta) otwierany pod paskiem. Poniżej 1280 px podpisy grup są ukryte wizualnie (zostają dla czytników). Na telefonie i tablecie – okrągły przycisk jak dotąd.
Pierwszy element paska to „Przejdź do treści” (filtr moveup_dostepnosc_skok, domyślnie #main). Styl paska ok. 2 KB w <head>, kod dopiero po pierwszym najechaniu, fokusie albo kliknięciu (kliknięcie przed wczytaniem jest wykonywane po wczytaniu). Stan przycisków paska i panelu jest wspólny. Pierwsze wdrożenie: budyzosine.monar.org (zamiast DJ-Accessibility, które ładowało 18 KB CSS i font Roboto z Google).

== Funkcje ==

Panel dla odwiedzających (Ustawienia → Dostępność: które funkcje pokazać):
– Rozmiar tekstu 100–200% co 20% (przyciski − / +) (działa także przy rozmiarach w px, np. Kadence; skaluje interlinię; obejmuje treści doczytane później)
– Odstępy w tekście – dokładnie wartości z WCAG 1.4.12
– Czytelna czcionka
– Kontrast: ciemny, jasny, odwrócone kolory, odcienie szarości, niskie i wysokie nasycenie (wykluczają się nawzajem); od 1.4.1 działają też na zdjęcia, filmy i osadzone mapy (w kontraście ciemnym i jasnym – odcienie szarości z mocniejszym kontrastem)
– Podkreśl linki, Wyróżnij nagłówki, Wyraźny fokus (dwukolorowy), Duży kursor
– Linijka do czytania i maska czytania (podążają za kursorem, palcem i fokusem klawiatury; wykluczają się nawzajem)
– Zatrzymaj animacje (CSS, przejścia, animacje przy przewijaniu Kadence/AOS, wideo)
– Ukryj obrazy (zdjęcia, wideo, zdjęcia w tle; miejsce po nich zostaje, układ nie skacze)
– Czytaj na głos (synteza mowy przeglądarki; klik albo Alt + R na elemencie z fokusem)
– Profile – jedno kliknięcie włącza zestaw opcji: Słabowidzący (tekst 140%, linki, kursor, fokus), Dysleksja (czytelna czcionka, odstępy, linijka), ADHD i skupienie (maska, bez animacji, bez obrazów), Epilepsja (bez animacji, niskie nasycenie), Ruch i klawiatura (fokus, kursor, bez animacji), Trudności poznawcze (linki, nagłówki, czytanie na głos). Bez profilu „ślepota” – osoby niewidome mają własne czytniki ekranu, a taki profil im przeszkadza.
– Ukryj przycisk – odwiedzający chowa go do zamknięcia przeglądarki (sessionStorage); panel otwiera skrót Alt + Shift + A (działa zawsze, także przed wczytaniem panelu)
– Przywróć ustawienia, link do Deklaracji dostępności

Nowe funkcje z kolejnych wersji włączają się same także na stronach z zapisanymi ustawieniami (lista „znane” w opcji).

Ustawienia strony:
– Wyłącz animacje wszystkim odwiedzającym
– Wyłączaj animacje osobom z systemowym „ogranicz ruch” (prefers-reduced-motion) – domyślnie włączone
– Położenie i kolory przycisku z podglądem kontrastu (WCAG 1.4.11)

Wyboru odwiedzającego pilnuje localStorage w jego przeglądarce (bez ciasteczek, bez zgody CookieYes).
Inne skrypty mogą reagować na zdarzenie `mu-a11y:ruch` (detail.bezAnimacji) albo klasy na <html>: `mu-bez-animacji` (panel), `mu-bez-animacji-strona` (ustawienie strony). Przykład: monar-kadra 1.0.7.

== Szybkość ==

Na starcie strony: przycisk, panel w <template> i ok. 1,5 KB kodu w treści HTML (razem ok. 2 KB po kompresji), zero dodatkowych plików, nic nie blokuje renderowania.
CSS (9 KB) i JS (10 KB) wczytują się dopiero po najechaniu lub fokusie na przycisku, albo od razu, jeśli odwiedzający ma zapisane ustawienia.
Dla porównania DJ-Accessibility 1.14: 101 KB CSS blokującego renderowanie + 37 KB JS na każdej stronie.

== Dostępność samego panelu (WCAG 2.2 AA) ==

– Przycisk: nazwa dostępna, aria-expanded, 48×48 px (2.5.8), fokus widoczny (2.4.7), kontrast ikony sprawdzany w ustawieniach (1.4.11)
– Panel: role="dialog" z nazwą, fokus przechodzi do tytułu, Esc i Zamknij oddają fokus przyciskowi, brak pułapki fokusu (2.1.2)
– Przełączniki: aria-pressed + znacznik wyboru, nie tylko kolor (4.1.2, 1.4.1); wynik zmiany rozmiaru ogłaszany przez role="status" (4.1.3)
– Cele dotykowe min. 44×44 px, tekst 15–18 px, kontrast min. 4,5:1 (kolor akcentu za jasny → panel przechodzi na czarny)
– Mieści się w 320 px szerokości (1.4.10), działa w trybie wysokiego kontrastu Windows (forced-colors), nie animuje się
– Audyt axe-core 4.10 (WCAG 2.0–2.2 A/AA + dobre praktyki): 0 błędów

Panel NIE czyni strony zgodnej z WCAG – zgodność zapewnia treść i motyw (teksty alternatywne, kontrast, nagłówki, klawiatura, formularze). Nie reklamować go jako „100% zgodności”.

== Aktualizacje ==

Od wersji 1.4.0 wtyczka sama sprawdza nowe wersje w https://github.com/jbalabuch/moveup-wtyczki (plik wtyczki.json) – aktualizacja pojawia się w Kokpit → Aktualizacje, można włączyć automatyczne aktualizacje. Nagłówek „Update URI” sprawia, że WordPress nie myli wtyczki z wtyczką o tej samej nazwie na wordpress.org.
