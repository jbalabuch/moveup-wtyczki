<?php
/**
 * moveUP – Agenci AI: dodatek dla WP Super Cache (od 1.1.2). WPSC ładuje ten plik przed WordPressem ($wpsc_plugins
 * w wp-cache-config.php, rejestracja: wpsc_add_plugin przy włączeniu wtyczki). Zapytania o Markdown (Accept: text/markdown)
 * szukają osobnego pliku cache („…-markdown”), którego nie ma – WPSC nie poda im gotowej strony HTML, a sama odpowiedź
 * Markdown ma DONOTCACHEPAGE, więc nie zapisuje się w cache.
 */
if ( ! function_exists( 'mu_ai_wpsc_nazwa' ) ) {
	function mu_ai_wpsc_nazwa( $s ) {
		$a = isset( $_SERVER['HTTP_ACCEPT'] ) ? strtolower( (string) $_SERVER['HTTP_ACCEPT'] ) : '';
		$m = strpos( $a, 'text/markdown' );
		$h = strpos( $a, 'text/html' );
		return ( false !== $m && ( false === $h || $m < $h ) ) ? $s . '-markdown' : $s;
	}
	if ( function_exists( 'add_cacheaction' ) ) {
		add_cacheaction( 'supercache_filename_str', 'mu_ai_wpsc_nazwa' );
	}
	if ( function_exists( 'add_filter' ) ) {
		add_filter( 'supercache_filename_str', 'mu_ai_wpsc_nazwa' );
	}
}
