<?php
/**
 * moveUP – aktualizacje wtyczek z GitHuba (https://github.com/jbalabuch/moveup-wtyczki).
 *
 * Wspólny plik we wszystkich wtyczkach moveUP (kopia w includes/ każdej wtyczki, źródło: WORDPRESS/_wspolne/).
 * Wtyczka ma w nagłówku „Update URI: https://github.com/jbalabuch/moveup-wtyczki” – WordPress nie pyta wtedy
 * wordpress.org o wtyczkę o tej samej nazwie, tylko filtr update_plugins_github.com, który czyta wtyczki.json.
 * Lista wersji jest w pamięci 12 h (przycisk „Sprawdź ponownie” w Kokpit → Aktualizacje odświeża ją od razu).
 *
 * Użycie w pliku głównym wtyczki:
 *   require_once __DIR__ . '/includes/moveup-aktualizacje.php';
 *   MoveUP_Aktualizacje::rejestruj( __FILE__, 'nazwa-folderu' );
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'MoveUP_Aktualizacje' ) ) {

	final class MoveUP_Aktualizacje {

		const WERSJA   = '1.0.0';
		const LISTA    = 'https://raw.githubusercontent.com/jbalabuch/moveup-wtyczki/main/wtyczki.json';
		const PAMIEC   = 'moveup_aktualizacje';

		/** @var array plik wtyczki (np. jadlospisy/jadlospisy.php) => slug */
		private static $wtyczki = array();

		public static function rejestruj( $plik, $slug ) {
			if ( ! self::$wtyczki ) {
				add_filter( 'update_plugins_github.com', array( __CLASS__, 'aktualizacja' ), 10, 3 );
				add_filter( 'plugins_api', array( __CLASS__, 'szczegoly' ), 20, 3 );
				add_action( 'upgrader_process_complete', array( __CLASS__, 'wyczysc' ), 10, 0 );
				add_action( 'load-update-core.php', array( __CLASS__, 'wymus' ) );
			}
			self::$wtyczki[ plugin_basename( $plik ) ] = sanitize_key( $slug );
		}

		/** Lista wersji z GitHuba; przy błędzie pusta lista i ponowna próba za godzinę. */
		private static function lista() {
			$lista = get_site_transient( self::PAMIEC );
			if ( is_array( $lista ) ) {
				return $lista;
			}
			$r     = wp_remote_get( self::LISTA, array( 'timeout' => 8 ) );
			$lista = ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) )
				? json_decode( wp_remote_retrieve_body( $r ), true ) : null;
			$ok    = is_array( $lista );
			set_site_transient( self::PAMIEC, $ok ? $lista : array(), $ok ? 12 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
			return $ok ? $lista : array();
		}

		private static function wpis( $slug ) {
			$lista = self::lista();
			$w     = $lista[ $slug ] ?? null;
			return ( is_array( $w ) && ! empty( $w['version'] ) && ! empty( $w['package'] )
				&& 0 === strpos( $w['package'], 'https://' ) ) ? $w : null;
		}

		/** Filtr update_plugins_github.com – odpowiedź w formacie, którego oczekuje WordPress. */
		public static function aktualizacja( $update, $dane, $plik ) {
			if ( ! isset( self::$wtyczki[ $plik ] ) ) {
				return $update; // inna wtyczka z Update URI na github.com
			}
			$slug = self::$wtyczki[ $plik ];
			$w    = self::wpis( $slug );
			if ( ! $w ) {
				return $update;
			}
			return array(
				'id'           => 'github.com/jbalabuch/moveup-wtyczki/' . $slug,
				'slug'         => $slug,
				'version'      => $w['version'],
				'url'          => 'https://github.com/jbalabuch/moveup-wtyczki',
				'package'      => $w['package'],
				'tested'       => $w['tested'] ?? '',
				'requires_php' => $w['requires_php'] ?? '',
				'icons'        => array(),
				'banners'      => array(),
				'translations' => array(),
			);
		}

		/** Okno „Zobacz szczegóły wersji” w Kokpit → Wtyczki / Aktualizacje. */
		public static function szczegoly( $wynik, $akcja, $args ) {
			if ( 'plugin_information' !== $akcja || empty( $args->slug ) || ! in_array( $args->slug, self::$wtyczki, true ) ) {
				return $wynik;
			}
			$w = self::wpis( $args->slug );
			if ( ! $w ) {
				return $wynik;
			}
			return (object) array(
				'name'          => $w['name'] ?? $args->slug,
				'slug'          => $args->slug,
				'version'       => $w['version'],
				'author'        => 'moveUP Agency',
				'homepage'      => 'https://github.com/jbalabuch/moveup-wtyczki',
				'requires'      => $w['requires'] ?? '',
				'requires_php'  => $w['requires_php'] ?? '',
				'tested'        => $w['tested'] ?? '',
				'last_updated'  => $w['date'] ?? '',
				'download_link' => $w['package'],
				'sections'      => array(
					'description' => wpautop( esc_html( $w['description'] ?? '' ) ),
					'changelog'   => wpautop( esc_html( $w['changelog'] ?? '' ) ),
				),
			);
		}

		public static function wyczysc() {
			delete_site_transient( self::PAMIEC );
		}

		/** „Sprawdź ponownie” w Kokpit → Aktualizacje (force-check=1) – świeża lista z GitHuba. */
		public static function wymus() {
			if ( ! empty( $_GET['force-check'] ) && current_user_can( 'update_plugins' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				self::wyczysc();
			}
		}
	}
}
