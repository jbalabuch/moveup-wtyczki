<?php
/**
 * Plugin Name: moveUP – Wydajność
 * Description: Poprawki szybkości strony, których nie da się ustawić w panelu: własne, odchudzone fonty z assets/fonty/fonty.json (@font-face w <head> zamiast osobnego CSS motywu Kadence), bez preloadu fontów Kadence, defer dla skryptów Kadence na końcu strony (animacje AOS, akordeon), małe pliki CSS z serwera strony wpisane w kod strony (bez kilkunastu zapytań blokujących wyświetlanie).
 * Version: 1.3.0
 * Author: moveUP Agency
 * Text Domain: moveup-wydajnosc
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-wydajnosc' );

define( 'MU_WYD_VER', '1.3.0' );

/**
 * Fonty strony z assets/fonty/fonty.json: [{ family, style, weight, file }].
 * Pliki to fonty zmienne przycięte do znaków potrzebnych po polsku (jeden plik na krój) – patrz readme.txt.
 * Pusta lista = fonty zostają takie, jak ustawił motyw.
 */
function mu_wyd_fonty() {
	static $fonty = null;
	if ( null === $fonty ) {
		$plik  = __DIR__ . '/assets/fonty/fonty.json';
		$fonty = file_exists( $plik ) ? json_decode( (string) file_get_contents( $plik ), true ) : array();
		$fonty = apply_filters( 'moveup_wydajnosc_fonty', is_array( $fonty ) ? $fonty : array() );
	}
	return $fonty;
}

add_action( 'init', function () {
	if ( ! mu_wyd_fonty() ) {
		return;
	}
	// Kadence: bez preloadu i bez własnego pliku CSS z fontami – zastępuje je @font-face poniżej.
	add_filter( 'kadence_local_fonts_preload', '__return_false' );
	add_filter( 'style_loader_tag', function ( $tag, $handle ) {
		return 'kadence-fonts-gfonts' === $handle ? '' : $tag;
	}, 10, 2 );
	add_action( 'wp_head', 'mu_wyd_font_face', 2 );
} );

function mu_wyd_font_face() {
	$url = plugins_url( 'assets/fonty/', __FILE__ );
	$css = '';
	foreach ( mu_wyd_fonty() as $f ) {
		if ( empty( $f['family'] ) || empty( $f['file'] ) ) {
			continue;
		}
		if ( ! empty( $f['preload'] ) ) { // tylko font tekstu z pierwszego ekranu – każdy preload zabiera łącze CSS-owi
			printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $url . $f['file'] . '?ver=' . MU_WYD_VER ) );
		}
		$css .= sprintf(
			"@font-face{font-family:'%s';font-style:%s;font-weight:%s;font-display:swap;src:url(%s) format('woff2')}",
			esc_attr( $f['family'] ),
			esc_attr( $f['style'] ?? 'normal' ),
			esc_attr( $f['weight'] ?? '400' ),
			esc_url( $url . $f['file'] . '?ver=' . MU_WYD_VER )
		);
	}
	if ( $css ) {
		echo '<style id="moveup-fonty">' . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- wartości oczyszczone wyżej
	}
}

// Skrypty na końcu strony, które same czekają na DOMContentLoaded – defer zamiast blokowania parsera.
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	$defer = apply_filters( 'moveup_wydajnosc_defer', array( 'kadence-aos', 'kadence-blocks-accordion' ) );
	if ( in_array( $handle, $defer, true ) && false === strpos( $tag, ' defer' ) && false === strpos( $tag, ' async' ) ) {
		$tag = str_replace( ' src=', ' defer src=', $tag );
	}
	return $tag;
}, 10, 2 );

/**
 * Małe arkusze CSS z serwera strony (motyw, bloki Kadence, własne wtyczki) wpisane w <style> w miejscu <link>.
 * Kadence ładuje kilkanaście plików po 1–6 KB – każdy to osobne zapytanie blokujące wyświetlanie strony.
 * Kolejność stylów się nie zmienia (ten sam punkt w kodzie), więc wygląd zostaje – w odróżnieniu od łączenia
 * i minifikacji CSS w LiteSpeed, które przy Kadence psuło układ. Ścieżki url(…) są zamieniane na adresy bezwzględne.
 * Limit rozmiaru pliku: filtr moveup_wydajnosc_inline_css_limit (bajty, 0 = wyłączone), wyjątki: moveup_wydajnosc_inline_css_bez.
 */
add_filter( 'style_loader_tag', 'mu_wyd_inline_css', 20, 4 );

function mu_wyd_inline_css( $tag, $handle, $href, $media ) {
	if ( is_admin() || is_customize_preview() || '' === $tag || ! $href ) {
		return $tag;
	}
	$limit = (int) apply_filters( 'moveup_wydajnosc_inline_css_limit', 15000 );
	$bez   = (array) apply_filters( 'moveup_wydajnosc_inline_css_bez', array() );
	if ( $limit <= 0 || in_array( $handle, $bez, true ) || ! in_array( $media, array( 'all', 'screen', '' ), true ) ) {
		return $tag;
	}
	$plik = mu_wyd_sciezka( $href );
	if ( ! $plik || ! is_readable( $plik ) || filesize( $plik ) > $limit ) {
		return $tag;
	}
	$css = (string) file_get_contents( $plik );
	if ( '' === trim( $css ) || false !== stripos( $css, '</style' ) ) {
		return $tag;
	}
	// url(względny) → adres bezwzględny względem katalogu pliku CSS
	$baza = trailingslashit( dirname( strtok( $href, '?' ) ) );
	$css  = preg_replace_callback( '/url\(\s*([\'"]?)(?!data:|https?:|\/\/|\/|#)([^\'")]+)\1\s*\)/i', function ( $m ) use ( $baza ) {
		return 'url(' . $m[1] . $baza . $m[2] . $m[1] . ')';
	}, $css );
	if ( null !== $css ) {
		$css = preg_replace( '~/\*# sourceMappingURL=[^*]*\*/~', '', $css );
	}
	if ( null === $css || '' === trim( $css ) ) { // błąd wyrażenia – zostaje zwykły <link>
		return $tag;
	}
	return sprintf( '<style id="%s-css"%s>%s</style>' . "\n", esc_attr( $handle ), 'all' === $media || '' === $media ? '' : ' media="' . esc_attr( $media ) . '"', $css );
}

/** Adres pliku z serwera strony → ścieżka na dysku (tylko wp-content i wp-includes, bez plików zewnętrznych). */
function mu_wyd_sciezka( $href ) {
	$url = strtok( set_url_scheme( $href, 'https' ), '?' );
	$map = array(
		set_url_scheme( content_url( '/' ), 'https' )  => trailingslashit( WP_CONTENT_DIR ),
		set_url_scheme( includes_url( '/' ), 'https' ) => trailingslashit( ABSPATH . WPINC ),
	);
	foreach ( $map as $u => $d ) {
		if ( 0 === strpos( $url, $u ) ) {
			$sc = realpath( $d . substr( $url, strlen( $u ) ) );
			return ( $sc && 0 === strpos( $sc, realpath( $d ) ) && '.css' === substr( $sc, -4 ) ) ? $sc : '';
		}
	}
	return '';
}
