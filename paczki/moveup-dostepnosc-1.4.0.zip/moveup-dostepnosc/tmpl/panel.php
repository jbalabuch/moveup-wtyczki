<?php
/**
 * Przycisk i panel. Panel leży w <template> – przeglądarka go nie renderuje, dopóki ktoś nie otworzy ułatwień.
 *
 * @var array  $o   ustawienia
 * @var array  $f   włączone funkcje (klucze)
 * @var string $bok left | right
 *
 * Kolor akcentu w panelu: kolor przycisku, jeśli ma z białym kontrast min. 4,5:1 (tekst), inaczej prawie czarny.
 */
defined( 'ABSPATH' ) || exit;

// Ikony liniowe 24×24 (stroke = currentColor), dekoracyjne – nazwę opcji niesie napis.
$ikony = array(
	'rozmiar'   => '<path d="M3 7V5h11v2M8.5 5v14M6.5 19h4M14 13v-1.5h7V13M17.5 11.5V19M16 19h3"/>',
	'odstepy'   => '<path d="M21 6H9M21 12H9M21 18H9M4 4v16M2 6l2-2 2 2M2 18l2 2 2-2"/>',
	'czcionka'  => '<path d="M3 19 8.5 5h1L15 19M5.2 14h7.6M17.5 19v-6.5a2.5 2.5 0 0 1 5 0V19M17.5 15.5h5"/>',
	'ciemny'    => '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18z" fill="currentColor"/>',
	'jasny'     => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
	'odwroc'    => '<path d="M17 3l4 4-4 4M21 7H8a4 4 0 0 0-4 4M7 21l-4-4 4-4M3 17h13a4 4 0 0 0 4-4"/>',
	'szarosc'   => '<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z"/><path d="M12 3v19" />',
	'nasyc-n'   => '<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z" stroke-dasharray="3 3"/>',
	'nasyc-w'   => '<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z" fill="currentColor"/>',
	'linki'     => '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
	'naglowki'  => '<path d="M5 4v16M15 4v16M5 12h10M19 20v-8l-2 1.5"/>',
	'fokus'     => '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><rect x="9" y="9" width="6" height="6" rx="1"/>',
	'kursor'    => '<path d="M5 3l14 7-6 2-2 6z"/><path d="M13 12l6 6"/>',
	'animacje'  => '<circle cx="12" cy="12" r="9"/><path d="M10 9v6M14 9v6"/>',
	'czytaj'    => '<path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>',
	'linijka'   => '<rect x="2" y="8" width="20" height="8" rx="1.5"/><path d="M6 8v3M10 8v4M14 8v3M18 8v4"/>',
	'maska'     => '<rect x="3" y="3" width="18" height="18" rx="2" fill="currentColor" fill-opacity=".18" stroke="none"/><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 10h18M3 14h18"/><rect x="3" y="10" width="18" height="4" fill="#fff" stroke="none"/>',
	'obrazy'    => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.5"/><path d="m21 15-5-5-6 6M3 3l18 18"/>',
	'p-wzrok'   => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
	'p-dysleksja' => '<path d="M2 5h6a4 4 0 0 1 4 4v11a3 3 0 0 0-3-3H2zM22 5h-6a4 4 0 0 0-4 4v11a3 3 0 0 1 3-3h7z"/>',
	'p-adhd'    => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
	'p-epilepsja' => '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/><path d="M3 3l18 18"/>',
	'p-ruch'    => '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
	'p-poznawcze' => '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
	'reset'     => '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
);
$svg = function ( $nazwa, $klasa = 'mu-a11y__ico' ) use ( $ikony ) {
	return '<svg class="' . $klasa . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $ikony[ $nazwa ] . '</svg>';
};
$opcja = function ( $ikona, $klasa, $etykieta, $grupa = '' ) use ( $svg ) {
	printf(
		'<button type="button" class="mu-a11y__opt" data-k="%s"%s aria-pressed="false">%s<span class="mu-a11y__lbl">%s</span></button>',
		esc_attr( $klasa ),
		$grupa ? ' data-g="' . esc_attr( $grupa ) . '"' : '',
		$svg( $ikona ), // phpcs:ignore WordPress.Security.EscapeOutput -- stałe SVG
		esc_html( $etykieta )
	);
};
$profil = function ( $ikona, $id, $etykieta ) use ( $svg ) {
	printf(
		'<button type="button" class="mu-a11y__opt" data-profil="%s" aria-pressed="false">%s<span class="mu-a11y__lbl">%s</span></button>',
		esc_attr( $id ),
		$svg( $ikona ), // phpcs:ignore WordPress.Security.EscapeOutput -- stałe SVG
		esc_html( $etykieta )
	);
};
$tekst = isset( $f['odstepy'] ) || isset( $f['czcionka'] ) || isset( $f['rozmiar'] );
$nawig = isset( $f['linki'] ) || isset( $f['naglowki'] ) || isset( $f['fokus'] ) || isset( $f['kursor'] ) || isset( $f['linijka'] ) || isset( $f['maska'] );
$inne  = isset( $f['animacje'] ) || isset( $f['obrazy'] ) || isset( $f['czytaj'] );
?>
<button type="button" class="mu-a11y-btn" aria-keyshortcuts="Alt+Shift+A" aria-expanded="false" aria-controls="mu-a11y-panel" aria-label="<?php esc_attr_e( 'Ułatwienia dostępu', 'moveup-dostepnosc' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="4" r="2.2"/><path d="M4 7.6c2.7.8 5.3 1.2 8 1.2s5.3-.4 8-1.2l.5 1.9c-2 .6-4.1 1-6.2 1.2v3.2l2 7.6-1.9.5-2.4-6.9-2.4 6.9-1.9-.5 2-7.6v-3.2c-2.1-.2-4.2-.6-6.2-1.2z"/></svg></button>
<template id="mu-a11y-tpl">
<div id="mu-a11y-panel" class="mu-a11y mu-a11y--<?php echo esc_attr( $bok ); ?>" role="dialog" aria-labelledby="mu-a11y-tytul" lang="<?php echo esc_attr( substr( get_bloginfo( 'language' ), 0, 2 ) ); ?>" style="--mu-dol:<?php echo absint( $o['odstep_dol'] ) + 60; ?>px;--mu-bok:<?php echo absint( $o['odstep_bok'] ); ?>px;--mu-akcent:<?php echo esc_attr( mu_dost_kontrast( $o['kolor_tla'], '#ffffff' ) >= 4.5 ? $o['kolor_tla'] : '#1a1a1a' ); ?>">
	<div class="mu-a11y__head">
		<span class="mu-a11y__logo" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><circle cx="12" cy="4" r="2.2"/><path d="M4 7.6c2.7.8 5.3 1.2 8 1.2s5.3-.4 8-1.2l.5 1.9c-2 .6-4.1 1-6.2 1.2v3.2l2 7.6-1.9.5-2.4-6.9-2.4 6.9-1.9-.5 2-7.6v-3.2c-2.1-.2-4.2-.6-6.2-1.2z"/></svg></span>
		<h2 class="mu-a11y__title" id="mu-a11y-tytul" tabindex="-1"><?php esc_html_e( 'Ułatwienia dostępu', 'moveup-dostepnosc' ); ?></h2>
		<button type="button" class="mu-a11y__close" aria-label="<?php esc_attr_e( 'Zamknij ułatwienia dostępu', 'moveup-dostepnosc' ); ?>"><svg class="mu-a11y__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
	</div>
	<div class="mu-a11y__body">
		<?php if ( isset( $f['profile'] ) ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Profile', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			$profil( 'p-wzrok', 'slabowidzacy', __( 'Słabowidzący', 'moveup-dostepnosc' ) );
			$profil( 'p-dysleksja', 'dysleksja', __( 'Dysleksja', 'moveup-dostepnosc' ) );
			$profil( 'p-adhd', 'adhd', __( 'ADHD i skupienie', 'moveup-dostepnosc' ) );
			$profil( 'p-epilepsja', 'epilepsja', __( 'Epilepsja', 'moveup-dostepnosc' ) );
			$profil( 'p-ruch', 'ruch', __( 'Ruch i klawiatura', 'moveup-dostepnosc' ) );
			$profil( 'p-poznawcze', 'poznawcze', __( 'Trudności poznawcze', 'moveup-dostepnosc' ) );
			?>
		</div>
		<?php endif; ?>
		<?php if ( $tekst ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Tekst', 'moveup-dostepnosc' ); ?></h3>
		<?php if ( isset( $f['rozmiar'] ) ) : ?>
		<div class="mu-a11y__size" role="group" aria-labelledby="mu-a11y-rozm">
			<?php echo $svg( 'rozmiar' ); // phpcs:ignore ?>
			<span class="mu-a11y__lbl" id="mu-a11y-rozm"><?php esc_html_e( 'Rozmiar tekstu', 'moveup-dostepnosc' ); ?></span>
			<button type="button" class="mu-a11y__step" data-krok="-1" aria-label="<?php esc_attr_e( 'Zmniejsz tekst', 'moveup-dostepnosc' ); ?>"><svg class="mu-a11y__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14"/></svg></button>
			<span class="mu-a11y__val" data-wart>100%</span>
			<button type="button" class="mu-a11y__step" data-krok="1" aria-label="<?php esc_attr_e( 'Powiększ tekst', 'moveup-dostepnosc' ); ?>"><svg class="mu-a11y__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14M5 12h14"/></svg></button>
		</div>
		<?php endif; ?>
		<div class="mu-a11y__grid">

			<?php
			if ( isset( $f['odstepy'] ) ) {
				$opcja( 'odstepy', 'mu-odstepy', __( 'Odstępy w tekście', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['czcionka'] ) ) {
				$opcja( 'czcionka', 'mu-czcionka', __( 'Czytelna czcionka', 'moveup-dostepnosc' ) );
			}
			?>
		</div>
		<?php endif; ?>

		<?php if ( isset( $f['kontrast'] ) ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Kontrast i kolory', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			$opcja( 'ciemny', 'mu-kontrast-ciemny', __( 'Ciemny kontrast', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'jasny', 'mu-kontrast-jasny', __( 'Jasny kontrast', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'odwroc', 'mu-odwroc', __( 'Odwrócone kolory', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'szarosc', 'mu-szarosc', __( 'Odcienie szarości', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'nasyc-n', 'mu-nasycenie-niskie', __( 'Niskie nasycenie', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'nasyc-w', 'mu-nasycenie-wysokie', __( 'Wysokie nasycenie', 'moveup-dostepnosc' ), 'kolory' );
			?>
		</div>
		<?php endif; ?>

		<?php if ( $nawig ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Nawigacja', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			if ( isset( $f['linki'] ) ) {
				$opcja( 'linki', 'mu-linki', __( 'Podkreśl linki', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['naglowki'] ) ) {
				$opcja( 'naglowki', 'mu-naglowki', __( 'Wyróżnij nagłówki', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['fokus'] ) ) {
				$opcja( 'fokus', 'mu-fokus', __( 'Wyraźny fokus', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['kursor'] ) ) {
				$opcja( 'kursor', 'mu-kursor', __( 'Duży kursor', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['linijka'] ) ) {
				$opcja( 'linijka', 'mu-linijka', __( 'Linijka do czytania', 'moveup-dostepnosc' ), 'prowadnica' );
			}
			if ( isset( $f['maska'] ) ) {
				$opcja( 'maska', 'mu-maska', __( 'Maska czytania', 'moveup-dostepnosc' ), 'prowadnica' );
			}
			?>
		</div>
		<?php endif; ?>

		<?php if ( $inne ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Animacje, obrazy i czytanie', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			if ( isset( $f['animacje'] ) ) {
				$opcja( 'animacje', 'mu-bez-animacji', __( 'Zatrzymaj animacje', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['obrazy'] ) ) {
				$opcja( 'obrazy', 'mu-bez-obrazow', __( 'Ukryj obrazy', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['czytaj'] ) ) {
				$opcja( 'czytaj', 'mu-czytaj', __( 'Czytaj na głos', 'moveup-dostepnosc' ) );
			}
			?>
		</div>
		<?php if ( isset( $f['czytaj'] ) ) : ?>
		<p class="mu-a11y__hint" data-czytaj-info hidden><?php esc_html_e( 'Kliknij akapit, nagłówek lub link, a przeczytamy go na głos. Klawiaturą: przejdź do elementu i naciśnij Alt + R.', 'moveup-dostepnosc' ); ?></p>
		<?php endif; ?>
		<?php endif; ?>
	</div>
	<div class="mu-a11y__foot">
		<button type="button" class="mu-a11y__reset"><?php echo $svg( 'reset' ); // phpcs:ignore ?><?php esc_html_e( 'Przywróć ustawienia', 'moveup-dostepnosc' ); ?></button>
		<?php if ( isset( $f['ukryj'] ) ) : ?>
		<button type="button" class="mu-a11y__reset mu-a11y__ukryj" data-ukryj aria-keyshortcuts="Alt+Shift+A" data-ukryj-tekst="<?php esc_attr_e( 'Ukryj przycisk', 'moveup-dostepnosc' ); ?>" data-pokaz-tekst="<?php esc_attr_e( 'Pokaż przycisk', 'moveup-dostepnosc' ); ?>" data-komunikat="<?php esc_attr_e( 'Przycisk ukryty do zamknięcia przeglądarki. Panel otworzysz skrótem Alt + Shift + A.', 'moveup-dostepnosc' ); ?>"><?php esc_html_e( 'Ukryj przycisk', 'moveup-dostepnosc' ); ?></button>
		<?php endif; ?>
		<?php if ( $o['deklaracja'] ) : ?>
		<a class="mu-a11y__link" href="<?php echo esc_url( $o['deklaracja'] ); ?>"><?php esc_html_e( 'Deklaracja dostępności', 'moveup-dostepnosc' ); ?></a>
		<?php endif; ?>
	</div>
	<p class="mu-a11y__skrot"><?php esc_html_e( 'Skrót klawiszowy panelu: Alt + Shift + A', 'moveup-dostepnosc' ); ?></p>
	<div class="mu-a11y__sr" role="status" data-status></div>
</div>
</template>
<script id="mu-a11y-btn-js">(function(){var b=document.querySelector(".mu-a11y-btn"),c=window.muA11y,w=0;function l(){if(w)return;w=1;if(!document.querySelector('link[href="'+c.css+'"]')){var s=document.createElement("link");s.rel="stylesheet";s.href=c.css;document.head.appendChild(s)}if(!document.querySelector('script[src="'+c.js+'"]')){var j=document.createElement("script");j.src=c.js;document.head.appendChild(j)}}
b.addEventListener("pointerenter",l,{once:true});b.addEventListener("focus",l,{once:true});function t(){l();window.muA11yPanel?window.muA11yPanel.toggle():(window.muA11yOtworz=1)}b.addEventListener("click",t);
document.addEventListener("keydown",function(e){if(e.altKey&&e.shiftKey&&!e.ctrlKey&&!e.metaKey&&e.code==="KeyA"){e.preventDefault();t()}})})();</script>
<?php
