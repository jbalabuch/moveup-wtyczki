<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
delete_option( 'mu_dostepnosc' );
delete_transient( 'mu_dost_wykryte' );
delete_transient( 'mu_dost_powitanie' );
