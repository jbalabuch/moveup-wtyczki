=== moveUP – Dostępność ===
Contributors: moveUP Agency
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.4.0
License: GPLv2 or later

Lekki panel ułatwień dostępu i wyłączanie animacji na stronie. Własny kod – funkcje wzorowane na DJ-Accessibility 1.14 (bez użycia jej kodu).

== Instalacja ==

Wtyczki → Dodaj nową → Wyślij wtyczkę → moveup-dostepnosc.zip → Włącz.
Po włączeniu WordPress otwiera Ustawienia → Dostępność z ramką „Pierwsze ustawienie”. Wtyczka sama wykrywa:
– kolor przycisku: palette1 z Kadence (zapisana paleta albo domyślna), w innych motywach kolor „primary”/„accent”/„contrast” z theme.json; ikona biała albo czarna – tak, żeby kontrast wynosił min. 3:1,
– link do deklaracji: strona /deklaracja-dostepnosci/ albo strona z „deklaracja dostępności” w tytule.
Przycisk działa od razu z tymi wartościami. Wystarczy je sprawdzić i kliknąć „Zapisz zmiany” – do tego czasu w kokpicie widać przypomnienie.

== Funkcje ==

Panel dla odwiedzających (Ustawienia → Dostępność: które funkcje pokazać):
– Rozmiar tekstu 100–200% co 20% (przyciski − / +) (działa także przy rozmiarach w px, np. Kadence; skaluje interlinię; obejmuje treści doczytane później)
– Odstępy w tekście – dokładnie wartości z WCAG 1.4.12
– Czytelna czcionka
– Kontrast: ciemny, jasny, odwrócone kolory, odcienie szarości, niskie i wysokie nasycenie (wykluczają się nawzajem)
– Podkreśl linki, Wyróżnij nagłówki, Wyraźny fokus (dwukolorowy), Duży kursor
– Linijka do czytania i maska czytania (podążają za kursorem, palcem i fokusem klawiatury; wykluczają się nawzajem)
– Zatrzymaj animacje (CSS, przejścia, animacje przy przewijaniu Kadence/AOS, wideo)
– Ukryj obrazy (zdjęcia, wideo, zdjęcia w tle; miejsce po nich zostaje, układ nie skacze)
– Czytaj na głos (synteza mowy przeglądarki; klik albo Alt + R na elemencie z fokusem)
– Profile – jedno kliknięcie włącza zestaw opcji: Słabowidzący (tekst 140%, linki, kursor, fokus), Dysleksja (czytelna czcionka, odstępy, linijka), ADHD i skupienie (maska, bez animacji, bez obrazów), Epilepsja (bez animacji, niskie nasycenie), Ruch i klawiatura (fokus, kursor, bez animacji), Trudności poznawcze (linki, nagłówki, czytanie na głos). Bez profilu „ślepota” – osoby niewidome mają własne czytniki ekranu, a taki profil im przeszkadza.
– Ukryj przycisk – odwiedzający chowa go do zamknięcia przeglądarki (sessionStorage); panel otwiera skrót Alt + Shift + A (działa zawsze, także przed wczytaniem panelu)
– Przywróć ustawienia, link do Deklaracji dostępności

Nowe funkcje z kolejnych wersji włączają się same także na stronach z zapisanymi ustawieniami (lista „znane” w opcji).

Ustawienia strony:
– Wyłącz animacje wszystkim odwiedzającym
– Wyłączaj animacje osobom z systemowym „ogranicz ruch” (prefers-reduced-motion) – domyślnie włączone
– Położenie i kolory przycisku z podglądem kontrastu (WCAG 1.4.11)

Wyboru odwiedzającego pilnuje localStorage w jego przeglądarce (bez ciasteczek, bez zgody CookieYes).
Inne skrypty mogą reagować na zdarzenie `mu-a11y:ruch` (detail.bezAnimacji) albo klasy na <html>: `mu-bez-animacji` (panel), `mu-bez-animacji-strona` (ustawienie strony). Przykład: monar-kadra 1.0.7.

== Szybkość ==

Na starcie strony: przycisk, panel w <template> i ok. 1,5 KB kodu w treści HTML (razem ok. 2 KB po kompresji), zero dodatkowych plików, nic nie blokuje renderowania.
CSS (9 KB) i JS (10 KB) wczytują się dopiero po najechaniu lub fokusie na przycisku, albo od razu, jeśli odwiedzający ma zapisane ustawienia.
Dla porównania DJ-Accessibility 1.14: 101 KB CSS blokującego renderowanie + 37 KB JS na każdej stronie.

== Dostępność samego panelu (WCAG 2.2 AA) ==

– Przycisk: nazwa dostępna, aria-expanded, 48×48 px (2.5.8), fokus widoczny (2.4.7), kontrast ikony sprawdzany w ustawieniach (1.4.11)
– Panel: role="dialog" z nazwą, fokus przechodzi do tytułu, Esc i Zamknij oddają fokus przyciskowi, brak pułapki fokusu (2.1.2)
– Przełączniki: aria-pressed + znacznik wyboru, nie tylko kolor (4.1.2, 1.4.1); wynik zmiany rozmiaru ogłaszany przez role="status" (4.1.3)
– Cele dotykowe min. 44×44 px, tekst 15–18 px, kontrast min. 4,5:1 (kolor akcentu za jasny → panel przechodzi na czarny)
– Mieści się w 320 px szerokości (1.4.10), działa w trybie wysokiego kontrastu Windows (forced-colors), nie animuje się
– Audyt axe-core 4.10 (WCAG 2.0–2.2 A/AA + dobre praktyki): 0 błędów

Panel NIE czyni strony zgodnej z WCAG – zgodność zapewnia treść i motyw (teksty alternatywne, kontrast, nagłówki, klawiatura, formularze). Nie reklamować go jako „100% zgodności”.

== Aktualizacje ==

Od wersji 1.4.0 wtyczka sama sprawdza nowe wersje w https://github.com/jbalabuch/moveup-wtyczki (plik wtyczki.json) – aktualizacja pojawia się w Kokpit → Aktualizacje, można włączyć automatyczne aktualizacje. Nagłówek „Update URI” sprawia, że WordPress nie myli wtyczki z wtyczką o tej samej nazwie na wordpress.org.
