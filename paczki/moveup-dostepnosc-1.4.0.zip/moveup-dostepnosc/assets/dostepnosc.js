/* moveUP – Dostępność: panel ułatwień. Wczytywany dopiero po najechaniu/fokusie na przycisk, skrócie Alt+Shift+A albo gdy odwiedzający ma zapisane ustawienia. */
(function () {
	'use strict';
	if (window.muA11yPanel) return;

	var d = document, html = d.documentElement, KLUCZ = 'mu-a11y';
	var KLASY = ['mu-odstepy', 'mu-czcionka', 'mu-kontrast-ciemny', 'mu-kontrast-jasny', 'mu-odwroc', 'mu-szarosc',
		'mu-nasycenie-niskie', 'mu-nasycenie-wysokie', 'mu-linki', 'mu-naglowki', 'mu-fokus', 'mu-kursor', 'mu-linijka',
		'mu-maska', 'mu-bez-animacji', 'mu-bez-obrazow', 'mu-czytaj', 'mu-rozmiar'];
	var MAX_KROK = 5; // 100% … 200% co 20% (WCAG 1.4.4: powiększenie tekstu do 200%)
	// Profile: zestawy opcji; r = minimalny krok rozmiaru tekstu. Opcje wyłączone w ustawieniach wtyczki są pomijane.
	var PROFILE = {
		slabowidzacy: { k: ['mu-linki', 'mu-kursor', 'mu-fokus'], r: 2 },
		dysleksja: { k: ['mu-czcionka', 'mu-odstepy', 'mu-linijka'] },
		adhd: { k: ['mu-maska', 'mu-bez-animacji', 'mu-bez-obrazow'] },
		epilepsja: { k: ['mu-bez-animacji', 'mu-nasycenie-niskie'] },
		ruch: { k: ['mu-fokus', 'mu-kursor', 'mu-bez-animacji'] },
		poznawcze: { k: ['mu-linki', 'mu-naglowki', 'mu-czytaj'] }
	};
	var POMIN = '#mu-a11y-panel, .mu-a11y-btn, .mu-a11y-prowadnica';
	var btn = d.querySelector('.mu-a11y-btn');
	var stan = wczytaj();
	var panel = null, status = null, ostatniFokus = null;

	function wczytaj() {
		var s = null;
		try { s = JSON.parse(localStorage.getItem(KLUCZ) || 'null'); } catch (e) {}
		return { r: Math.min(MAX_KROK, (s && +s.r) || 0) };
	}

	function zapisz() {
		var k = KLASY.filter(function (c) { return html.classList.contains(c); }).join(' ');
		try {
			if (k) localStorage.setItem(KLUCZ, JSON.stringify({ k: k, r: stan.r }));
			else localStorage.removeItem(KLUCZ);
		} catch (e) {}
	}

	function oglos(t) {
		if (!status) return;
		status.textContent = '';
		setTimeout(function () { status.textContent = t; }, 50);
	}

	function procent() { return (100 + stan.r * 20) + '%'; }
	function wl(k) { return html.classList.contains(k); }

	/* ---------- Rozmiar tekstu: skalowanie wyliczonych rozmiarów (działa też przy rozmiarach w px) ---------- */
	var obserwator = null;

	function skaluj(korzen) {
		var f = 1 + stan.r * 0.2;
		var lista = korzen.nodeType === 1 ? [korzen].concat([].slice.call(korzen.querySelectorAll('*'))) : [];
		var doZmiany = [];
		lista.forEach(function (el) {
			if (el instanceof SVGElement || /^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE|BR)$/.test(el.tagName) || el.closest(POMIN)) return;
			if (!el.hasAttribute('data-mu-fs')) {
				if (f === 1) return;
				var cs = getComputedStyle(el);
				el.setAttribute('data-mu-fs', parseFloat(cs.fontSize));
				el.setAttribute('data-mu-lh', /px$/.test(cs.lineHeight) ? parseFloat(cs.lineHeight) : '');
				el.setAttribute('data-mu-st', (el.style.fontSize || '') + '|' + (el.style.lineHeight || ''));
			}
			doZmiany.push(el);
		});
		// najpierw odczyty (wyżej), potem zapisy – bez wielokrotnego przeliczania układu
		doZmiany.forEach(function (el) {
			if (f === 1) {
				var st = (el.getAttribute('data-mu-st') || '|').split('|');
				el.style.fontSize = st[0];
				el.style.lineHeight = st[1];
				el.removeAttribute('data-mu-fs'); el.removeAttribute('data-mu-lh'); el.removeAttribute('data-mu-st');
				return;
			}
			el.style.setProperty('font-size', (+el.getAttribute('data-mu-fs') * f).toFixed(2) + 'px');
			var lh = el.getAttribute('data-mu-lh');
			if (lh) el.style.setProperty('line-height', (+lh * f).toFixed(2) + 'px');
		});
	}

	function ustawRozmiar(r) {
		stan.r = Math.max(0, Math.min(MAX_KROK, r));
		html.classList.toggle('mu-rozmiar', stan.r > 0);
		skaluj(d.body);
		if (stan.r > 0 && !obserwator && window.MutationObserver) {
			// treści dociągane później (np. posty z Facebooka, karuzele)
			obserwator = new MutationObserver(function (m) {
				m.forEach(function (x) { [].forEach.call(x.addedNodes, function (n) { if (n.nodeType === 1 && !n.closest(POMIN)) skaluj(n); }); });
			});
			obserwator.observe(d.body, { childList: true, subtree: true });
		} else if (stan.r === 0 && obserwator) {
			obserwator.disconnect(); obserwator = null;
		}
		var w = panel && panel.querySelector('[data-wart]');
		if (w) {
			w.textContent = procent();
			panel.querySelector('[data-krok="-1"]').disabled = stan.r === 0;
			panel.querySelector('[data-krok="1"]').disabled = stan.r === MAX_KROK;
		}
	}

	/* ---------- Ruch ---------- */
	function ruch() {
		var stop = wl('mu-bez-animacji');
		if (stop) [].forEach.call(d.querySelectorAll('video'), function (v) { if (!v.paused) v.pause(); });
		d.dispatchEvent(new CustomEvent('mu-a11y:ruch', { detail: { bezAnimacji: stop } }));
	}

	/* ---------- Linijka i maska czytania: podążają za kursorem, palcem i fokusem ---------- */
	var prowadnica = null, y = -1, klatka = 0;

	function rysuj() {
		klatka = 0;
		if (!prowadnica) return;
		var h = innerHeight, pas = 64; // maska: odsłonięty pas 128 px
		if (wl('mu-linijka')) prowadnica.l.style.transform = 'translateY(' + Math.round(y - 4) + 'px)';
		if (wl('mu-maska')) {
			prowadnica.g.style.height = Math.max(0, y - pas) + 'px';
			prowadnica.d.style.top = Math.min(h, y + pas) + 'px';
		}
	}
	function przesun(ny) { y = ny; if (!klatka) klatka = requestAnimationFrame(rysuj); }
	function naRuch(e) { przesun(e.clientY); }
	function naDotyk(e) { if (e.touches[0]) przesun(e.touches[0].clientY); }
	function naFokus(e) {
		if (!e.target.getBoundingClientRect || e.target.closest(POMIN)) return;
		var r = e.target.getBoundingClientRect();
		przesun(r.top + r.height / 2);
	}

	function prowadnice() {
		var on = wl('mu-linijka') || wl('mu-maska');
		if (on && !prowadnica) {
			prowadnica = { l: d.createElement('div'), g: d.createElement('div'), d: d.createElement('div') };
			prowadnica.l.className = 'mu-a11y-prowadnica mu-a11y-linijka';
			prowadnica.g.className = 'mu-a11y-prowadnica mu-a11y-maska mu-a11y-maska--gora';
			prowadnica.d.className = 'mu-a11y-prowadnica mu-a11y-maska mu-a11y-maska--dol';
			[prowadnica.l, prowadnica.g, prowadnica.d].forEach(function (x) { x.setAttribute('aria-hidden', 'true'); d.body.appendChild(x); });
			d.addEventListener('pointermove', naRuch, { passive: true });
			d.addEventListener('touchmove', naDotyk, { passive: true });
			d.addEventListener('focusin', naFokus);
			if (y < 0) y = innerHeight / 3;
		} else if (!on && prowadnica) {
			[prowadnica.l, prowadnica.g, prowadnica.d].forEach(function (x) { x.remove(); });
			prowadnica = null;
			d.removeEventListener('pointermove', naRuch);
			d.removeEventListener('touchmove', naDotyk);
			d.removeEventListener('focusin', naFokus);
		}
		if (prowadnica) rysuj();
	}

	/* ---------- Czytanie na głos ---------- */
	var CZYTAJ = 'p, h1, h2, h3, h4, h5, h6, li, a, button, td, th, blockquote, figcaption, label, dt, dd';
	var czytany = null;

	function mow(t, el) {
		if (!window.speechSynthesis || !t) return;
		speechSynthesis.cancel();
		var u = new SpeechSynthesisUtterance(t.replace(/\s+/g, ' ').trim());
		var lang = html.lang || 'pl';
		u.lang = lang;
		var g = speechSynthesis.getVoices().filter(function (v) { return v.lang.toLowerCase().indexOf(lang.slice(0, 2).toLowerCase()) === 0; })[0];
		if (g) u.voice = g;
		if (czytany) czytany.classList.remove('mu-czytany');
		czytany = el || null;
		if (czytany) czytany.classList.add('mu-czytany');
		u.onend = u.onerror = function () { if (czytany) czytany.classList.remove('mu-czytany'); czytany = null; };
		speechSynthesis.speak(u);
	}

	function naKlik(e) {
		if (!wl('mu-czytaj') || e.target.closest(POMIN)) return;
		var zazn = String(window.getSelection ? window.getSelection() : '');
		if (zazn.trim()) { mow(zazn); return; }
		var el = e.target.closest(CZYTAJ);
		if (el) mow(el.innerText || el.getAttribute('aria-label') || '', el);
	}

	function naKlawisz(e) {
		if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && e.code === 'KeyR' && wl('mu-czytaj')) {
			e.preventDefault();
			var zazn = String(window.getSelection ? window.getSelection() : '');
			var el = d.activeElement && d.activeElement !== d.body ? d.activeElement : null;
			mow(zazn.trim() ? zazn : el ? (el.innerText || el.getAttribute('aria-label') || el.value || '') : '', el);
		}
	}

	function czytanie() {
		var on = wl('mu-czytaj');
		if (!on && window.speechSynthesis) speechSynthesis.cancel();
		var info = panel && panel.querySelector('[data-czytaj-info]');
		if (info) info.hidden = !on;
	}

	/* ---------- Włączanie opcji (wspólne dla kafelków i profili) ---------- */
	function kafelek(k) { return panel && panel.querySelector('.mu-a11y__opt[data-k="' + k + '"]'); }

	function ustaw(k, on) {
		var t = kafelek(k), g = t && t.getAttribute('data-g');
		if (on && g) {
			[].forEach.call(panel.querySelectorAll('[data-g="' + g + '"]'), function (x) { html.classList.remove(x.getAttribute('data-k')); });
		}
		html.classList.toggle(k, on);
	}

	function skutki() {
		ruch();
		czytanie();
		prowadnice();
	}

	function dostepneW(p) {
		return p.k.filter(function (k) { return !!kafelek(k); });
	}

	function profilWlaczony(p) {
		var k = dostepneW(p);
		var rOk = !p.r || !panel.querySelector('[data-krok]') || stan.r >= p.r;
		return k.length > 0 && rOk && k.every(wl);
	}

	function odswiez() {
		if (!panel) return;
		[].forEach.call(panel.querySelectorAll('.mu-a11y__opt[data-k]'), function (b) {
			b.setAttribute('aria-pressed', wl(b.getAttribute('data-k')) ? 'true' : 'false');
		});
		[].forEach.call(panel.querySelectorAll('.mu-a11y__opt[data-profil]'), function (b) {
			var p = PROFILE[b.getAttribute('data-profil')];
			if (!p || !dostepneW(p).length) { b.remove(); return; }
			b.setAttribute('aria-pressed', profilWlaczony(p) ? 'true' : 'false');
		});
	}

	/* ---------- Ukrywanie przycisku (do końca sesji przeglądarki; wraca skrótem Alt+Shift+A) ---------- */
	function ukryjPrzycisk(ukryj) {
		html.classList.toggle('mu-a11y-ukryty', ukryj);
		try { if (ukryj) sessionStorage.setItem('mu-a11y-ukryty', '1'); else sessionStorage.removeItem('mu-a11y-ukryty'); } catch (e) {}
		var b = panel && panel.querySelector('[data-ukryj]');
		if (b) b.textContent = ukryj ? b.getAttribute('data-pokaz-tekst') : b.getAttribute('data-ukryj-tekst');
	}

	/* ---------- Panel ---------- */
	function zbuduj() {
		var tpl = d.getElementById('mu-a11y-tpl');
		if (!tpl) return false;
		d.body.appendChild(tpl.content.cloneNode(true));
		panel = d.getElementById('mu-a11y-panel');
		status = panel.querySelector('[data-status]');
		panel.hidden = true;

		var czyt = kafelek('mu-czytaj');
		if (czyt && !window.speechSynthesis) czyt.remove(); // przeglądarka bez syntezy mowy

		panel.addEventListener('click', function (e) {
			var b = e.target.closest('button');
			if (!b) return;
			if (b.classList.contains('mu-a11y__close')) { zamknij(true); return; }
			if (b.hasAttribute('data-ukryj')) {
				var ukryj = !wl('mu-a11y-ukryty');
				ukryjPrzycisk(ukryj);
				oglos(ukryj ? b.getAttribute('data-komunikat') : b.textContent);
				return;
			}
			if (b.classList.contains('mu-a11y__reset')) { reset(); return; }
			if (b.hasAttribute('data-krok')) {
				ustawRozmiar(stan.r + (+b.getAttribute('data-krok')));
				odswiez();
				zapisz();
				oglos(panel.querySelector('#mu-a11y-rozm').textContent + ': ' + procent());
				if (b.disabled) b.parentNode.querySelector('[data-krok]:not([disabled])').focus(); // fokus nie ginie na wyłączonym przycisku
				return;
			}
			if (b.hasAttribute('data-profil')) {
				var p = PROFILE[b.getAttribute('data-profil')], on = !profilWlaczony(p);
				dostepneW(p).forEach(function (k) { ustaw(k, on); });
				if (p.r && panel.querySelector('[data-krok]')) ustawRozmiar(on ? Math.max(stan.r, p.r) : 0);
				skutki(); odswiez(); zapisz();
				return;
			}
			var k = b.getAttribute('data-k');
			if (!k) return;
			ustaw(k, !wl(k));
			skutki(); odswiez(); zapisz();
		});

		panel.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') { e.stopPropagation(); zamknij(true); }
		});
		ustawRozmiar(stan.r);
		czytanie();
		ukryjPrzycisk(wl('mu-a11y-ukryty'));
		odswiez();
		return true;
	}

	function otworz() {
		if (!panel && !zbuduj()) return;
		ostatniFokus = d.activeElement;
		panel.hidden = false;
		btn.setAttribute('aria-expanded', 'true');
		panel.querySelector('#mu-a11y-tytul').focus();
		d.addEventListener('keydown', escGlobalnie);
		d.addEventListener('pointerdown', klikPoza, true);
	}

	function zamknij(oddajFokus) {
		if (!panel || panel.hidden) return;
		panel.hidden = true;
		btn.setAttribute('aria-expanded', 'false');
		d.removeEventListener('keydown', escGlobalnie);
		d.removeEventListener('pointerdown', klikPoza, true);
		if (oddajFokus) {
			// przycisk ukryty → fokus wraca tam, gdzie był przed otwarciem (np. po skrócie klawiszowym)
			var cel = wl('mu-a11y-ukryty') ? ostatniFokus : btn;
			if (cel && cel.focus && cel !== d.body) cel.focus();
		}
	}

	function escGlobalnie(e) { if (e.key === 'Escape') zamknij(panel.contains(d.activeElement)); }
	function klikPoza(e) { if (!panel.contains(e.target) && !btn.contains(e.target)) zamknij(false); }

	function reset() {
		KLASY.forEach(function (c) { html.classList.remove(c); });
		ustawRozmiar(0);
		skutki(); odswiez(); zapisz();
		oglos(panel.querySelector('.mu-a11y__reset:not([data-ukryj])').textContent);
	}

	/* ---------- Start ---------- */
	function start() {
		if (stan.r > 0) ustawRozmiar(stan.r);
		if (wl('mu-bez-animacji')) ruch();
		prowadnice();
		d.addEventListener('click', naKlik, true);
		d.addEventListener('keydown', naKlawisz);
		window.muA11yPanel = { toggle: function () { panel && !panel.hidden ? zamknij(true) : otworz(); }, otworz: otworz, zamknij: zamknij };
		if (window.muA11yOtworz) { window.muA11yOtworz = 0; otworz(); }
	}

	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})();
