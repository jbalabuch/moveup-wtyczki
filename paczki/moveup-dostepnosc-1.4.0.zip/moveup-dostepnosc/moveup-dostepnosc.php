<?php
/**
 * Plugin Name: moveUP – Dostępność
 * Description: Panel ułatwień dostępu (rozmiar tekstu, odstępy, kontrast, podświetlanie linków, wyraźny fokus, zatrzymanie animacji, czytanie na głos) i wyłączanie animacji na całej stronie. Lekki: na starcie strony tylko przycisk i kilka setek bajtów kodu, reszta wczytuje się po pierwszym użyciu.
 * Version: 1.4.0
 * Author: moveUP Agency
 * Text Domain: moveup-dostepnosc
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-dostepnosc' );

define( 'MU_DOST_VER', '1.4.0' );
define( 'MU_DOST_URL', plugin_dir_url( __FILE__ ) );
define( 'MU_DOST_OPCJA', 'mu_dostepnosc' );

/* -------------------------------------------------------------------------
 * Ustawienia
 * ---------------------------------------------------------------------- */
function mu_dost_funkcje() {
	return array(
		'rozmiar'    => __( 'Rozmiar tekstu', 'moveup-dostepnosc' ),
		'odstepy'    => __( 'Odstępy w tekście', 'moveup-dostepnosc' ),
		'czcionka'   => __( 'Czytelna czcionka', 'moveup-dostepnosc' ),
		'kontrast'   => __( 'Kontrast i kolory', 'moveup-dostepnosc' ),
		'linki'      => __( 'Podkreśl linki', 'moveup-dostepnosc' ),
		'naglowki'   => __( 'Wyróżnij nagłówki', 'moveup-dostepnosc' ),
		'fokus'      => __( 'Wyraźny fokus', 'moveup-dostepnosc' ),
		'kursor'     => __( 'Duży kursor', 'moveup-dostepnosc' ),
		'linijka'    => __( 'Linijka do czytania', 'moveup-dostepnosc' ),
		'maska'      => __( 'Maska czytania', 'moveup-dostepnosc' ),
		'animacje'   => __( 'Zatrzymaj animacje', 'moveup-dostepnosc' ),
		'obrazy'     => __( 'Ukryj obrazy', 'moveup-dostepnosc' ),
		'czytaj'     => __( 'Czytaj na głos', 'moveup-dostepnosc' ),
		'profile'    => __( 'Profile (gotowe zestawy opcji)', 'moveup-dostepnosc' ),
		'ukryj'      => __( 'Ukrywanie przycisku przez odwiedzającego (wraca skrótem Alt + Shift + A)', 'moveup-dostepnosc' ),
	);
}

function mu_dost_domyslne() {
	$w = mu_dost_wykryj();
	return array(
		'wlaczony'          => 1,
		'funkcje'           => array_keys( mu_dost_funkcje() ),
		'strona'            => 'prawa',   // prawa | lewa
		'odstep_dol'        => 20,
		'odstep_bok'        => 20,
		'kolor_tla'         => $w['kolor_tla'],
		'kolor_ikony'       => $w['kolor_ikony'],
		'deklaracja'        => $w['deklaracja'],
		'ruch_systemowy'    => 1,         // prefers-reduced-motion = bez animacji
		'bez_animacji'      => 0,         // wyłącz animacje wszystkim odwiedzającym
	);
}

/**
 * Wartości startowe odczytane ze strony: kolor przycisku z palety motywu, adres deklaracji dostępności.
 * Wynik w pamięci podręcznej na 12 h (front nie odpytuje bazy przy każdym wejściu, dopóki ustawienia nie są zapisane).
 */
function mu_dost_wykryj( $odswiez = false ) {
	$w = $odswiez ? false : get_transient( 'mu_dost_wykryte' );
	if ( is_array( $w ) ) {
		return $w;
	}
	$kolor = '';
	$zrodlo = '';
	// Kadence: aktywna paleta, palette1 = kolor akcentu
	$kp = json_decode( (string) get_option( 'kadence_global_palette' ), true );
	if ( is_array( $kp ) && ! empty( $kp['active'] ) && ! empty( $kp[ $kp['active'] ] ) ) {
		foreach ( $kp[ $kp['active'] ] as $c ) {
			if ( isset( $c['slug'], $c['color'] ) && 'palette1' === $c['slug'] ) {
				$kolor  = sanitize_hex_color( $c['color'] );
				$zrodlo = 'Kadence (palette1)';
			}
		}
	}
	// Kadence bez zapisanej palety – domyślny palette1 motywu
	if ( ! $kolor && 'kadence' === get_template() ) {
		$kolor  = '#2b6cb0';
		$zrodlo = 'Kadence (domyślna paleta)';
	}
	// Motyw blokowy / theme.json: kolor „primary”, „accent” albo „contrast”
	if ( ! $kolor && function_exists( 'wp_get_global_settings' ) ) {
		$pal = wp_get_global_settings( array( 'color', 'palette', 'theme' ) );
		if ( is_array( $pal ) ) {
			foreach ( array( 'primary', 'accent', 'contrast' ) as $slug ) {
				foreach ( $pal as $c ) {
					if ( ! $kolor && isset( $c['slug'], $c['color'] ) && $slug === $c['slug'] && sanitize_hex_color( $c['color'] ) ) {
						$kolor  = sanitize_hex_color( $c['color'] );
						$zrodlo = 'theme.json (' . $slug . ')';
					}
				}
			}
		}
	}
	if ( ! $kolor ) {
		$kolor  = '#1a1a1a';
		$zrodlo = '';
	}
	// Strona z deklaracją dostępności: adres /deklaracja-dostepnosci/ albo tytuł
	$dekl = get_page_by_path( 'deklaracja-dostepnosci' );
	if ( ! $dekl || 'publish' !== $dekl->post_status ) {
		$q    = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 's' => 'deklaracja dostępności', 'posts_per_page' => 1, 'fields' => 'ids' ) );
		$dekl = $q ? get_post( $q[0] ) : null;
	}
	$w = array(
		'kolor_tla'   => $kolor,
		// ikona biała, jeśli ma z tłem min. 3:1 (WCAG 1.4.11), inaczej czarna
		'kolor_ikony' => mu_dost_kontrast( $kolor, '#ffffff' ) >= 3 ? '#ffffff' : '#000000',
		'deklaracja'  => $dekl ? get_permalink( $dekl ) : '',
		'zrodlo'      => $zrodlo,
	);
	set_transient( 'mu_dost_wykryte', $w, 12 * HOUR_IN_SECONDS );
	return $w;
}

function mu_dost_skonfigurowana() {
	return false !== get_option( MU_DOST_OPCJA, false );
}

function mu_dost_opcje() {
	$o = get_option( MU_DOST_OPCJA, array() );
	$o = wp_parse_args( is_array( $o ) ? $o : array(), mu_dost_domyslne() );
	// Funkcje dodane w nowszej wersji (nieznane przy ostatnim zapisie ustawień) są domyślnie włączone.
	if ( isset( $o['znane'] ) || get_option( MU_DOST_OPCJA ) ) {
		$znane      = isset( $o['znane'] ) ? (array) $o['znane'] : array( 'rozmiar', 'odstepy', 'czcionka', 'kontrast', 'linki', 'naglowki', 'fokus', 'kursor', 'animacje', 'czytaj' );
		$o['funkcje'] = array_values( array_unique( array_merge( (array) $o['funkcje'], array_diff( array_keys( mu_dost_funkcje() ), $znane ) ) ) );
	}
	return $o;
}

/* -------------------------------------------------------------------------
 * CSS zatrzymujący ruch – wspólny dla ustawienia strony, systemu i panelu
 * ---------------------------------------------------------------------- */
function mu_dost_css_bez_ruchu( $prefiks ) {
	$s = $prefiks ? $prefiks . ' ' : '';
	return $s . '*,' . $s . '*::before,' . $s . '*::after{animation-duration:.001ms!important;animation-delay:0s!important;animation-iteration-count:1!important;transition-duration:.001ms!important;transition-delay:0s!important;scroll-behavior:auto!important}'
		. ( $prefiks ? $prefiks : 'html' ) . '{scroll-behavior:auto!important}'
		. $s . '[data-aos]{opacity:1!important;transform:none!important}';
}

/* -------------------------------------------------------------------------
 * Front: w <head> mały CSS przycisku + skrypt przywracający zapisane ustawienia
 * ---------------------------------------------------------------------- */
add_action( 'wp_head', function () {
	$o = mu_dost_opcje();
	$css = '';
	if ( $o['bez_animacji'] ) {
		$css .= mu_dost_css_bez_ruchu( '' );
	} elseif ( $o['ruch_systemowy'] ) {
		$css .= '@media (prefers-reduced-motion:reduce){' . mu_dost_css_bez_ruchu( '' ) . '}';
	}
	if ( $o['wlaczony'] ) {
		$bok   = 'lewa' === $o['strona'] ? 'left' : 'right';
		$css  .= '.mu-a11y-btn{position:fixed;z-index:2147483000;bottom:' . absint( $o['odstep_dol'] ) . 'px;' . $bok . ':' . absint( $o['odstep_bok'] ) . 'px;width:48px;height:48px;margin:0;padding:0;border:2px solid ' . esc_attr( $o['kolor_ikony'] ) . ';border-radius:50%;background:' . esc_attr( $o['kolor_tla'] ) . ';color:' . esc_attr( $o['kolor_ikony'] ) . ';cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.35)}'
			. '.mu-a11y-btn:hover,.mu-a11y-btn:focus,.mu-a11y-btn:active{background:' . esc_attr( $o['kolor_tla'] ) . '!important;color:' . esc_attr( $o['kolor_ikony'] ) . '!important;border-color:' . esc_attr( $o['kolor_ikony'] ) . '!important}'
			. '.mu-a11y-btn:hover{box-shadow:0 4px 14px rgba(0,0,0,.4)}'
			. '.mu-a11y-btn svg{width:30px;height:30px;fill:currentColor;pointer-events:none}'
			. '.mu-a11y-btn:focus-visible{outline:3px solid ' . esc_attr( $o['kolor_tla'] ) . ';outline-offset:3px;box-shadow:0 0 0 3px #fff}'
			. 'html.mu-a11y-ukryty .mu-a11y-btn{display:none!important}'
			. '@media print{.mu-a11y-btn,.mu-a11y{display:none!important}}';
	}
	if ( $css ) {
		echo '<style id="mu-a11y-css">' . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- wartości oczyszczone wyżej
	}
	if ( $o['bez_animacji'] ) {
		// sygnał dla skryptów (karuzele, slidery), że animacje są wyłączone na całej stronie
		echo '<script>document.documentElement.classList.add("mu-bez-animacji-strona")</script>' . "\n";
	}
	if ( $o['wlaczony'] ) {
		// Zapisane ustawienia odwiedzającego: klasy na <html> od razu (bez mignięcia), pełny CSS i JS tylko wtedy, gdy coś jest włączone.
		$cfg = array( 'css' => MU_DOST_URL . 'assets/dostepnosc.css?ver=' . MU_DOST_VER, 'js' => MU_DOST_URL . 'assets/dostepnosc.js?ver=' . MU_DOST_VER );
		echo '<script id="mu-a11y-init">(function(d,c){var s;window.muA11y=c;try{if(sessionStorage.getItem("mu-a11y-ukryty"))d.documentElement.className+=" mu-a11y-ukryty";s=JSON.parse(localStorage.getItem("mu-a11y")||"null")}catch(e){}if(!s||!s.k)return;d.documentElement.className+=" "+s.k;'
			. 'var l=d.createElement("link");l.rel="stylesheet";l.href=c.css;d.head.appendChild(l);var j=d.createElement("script");j.src=c.js;j.defer=true;d.head.appendChild(j)})(document,'
			. wp_json_encode( $cfg ) . ");</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}, 1 );

/* -------------------------------------------------------------------------
 * Front: przycisk + panel w <template> (bezczynny, bez kosztu renderowania)
 * ---------------------------------------------------------------------- */
add_action( 'wp_footer', function () {
	$o = mu_dost_opcje();
	if ( ! $o['wlaczony'] ) {
		return;
	}
	$f   = array_flip( (array) $o['funkcje'] );
	$bok = 'lewa' === $o['strona'] ? 'left' : 'right';
	include __DIR__ . '/tmpl/panel.php';
}, 5 );

/* -------------------------------------------------------------------------
 * Panel w kokpicie: Ustawienia → Dostępność
 * ---------------------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_options_page( __( 'Dostępność', 'moveup-dostepnosc' ), __( 'Dostępność', 'moveup-dostepnosc' ), 'manage_options', 'moveup-dostepnosc', 'mu_dost_strona_ustawien' );
} );

add_action( 'admin_init', function () {
	register_setting( 'moveup-dostepnosc', MU_DOST_OPCJA, array( 'type' => 'array', 'sanitize_callback' => 'mu_dost_oczysc' ) );
} );

function mu_dost_oczysc( $v ) {
	$d = mu_dost_domyslne();
	$v = is_array( $v ) ? $v : array();
	$kolor = function ( $k ) use ( $v, $d ) {
		$c = isset( $v[ $k ] ) ? sanitize_hex_color( $v[ $k ] ) : '';
		return $c ? $c : $d[ $k ];
	};
	return array(
		'wlaczony'       => empty( $v['wlaczony'] ) ? 0 : 1,
		'funkcje'        => array_values( array_intersect( array_keys( mu_dost_funkcje() ), isset( $v['funkcje'] ) ? (array) $v['funkcje'] : array() ) ),
		'znane'          => array_keys( mu_dost_funkcje() ),
		'strona'         => ( isset( $v['strona'] ) && 'lewa' === $v['strona'] ) ? 'lewa' : 'prawa',
		'odstep_dol'     => min( 400, absint( isset( $v['odstep_dol'] ) ? $v['odstep_dol'] : $d['odstep_dol'] ) ),
		'odstep_bok'     => min( 400, absint( isset( $v['odstep_bok'] ) ? $v['odstep_bok'] : $d['odstep_bok'] ) ),
		'kolor_tla'      => $kolor( 'kolor_tla' ),
		'kolor_ikony'    => $kolor( 'kolor_ikony' ),
		'deklaracja'     => isset( $v['deklaracja'] ) ? esc_url_raw( trim( $v['deklaracja'] ) ) : '',
		'ruch_systemowy' => empty( $v['ruch_systemowy'] ) ? 0 : 1,
		'bez_animacji'   => empty( $v['bez_animacji'] ) ? 0 : 1,
	);
}

/** Współczynnik kontrastu WCAG dwóch kolorów #rrggbb */
function mu_dost_kontrast( $a, $b ) {
	$l = function ( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$c = array();
		foreach ( array( 0, 2, 4 ) as $i ) {
			$x   = hexdec( substr( $hex, $i, 2 ) ) / 255;
			$c[] = $x <= 0.04045 ? $x / 12.92 : pow( ( $x + 0.055 ) / 1.055, 2.4 );
		}
		return 0.2126 * $c[0] + 0.7152 * $c[1] + 0.0722 * $c[2];
	};
	$x = $l( $a );
	$y = $l( $b );
	return ( max( $x, $y ) + 0.05 ) / ( min( $x, $y ) + 0.05 );
}

function mu_dost_strona_ustawien() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o = mu_dost_opcje();
	$n = MU_DOST_OPCJA;
	$k = mu_dost_kontrast( $o['kolor_tla'], $o['kolor_ikony'] );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Dostępność', 'moveup-dostepnosc' ); ?></h1>
		<?php
		if ( ! mu_dost_skonfigurowana() ) :
			$w = mu_dost_wykryj( true );
			?>
		<div class="notice notice-info" style="padding:12px 16px">
			<h2 style="margin:0 0 8px"><?php esc_html_e( 'Pierwsze ustawienie', 'moveup-dostepnosc' ); ?></h2>
			<p style="margin:0 0 6px"><?php esc_html_e( 'Przycisk ułatwień już działa na stronie. Uzupełniliśmy ustawienia na podstawie strony – sprawdź je i kliknij „Zapisz zmiany” na dole.', 'moveup-dostepnosc' ); ?></p>
			<ul style="list-style:disc;margin:0 0 0 20px">
				<li>
					<?php
					if ( $w['zrodlo'] ) {
						/* translators: 1: kolor, 2: źródło */
						printf( esc_html__( 'Kolor przycisku: %1$s – z motywu, %2$s.', 'moveup-dostepnosc' ), '<span style="display:inline-block;width:14px;height:14px;border-radius:50%;vertical-align:-2px;background:' . esc_attr( $w['kolor_tla'] ) . '"></span> <code>' . esc_html( $w['kolor_tla'] ) . '</code>', esc_html( $w['zrodlo'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput
					} else {
						esc_html_e( 'Kolor przycisku: nie znaleźliśmy koloru motywu, ustawiliśmy prawie czarny – wybierz kolor marki poniżej.', 'moveup-dostepnosc' );
					}
					?>
				</li>
				<li>
					<?php
					if ( $w['deklaracja'] ) {
						/* translators: %s: adres */
						printf( esc_html__( 'Deklaracja dostępności: %s', 'moveup-dostepnosc' ), '<a href="' . esc_url( $w['deklaracja'] ) . '" target="_blank">' . esc_html( $w['deklaracja'] ) . '</a>' ); // phpcs:ignore WordPress.Security.EscapeOutput
					} else {
						esc_html_e( 'Deklaracja dostępności: nie znaleźliśmy takiej strony. Jeśli ją masz, wklej adres poniżej.', 'moveup-dostepnosc' );
					}
					?>
				</li>
				<li><?php esc_html_e( 'Położenie: prawy dolny róg. Zmień, jeśli w tym miejscu jest już np. czat albo przycisk „do góry”.', 'moveup-dostepnosc' ); ?></li>
			</ul>
		</div>
		<?php endif; ?>
		<p><?php esc_html_e( 'Panel pomaga odwiedzającym dopasować stronę do swoich potrzeb. Nie zastępuje dostępności samej strony (teksty alternatywne, kontrast, nagłówki, obsługa klawiaturą) – tę trzeba zapewnić w treści i w motywie.', 'moveup-dostepnosc' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'moveup-dostepnosc' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Panel ułatwień', 'moveup-dostepnosc' ); ?></th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[wlaczony]" value="1" <?php checked( $o['wlaczony'] ); ?>> <?php esc_html_e( 'Pokazuj przycisk i panel na stronie', 'moveup-dostepnosc' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Funkcje w panelu', 'moveup-dostepnosc' ); ?></th>
					<td><fieldset><legend class="screen-reader-text"><?php esc_html_e( 'Funkcje w panelu', 'moveup-dostepnosc' ); ?></legend>
					<?php foreach ( mu_dost_funkcje() as $id => $nazwa ) : ?>
						<label style="display:block;margin:0 0 6px"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[funkcje][]" value="<?php echo esc_attr( $id ); ?>" <?php checked( in_array( $id, (array) $o['funkcje'], true ) ); ?>> <?php echo esc_html( $nazwa ); ?></label>
					<?php endforeach; ?>
					</fieldset></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Animacje na stronie', 'moveup-dostepnosc' ); ?></th>
					<td>
						<label style="display:block;margin:0 0 6px"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[bez_animacji]" value="1" <?php checked( $o['bez_animacji'] ); ?>> <?php esc_html_e( 'Wyłącz wszystkie animacje dla wszystkich odwiedzających', 'moveup-dostepnosc' ); ?></label>
						<label style="display:block"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[ruch_systemowy]" value="1" <?php checked( $o['ruch_systemowy'] ); ?>> <?php esc_html_e( 'Wyłączaj animacje osobom, które w systemie ustawiły ograniczenie ruchu (zalecane)', 'moveup-dostepnosc' ); ?></label>
						<p class="description"><?php esc_html_e( 'Zatrzymuje animacje i przejścia CSS oraz animacje przy przewijaniu (np. Kadence). Karuzele z własnym skryptem trzeba zatrzymać w ich ustawieniach.', 'moveup-dostepnosc' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Położenie przycisku', 'moveup-dostepnosc' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( $n ); ?>[strona]" aria-label="<?php esc_attr_e( 'Strona ekranu', 'moveup-dostepnosc' ); ?>">
							<option value="prawa" <?php selected( $o['strona'], 'prawa' ); ?>><?php esc_html_e( 'Prawy dolny róg', 'moveup-dostepnosc' ); ?></option>
							<option value="lewa" <?php selected( $o['strona'], 'lewa' ); ?>><?php esc_html_e( 'Lewy dolny róg', 'moveup-dostepnosc' ); ?></option>
						</select>
						<label><?php esc_html_e( 'od dołu', 'moveup-dostepnosc' ); ?> <input type="number" min="0" max="400" class="small-text" name="<?php echo esc_attr( $n ); ?>[odstep_dol]" value="<?php echo esc_attr( $o['odstep_dol'] ); ?>"> px</label>
						<label><?php esc_html_e( 'od boku', 'moveup-dostepnosc' ); ?> <input type="number" min="0" max="400" class="small-text" name="<?php echo esc_attr( $n ); ?>[odstep_bok]" value="<?php echo esc_attr( $o['odstep_bok'] ); ?>"> px</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Kolory przycisku', 'moveup-dostepnosc' ); ?></th>
					<td>
						<label><?php esc_html_e( 'Tło', 'moveup-dostepnosc' ); ?> <input type="color" name="<?php echo esc_attr( $n ); ?>[kolor_tla]" value="<?php echo esc_attr( $o['kolor_tla'] ); ?>"></label>
						<label style="margin-left:12px"><?php esc_html_e( 'Ikona', 'moveup-dostepnosc' ); ?> <input type="color" name="<?php echo esc_attr( $n ); ?>[kolor_ikony]" value="<?php echo esc_attr( $o['kolor_ikony'] ); ?>"></label>
						<p class="description">
							<?php
							/* translators: %s: współczynnik kontrastu */
							printf( esc_html__( 'Kontrast ikony do tła: %s:1.', 'moveup-dostepnosc' ), esc_html( number_format_i18n( $k, 2 ) ) );
							echo ' ';
							echo $k >= 3 ? esc_html__( 'Spełnia WCAG 1.4.11 (min. 3:1).', 'moveup-dostepnosc' ) : '<strong>' . esc_html__( 'Za mało – WCAG 1.4.11 wymaga min. 3:1.', 'moveup-dostepnosc' ) . '</strong>';
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mu-dekl"><?php esc_html_e( 'Deklaracja dostępności', 'moveup-dostepnosc' ); ?></label></th>
					<td><input type="url" id="mu-dekl" class="regular-text" name="<?php echo esc_attr( $n ); ?>[deklaracja]" value="<?php echo esc_attr( $o['deklaracja'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/deklaracja-dostepnosci/' ) ); ?>">
					<p class="description"><?php esc_html_e( 'Adres strony z deklaracją – link pojawi się na dole panelu. Puste = bez linku.', 'moveup-dostepnosc' ); ?></p></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * Pierwsze uruchomienie: po włączeniu – ustawienia; do pierwszego zapisu – przypomnienie w kokpicie
 * ---------------------------------------------------------------------- */
register_activation_hook( __FILE__, function () {
	delete_transient( 'mu_dost_wykryte' );
	if ( ! mu_dost_skonfigurowana() ) {
		set_transient( 'mu_dost_powitanie', 1, 60 );
	}
} );

add_action( 'admin_init', function () {
	if ( ! get_transient( 'mu_dost_powitanie' ) ) {
		return;
	}
	delete_transient( 'mu_dost_powitanie' );
	// nie przy włączaniu kilku wtyczek naraz ani przy wp-cli/AJAX
	if ( wp_doing_ajax() || ( defined( 'WP_CLI' ) && WP_CLI ) || isset( $_GET['activate-multi'] ) || ! current_user_can( 'manage_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	wp_safe_redirect( admin_url( 'options-general.php?page=moveup-dostepnosc' ) );
	exit;
} );

add_action( 'admin_notices', function () {
	if ( mu_dost_skonfigurowana() || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$ekran = get_current_screen();
	if ( $ekran && 'settings_page_moveup-dostepnosc' === $ekran->id ) {
		return;
	}
	printf(
		'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
		esc_html__( 'moveUP – Dostępność: sprawdź kolor przycisku i link do deklaracji dostępności.', 'moveup-dostepnosc' ),
		esc_url( admin_url( 'options-general.php?page=moveup-dostepnosc' ) ),
		esc_html__( 'Dokończ ustawienia', 'moveup-dostepnosc' )
	);
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $l ) {
	array_unshift( $l, '<a href="' . esc_url( admin_url( 'options-general.php?page=moveup-dostepnosc' ) ) . '">' . esc_html__( 'Ustawienia', 'moveup-dostepnosc' ) . '</a>' );
	return $l;
} );
