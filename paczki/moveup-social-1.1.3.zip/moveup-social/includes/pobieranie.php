<?php
/**
 * moveUP – Social: pobieranie kanałów RSS, porządkowanie postów, zdjęcia na serwer strony.
 * Logika jak w MONAR – Facebook 1.3.15 (duplikaty albumów, puste udostępnienia), osobno dla każdego źródła.
 */

defined( 'ABSPATH' ) || exit;

function mus_opcja_postow( $id ) {
	return 'mu_social_posty_' . sanitize_key( $id );
}

/** Ile postów trzymać dla źródła: największa liczba z feedów, które go używają (min. 12). */
function mus_ile_trzymac( $id ) {
	$ile = 12;
	foreach ( mus_opcje()['feedy'] as $f ) {
		if ( in_array( $id, $f['zrodla'], true ) ) {
			$ile = max( $ile, (int) $f['liczba'] );
		}
	}
	return min( 30, $ile );
}

/**
 * Odświeża wszystkie źródła.
 *
 * @return array id źródła => liczba postów albo WP_Error
 */
function mus_odswiez_wszystko() {
	$wyniki = array();
	foreach ( mus_opcje()['zrodla'] as $z ) {
		$wyniki[ $z['id'] ] = mus_odswiez_zrodlo( $z );
	}
	// Posty po usuniętych źródłach.
	$ids = wp_list_pluck( mus_opcje()['zrodla'], 'id' );
	foreach ( (array) get_option( 'mu_social_znane', array() ) as $stare ) {
		if ( ! in_array( $stare, $ids, true ) ) {
			delete_option( mus_opcja_postow( $stare ) );
			foreach ( glob( mus_katalog()['dir'] . '/' . sanitize_key( $stare ) . '-*.webp' ) ?: array() as $plik ) {
				wp_delete_file( $plik );
			}
		}
	}
	update_option( 'mu_social_znane', $ids, false );
	return $wyniki;
}

function mus_katalog() {
	$k = wp_upload_dir();
	return array(
		'dir' => trailingslashit( $k['basedir'] ) . 'moveup-social',
		'url' => trailingslashit( $k['baseurl'] ) . 'moveup-social',
	);
}

/**
 * Pobiera kanał źródła, wybiera posty ze zdjęciem, usuwa duplikaty, zapisuje zdjęcia lokalnie.
 *
 * @return int|WP_Error Liczba zapisanych postów.
 */
function mus_odswiez_zrodlo( $z ) {
	if ( empty( $z['rss'] ) ) {
		return 0;
	}
	$res = wp_remote_get( $z['rss'], array( 'timeout' => 20 ) );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	if ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return new WP_Error( 'mus_http', 'Kanał RSS zwrócił kod ' . wp_remote_retrieve_response_code( $res ) );
	}
	$prev = libxml_use_internal_errors( true );
	$xml  = simplexml_load_string( wp_remote_retrieve_body( $res ) );
	libxml_use_internal_errors( $prev );
	if ( ! $xml || empty( $xml->channel->item ) ) {
		return new WP_Error( 'mus_xml', 'Nie udało się odczytać kanału RSS.' );
	}

	$kandydaci = array();
	foreach ( $xml->channel->item as $item ) {
		$tytul = (string) $item->title;
		if ( 0 === stripos( $tytul, "This content isn't available" ) ) {
			continue;
		}
		$opis  = (string) $item->description;
		$img   = '';
		$media = $item->children( 'http://search.yahoo.com/mrss/' );
		if ( isset( $media->content ) ) {
			$img = (string) $media->content->attributes()->url;
		}
		if ( ! $img && preg_match( '/<img[^>]+src="([^"]+)"/i', $opis, $m ) ) {
			$img = html_entity_decode( $m[1] );
		}
		if ( ! $img ) {
			continue; // bez zdjęcia nie pokazujemy
		}
		$tekst = mus_czysty_tekst( $opis );
		if ( 'facebook' === $z['serwis'] && '' === $tekst ) {
			continue; // udostępnienia bez tekstu na Facebooku wyglądają na błąd; na Instagramie zdjęcie bez opisu jest normalne
		}
		$kandydaci[] = array(
			'id'    => (string) $item->guid ?: (string) $item->link,
			'link'  => (string) $item->link,
			'czas'  => (int) strtotime( (string) $item->pubDate ),
			'tekst' => wp_encode_emoji( $tekst ), // baza bez utf8mb4 nie przyjmie surowych emoji
			'img'   => $img,
			'klucz' => basename( (string) wp_parse_url( $img, PHP_URL_PATH ) ), // ten sam plik = ten sam album
		);
	}

	// Duplikaty albumu: zostaje wpis z najdłuższym tekstem.
	$unikalne = array();
	foreach ( $kandydaci as $k ) {
		if ( ! isset( $unikalne[ $k['klucz'] ] ) || mb_strlen( $k['tekst'] ) > mb_strlen( $unikalne[ $k['klucz'] ]['tekst'] ) ) {
			$unikalne[ $k['klucz'] ] = $k;
		}
	}
	// Ten sam post opublikowany dwa razy (identyczna pierwsza linia tekstu): zostaje dłuższa wersja. Posty bez tekstu – bez łączenia.
	$wg_tekstu = array();
	foreach ( $unikalne as $klucz => $k ) {
		$linia = mb_substr( mb_strtolower( trim( (string) strtok( html_entity_decode( $k['tekst'] ), "\n" ) ) ), 0, 80 );
		$linia = '' === $linia ? 'bez-tekstu-' . $klucz : $linia;
		if ( ! isset( $wg_tekstu[ $linia ] ) || mb_strlen( $k['tekst'] ) > mb_strlen( $wg_tekstu[ $linia ]['tekst'] ) ) {
			$wg_tekstu[ $linia ] = $k;
		}
	}
	$posty = array_values( $wg_tekstu );
	usort( $posty, function ( $a, $b ) {
		return $b['czas'] <=> $a['czas'];
	} );
	$posty = array_slice( $posty, 0, mus_ile_trzymac( $z['id'] ) );

	$kat = mus_katalog();
	wp_mkdir_p( $kat['dir'] );
	$przedrostek = sanitize_key( $z['id'] ) . '-';
	$zostaw      = array();
	foreach ( $posty as $i => $post ) {
		$plik = $przedrostek . md5( $post['klucz'] ) . '.webp';
		$cel  = $kat['dir'] . '/' . $plik;
		if ( ! file_exists( $cel ) && ! mus_zapisz_zdjecie( $post['img'], $cel ) ) {
			unset( $posty[ $i ] );
			continue;
		}
		$wym                = function_exists( 'wp_getimagesize' ) ? wp_getimagesize( $cel ) : getimagesize( $cel );
		$zostaw[]           = $plik;
		$posty[ $i ]['zdj'] = $kat['url'] . '/' . $plik;
		$posty[ $i ]['w']   = $wym ? (int) $wym[0] : 0;
		$posty[ $i ]['h']   = $wym ? (int) $wym[1] : 0;
		unset( $posty[ $i ]['img'], $posty[ $i ]['klucz'] );
	}
	foreach ( glob( $kat['dir'] . '/' . $przedrostek . '*.webp' ) ?: array() as $stary ) {
		if ( ! in_array( basename( $stary ), $zostaw, true ) ) {
			wp_delete_file( $stary );
		}
	}

	$posty = array_values( $posty );
	if ( ! $posty ) {
		return new WP_Error( 'mus_pusto', 'W kanale nie ma postów ze zdjęciami.' );
	}
	$opcja  = mus_opcja_postow( $z['id'] );
	$stare  = get_option( $opcja, array() );
	$zmiana = wp_list_pluck( $posty, 'id' ) !== wp_list_pluck( $stare['posty'] ?? array(), 'id' );
	update_option( $opcja, array( 'czas' => time(), 'posty' => $posty ), false );
	if ( empty( get_option( $opcja )['posty'] ) ) {
		return new WP_Error( 'mus_zapis', 'Nie udało się zapisać postów w bazie danych.' );
	}
	if ( $zmiana ) {
		do_action( 'litespeed_purge_all' ); // strony z cache pokażą nowe posty
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache(); // WP Super Cache (serwery Apache bez LiteSpeed) – od 1.0.3
		}
	}
	return count( $posty );
}

function mus_czysty_tekst( $html ) {
	$t = preg_replace( '/<br\s*\/?>/i', "\n", $html );
	$t = html_entity_decode( wp_strip_all_tags( $t ), ENT_QUOTES, 'UTF-8' );
	$t = preg_replace( '~^\s*https?://(www\.)?facebook\.com/share/\S+~m', '', $t ); // gołe linki udostępnień
	$t = preg_replace( "/[ \t]+/", ' ', $t );
	$t = preg_replace( "/ *\n */", "\n", $t );
	$t = preg_replace( "/\n{3,}/", "\n\n", $t );
	return trim( $t );
}

/** Zdjęcie do webp, najdłuższy bok 720 px (wystarczy na kafel 360 px przy ekranach 2×), jakość 80. */
function mus_zapisz_zdjecie( $zrodlo, $cel ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$tmp = download_url( $zrodlo, 20 );
	if ( is_wp_error( $tmp ) ) {
		return false;
	}
	$ed = wp_get_image_editor( $tmp );
	if ( is_wp_error( $ed ) ) {
		wp_delete_file( $tmp );
		return false;
	}
	$ed->resize( 720, 720, false );
	$ed->set_quality( 80 );
	$ok = ! is_wp_error( $ed->save( $cel, 'image/webp' ) );
	wp_delete_file( $tmp );
	return $ok;
}

/** Posty źródła z pamięci; przy pustej pamięci pierwsze pobranie od razu (raz na 5 min). */
function mus_posty_zrodla( $z ) {
	$dane = get_option( mus_opcja_postow( $z['id'] ), array() );
	if ( empty( $dane['posty'] ) && $z['rss'] && ! get_transient( 'mus_blokada_' . $z['id'] ) ) {
		set_transient( 'mus_blokada_' . $z['id'], 1, 5 * MINUTE_IN_SECONDS );
		mus_odswiez_zrodlo( $z );
		$dane = get_option( mus_opcja_postow( $z['id'] ), array() );
	}
	$posty = $dane['posty'] ?? array();
	foreach ( $posty as &$p ) {
		$p['zrodlo'] = $z['id'];
	}
	return array( 'czas' => (int) ( $dane['czas'] ?? 0 ), 'posty' => $posty );
}

/** Posty feedu: najnowsze ze wszystkich jego źródeł, po dacie. */
function mus_posty_feedu( $f ) {
	$posty = array();
	$czas  = 0;
	foreach ( $f['zrodla'] as $id ) {
		$z = mus_zrodlo( $id );
		if ( ! $z ) {
			continue;
		}
		$d     = mus_posty_zrodla( $z );
		$czas  = max( $czas, $d['czas'] );
		$posty = array_merge( $posty, $d['posty'] );
	}
	usort( $posty, function ( $a, $b ) {
		return $b['czas'] <=> $a['czas'];
	} );
	return array( 'czas' => $czas, 'posty' => array_slice( $posty, 0, (int) $f['liczba'] ) );
}
