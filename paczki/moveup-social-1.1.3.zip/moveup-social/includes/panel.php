<?php
/**
 * moveUP – Social: panel Ustawienia → Social – źródła (kanały RSS) i feedy (co i jak pokazać).
 * Karty z etykietami nad polami – na telefonie jedna kolumna, pola na całą szerokość.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_options_page( 'Social – posty z Facebooka i Instagrama', 'Social', 'manage_options', 'moveup-social', 'mus_panel' );
} );

add_action( 'admin_init', function () {
	register_setting( 'moveup_social', MUS_OPCJA, array(
		'type'              => 'array',
		'sanitize_callback' => 'mus_oczysc',
	) );
} );

// Po zapisie ustawień – pobranie postów (nowe źródło od razu ma posty).
add_action( 'update_option_' . MUS_OPCJA, function () {
	mus_odswiez_wszystko();
} );
add_action( 'add_option_' . MUS_OPCJA, function () {
	mus_odswiez_wszystko();
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'settings_page_moveup-social' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'moveup-social-panel', MUS_URL . 'assets/panel.css', array(), MUS_VER );
	wp_enqueue_script( 'moveup-social-panel', MUS_URL . 'assets/panel.js', array(), MUS_VER, true );
} );

/** Pole formularza: etykieta nad polem, opis pod nim. */
function mus_pole( $nazwa, $etykieta, $wartosc, $typ = 'text', $opis = '', $atrybuty = '' ) {
	$id = 'mus-' . trim( preg_replace( '/[^a-z0-9_]+/i', '-', $nazwa ), '-' );
	printf(
		'<p class="mus-p"><label for="%1$s">%2$s</label><input id="%1$s" type="%3$s" name="%4$s" value="%5$s" %6$s>%7$s</p>',
		esc_attr( $id ),
		esc_html( $etykieta ),
		esc_attr( $typ ),
		esc_attr( $nazwa ),
		esc_attr( $wartosc ),
		$atrybuty, // phpcs:ignore WordPress.Security.EscapeOutput
		$opis ? '<span class="description">' . esc_html( $opis ) . '</span>' : ''
	);
}

function mus_wybor( $nazwa, $etykieta, $wartosc, $opcje, $opis = '' ) {
	$id = 'mus-' . trim( preg_replace( '/[^a-z0-9_]+/i', '-', $nazwa ), '-' );
	echo '<p class="mus-p"><label for="' . esc_attr( $id ) . '">' . esc_html( $etykieta ) . '</label><select id="' . esc_attr( $id ) . '" name="' . esc_attr( $nazwa ) . '">';
	foreach ( $opcje as $k => $v ) {
		echo '<option value="' . esc_attr( $k ) . '"' . selected( (string) $wartosc, (string) $k, false ) . '>' . esc_html( $v ) . '</option>';
	}
	echo '</select>' . ( $opis ? '<span class="description">' . esc_html( $opis ) . '</span>' : '' ) . '</p>';
}

function mus_tak( $nazwa, $etykieta, $wartosc ) {
	echo '<p class="mus-p mus-p--tak"><input type="hidden" name="' . esc_attr( $nazwa ) . '" value="0"><label><input type="checkbox" name="' . esc_attr( $nazwa ) . '" value="1"' . checked( (int) $wartosc, 1, false ) . '> ' . esc_html( $etykieta ) . '</label></p>';
}

function mus_karta_zrodla( $i, $z ) {
	$n = MUS_OPCJA . '[zrodla][' . $i . ']';
	?>
	<fieldset class="mus-karta" data-mus-karta>
		<legend><?php echo esc_html( $z['nazwa'] ?: 'Nowe źródło' ); ?></legend>
		<input type="hidden" name="<?php echo esc_attr( $n ); ?>[id]" value="<?php echo esc_attr( $z['id'] ); ?>">
		<div class="mus-siatka">
			<?php
			mus_wybor( $n . '[serwis]', 'Serwis', $z['serwis'], array( 'facebook' => 'Facebook', 'instagram' => 'Instagram' ) );
			mus_pole( $n . '[nazwa]', 'Nazwa profilu', $z['nazwa'], 'text', 'Pokazywana przy profilu i postach, np. @pani_od_narkotykow.' );
			mus_pole( $n . '[rss]', 'Adres kanału RSS', $z['rss'], 'url', 'Kanał z ostatnimi postami (np. z n8n). Odświeżany co godzinę.' );
			mus_pole( $n . '[profil]', 'Adres profilu', $z['profil'], 'url' );
			mus_pole( $n . '[przycisk]', 'Tekst przycisku', $z['przycisk'], 'text', 'Np. „Obserwuj na Instagramie”. Puste – bez przycisku.' );
			?>
			<p class="mus-p mus-p--media">
				<label for="mus-aw-<?php echo esc_attr( $i ); ?>">Zdjęcie profilu</label>
				<span class="mus-media">
					<input id="mus-aw-<?php echo esc_attr( $i ); ?>" type="url" name="<?php echo esc_attr( $n ); ?>[awatar]" value="<?php echo esc_attr( $z['awatar'] ); ?>">
					<button type="button" class="button" data-mus-media>Wybierz z mediów</button>
				</span>
				<span class="description">Kwadrat, min. 100 px.</span>
			</p>
		</div>
		<?php
		if ( $z['id'] ) {
			$d = get_option( mus_opcja_postow( $z['id'] ), array() );
			printf(
				'<p class="mus-stan">Ostatnie pobranie: <strong>%s</strong>, postów: <strong>%d</strong>.</p>',
				! empty( $d['czas'] ) ? esc_html( wp_date( 'j F Y, H:i', $d['czas'] ) ) : 'jeszcze nie',
				! empty( $d['posty'] ) ? count( $d['posty'] ) : 0
			);
		}
		?>
		<p class="mus-usun"><button type="button" class="button-link button-link-delete" data-mus-usun>Usuń źródło</button></p>
	</fieldset>
	<?php
}

function mus_karta_feedu( $i, $f, $zrodla ) {
	$n = MUS_OPCJA . '[feedy][' . $i . ']';
	?>
	<fieldset class="mus-karta" data-mus-karta>
		<legend><?php echo esc_html( $f['nazwa'] ?: 'Nowy feed' ); ?></legend>
		<input type="hidden" name="<?php echo esc_attr( $n ); ?>[id]" value="<?php echo esc_attr( $f['id'] ); ?>">
		<?php if ( $f['id'] ) : ?>
			<p class="mus-kod">Wstaw na stronie (blok „Shortcode”): <code>[moveup_social feed="<?php echo esc_html( $f['id'] ); ?>"]</code></p>
		<?php endif; ?>
		<div class="mus-siatka">
			<?php mus_pole( $n . '[nazwa]', 'Nazwa feedu (dla Ciebie)', $f['nazwa'], 'text', 'Np. „Instagram na głównej”.' ); ?>
			<fieldset class="mus-p mus-zrodla">
				<legend>Źródła w tym feedzie</legend>
				<?php if ( ! $zrodla ) : ?>
					<span class="description">Najpierw dodaj i zapisz źródło.</span>
				<?php endif; ?>
				<?php foreach ( $zrodla as $z ) : ?>
					<label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[zrodla][]" value="<?php echo esc_attr( $z['id'] ); ?>"<?php checked( in_array( $z['id'], $f['zrodla'], true ) ); ?>> <?php echo esc_html( ( $z['nazwa'] ?: $z['id'] ) . ' (' . mus_serwisy()[ $z['serwis'] ]['nazwa'] . ')' ); ?></label>
				<?php endforeach; ?>
				<span class="description">Kilka źródeł – posty wszystkich razem, od najnowszego.</span>
			</fieldset>
		</div>

		<h3>Układ</h3>
		<div class="mus-siatka">
			<?php
			mus_wybor( $n . '[uklad]', 'Układ', $f['uklad'], array( 'siatka' => 'Siatka', 'karuzela' => 'Karuzela (strzałki)', 'lista' => 'Lista (jeden pod drugim)' ) );
			mus_wybor( $n . '[telefon]', 'Siatka na telefonie i tablecie', $f['telefon'], array( 'siatka' => 'Siatka', 'pasek' => 'Pasek przewijany palcem' ) );
			mus_pole( $n . '[liczba]', 'Liczba postów', $f['liczba'], 'number', 'Od 1 do 30 – razem z tymi pod „Wczytaj więcej”.', 'min="1" max="30"' );
			mus_pole( $n . '[wiersze]', 'Rzędy na start (siatka)', $f['wiersze'], 'number', '0 – wszystkie od razu. Więcej rzędów – przycisk „Wczytaj więcej postów”.', 'min="0" max="10"' );
			mus_pole( $n . '[kol_d]', 'Kolumny – komputer', $f['kol_d'], 'number', '', 'min="1" max="6"' );
			mus_pole( $n . '[kol_t]', 'Kolumny – tablet', $f['kol_t'], 'number', '', 'min="1" max="4"' );
			mus_pole( $n . '[kol_m]', 'Kolumny – telefon', $f['kol_m'], 'number', '', 'min="1" max="3"' );
			mus_pole( $n . '[autoplay]', 'Karuzela: przewijanie co (s)', $f['autoplay'], 'number', '0 – bez automatycznego przewijania.', 'min="0" max="30"' );
			?>
		</div>

		<h3>Zdjęcia i szczegóły posta</h3>
		<div class="mus-siatka">
			<?php
			mus_wybor( $n . '[proporcje]', 'Proporcje zdjęć', $f['proporcje'], array( '1/1' => 'Kwadrat 1:1', '4/5' => 'Pion 4:5', '3/4' => 'Pion 3:4 (jak siatka Instagrama)', '4/3' => 'Poziom 4:3', '16/9' => 'Poziom 16:9' ) );
			mus_wybor( $n . '[szczegoly]', 'Szczegóły posta', $f['szczegoly'], array( 'pod' => 'Pod zdjęciem', 'obok' => 'Obok zdjęcia', 'nakladka' => 'Na zdjęciu po najechaniu', 'brak' => 'Bez szczegółów – same zdjęcia' ) );
			mus_wybor( $n . '[tekst]', 'Tekst posta', $f['tekst'], array( 'skrot' => 'Skrócony (z „Czytaj więcej”)', 'caly' => 'Cały', 'brak' => 'Bez tekstu' ) );
			mus_pole( $n . '[linie]', 'Skrót: liczba linii', $f['linie'], 'number', '', 'min="1" max="12"' );
			?>
			<div class="mus-p mus-p--grupa">
				<span class="mus-etykieta">Pokaż</span>
				<?php
				mus_tak( $n . '[data]', 'Datę', $f['data'] );
				mus_tak( $n . '[godzina]', 'Godzinę', $f['godzina'] );
				mus_tak( $n . '[zrodlo]', 'Nazwę profilu przy poście', $f['zrodlo'] );
				mus_tak( $n . '[link]', 'Link „Zobacz post na …” (pod i obok zdjęcia)', $f['link'] );
				?>
			</div>
		</div>

		<h3>Nagłówek, profile i przyciski</h3>
		<div class="mus-siatka">
			<?php
			mus_pole( $n . '[tytul]', 'Nagłówek sekcji (H2)', $f['tytul'], 'text', 'Puste – bez nagłówka (np. gdy jest już w treści strony).' );
			mus_pole( $n . '[podtytul]', 'Podtytuł', $f['podtytul'] );
			mus_wybor( $n . '[profile]', 'Profile nad postami', $f['profile'], array( 'brak' => 'Nie', 'gora' => 'Tak – zdjęcie i nazwa profilu' ) );
			mus_wybor( $n . '[przyciski]', 'Przyciski „Obserwuj”', $f['przyciski'], array( 'dol' => 'Pod postami', 'gora' => 'Nad postami', 'brak' => 'Bez przycisków' ), 'Przy profilach nad postami przycisk stoi obok profilu, a na telefonie – pod postami.' );
			?>
		</div>

		<h3>Wygląd</h3>
		<div class="mus-siatka">
			<?php
			mus_pole( $n . '[kolor]', 'Kolor akcentu (nazwy, linki, data)', $f['kolor'], 'text', 'Np. #530e4f. Puste – kolor tekstu strony.', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[p_tlo]', 'Przycisk – tło', $f['p_tlo'], 'text', 'Puste – przyciski jak na stronie.', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[p_tekst]', 'Przycisk – tekst', $f['p_tekst'], 'text', '', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[p_hover]', 'Przycisk – tło po najechaniu', $f['p_hover'], 'text', '', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[p_czcionka]', 'Przycisk – krój pisma', $f['p_czcionka'], 'text', 'Np. Ubuntu. Puste – jak na stronie.' );
			mus_pole( $n . '[karta]', 'Tło karty (pod / obok)', $f['karta'], 'text', 'Puste – bez tła.', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[zaokr]', 'Zaokrąglenie (px)', $f['zaokr'], 'number', '', 'min="0" max="40"' );
			mus_pole( $n . '[odstep]', 'Odstęp między postami (px) – komputer', $f['odstep'], 'number', '', 'min="0" max="80"' );
			mus_pole( $n . '[odstep_m]', 'Odstęp między postami (px) – telefon', $f['odstep_m'], 'number', '', 'min="0" max="80"' );
			mus_pole( $n . '[margines]', 'Odstęp wokół feedu (px) – komputer', $f['margines'], 'number', '', 'min="0" max="80"' );
			mus_pole( $n . '[margines_m]', 'Odstęp wokół feedu (px) – telefon', $f['margines_m'], 'number', '', 'min="0" max="40"' );
			?>
		</div>

		<h3>Odstępy pionowe i tekst</h3>
		<div class="mus-siatka">
			<?php
			mus_pole( $n . '[od_zdjecie]', 'Zdjęcie → data (px)', $f['od_zdjecie'], 'number', 'Odstęp pod zdjęciem.', 'min="0" max="80"' );
			mus_pole( $n . '[od_data]', 'Data → tekst (px)', $f['od_data'], 'number', 'Też między nazwą profilu a datą.', 'min="0" max="60"' );
			mus_pole( $n . '[od_wiecej]', 'Tekst → „Czytaj więcej” (px)', $f['od_wiecej'], 'number', 'Też przed „Zobacz post”.', 'min="0" max="60"' );
			mus_pole( $n . '[od_pod]', 'Odstęp pod feedem (px) – komputer', $f['od_pod'], 'number', 'Do następnej sekcji strony.', 'min="0" max="200"' );
			mus_pole( $n . '[od_pod_m]', 'Odstęp pod feedem (px) – telefon', $f['od_pod_m'], 'number', '', 'min="0" max="200"' );
			mus_pole( $n . '[tekst_px]', 'Rozmiar tekstu i daty (px) – komputer', $f['tekst_px'], 'number', 'Można z przecinkiem, np. 14,4.', 'min="10" max="24" step="0.1"' );
			mus_pole( $n . '[tekst_px_m]', 'Rozmiar tekstu i daty (px) – telefon', $f['tekst_px_m'], 'number', '', 'min="10" max="24" step="0.1"' );
			mus_pole( $n . '[linia_px]', 'Wysokość linii tekstu (px)', $f['linia_px'], 'number', '', 'min="12" max="40" step="0.1"' );
			mus_tak( $n . '[skrot_ciagly]', 'Skrót tekstu jako ciągły akapit (puste linie dopiero po „Czytaj więcej”)', $f['skrot_ciagly'] );
			mus_wybor( $n . '[wiecej]', '„Czytaj więcej” wygląda jak', $f['wiecej'], array( 'link' => 'Link tekstowy (ustawienia niżej)', 'przycisk' => 'Przycisk (kolory i wymiary przycisków)' ) );
			mus_pole( $n . '[linia_px_m]', 'Wysokość linii tekstu (px) – telefon', $f['linia_px_m'] ?: '', 'number', 'Puste – jak na komputerze.', 'min="12" max="40" step="0.1"' );
			mus_pole( $n . '[od_nazwa]', 'Nazwa profilu → data (px)', ( (int) $f['od_nazwa'] >= 0 ) ? $f['od_nazwa'] : '', 'number', 'Puste – jak „Data → tekst”.', 'min="0" max="60"' );
			mus_pole( $n . '[kiedy_kolor]', 'Kolor daty', $f['kiedy_kolor'], 'text', 'Puste – kolor akcentu, lekko przygaszony.', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			?>
		</div>

		<h3>Nazwa profilu przy poście</h3>
		<div class="mus-siatka">
			<?php
			mus_tak( $n . '[z_link]', 'Nazwa jako link do profilu (nowa karta)', $f['z_link'] );
			mus_tak( $n . '[z_ikona]', 'Ikona serwisu (Facebook / Instagram) przed nazwą', $f['z_ikona'] );
			mus_pole( $n . '[z_kolor]', 'Kolor nazwy', $f['z_kolor'], 'text', 'Puste – kolor akcentu.', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[z_rozmiar]', 'Rozmiar nazwy (px) – komputer', $f['z_rozmiar'] ?: '', 'number', 'Puste – jak tekst posta.', 'min="10" max="32" step="0.1"' );
			mus_pole( $n . '[z_rozmiar_m]', 'Rozmiar nazwy (px) – telefon', $f['z_rozmiar_m'] ?: '', 'number', 'Puste – jak tekst posta.', 'min="10" max="32" step="0.1"' );
			mus_pole( $n . '[z_linia]', 'Wysokość linii nazwy (px)', $f['z_linia'] ?: '', 'number', 'Puste – jak tekst posta.', 'min="12" max="48" step="0.1"' );
			mus_wybor( $n . '[z_grubosc]', 'Grubość nazwy', (string) $f['z_grubosc'], array( '400' => 'Normalna (400)', '500' => 'Średnia (500)', '600' => 'Półgruba (600)', '700' => 'Gruba (700)' ) );
			mus_wybor( $n . '[z_podkresl]', 'Podkreślenie nazwy (link)', $f['z_podkresl'], array( 'brak' => 'Nigdy', 'najechanie' => 'Po najechaniu', 'zawsze' => 'Zawsze' ) );
			?>
		</div>

		<h3>„Czytaj więcej” jako link</h3>
		<div class="mus-siatka">
			<?php
			mus_pole( $n . '[w_kolor]', 'Kolor linku', $f['w_kolor'], 'text', 'Puste – kolor akcentu feedu.', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[w_hover]', 'Kolor linku po najechaniu', $f['w_hover'], 'text', 'Puste – bez zmiany koloru.', 'placeholder="#rrggbb" pattern="#[0-9a-fA-F]{3,8}"' );
			mus_pole( $n . '[w_czcionka]', 'Krój pisma linku', $f['w_czcionka'], 'text', 'Np. Poppins. Puste – jak tekst postu.' );
			mus_wybor( $n . '[w_grubosc]', 'Grubość', (string) $f['w_grubosc'], array( '400' => 'Normalna (400)', '500' => 'Średnia (500)', '600' => 'Półgruba (600)', '700' => 'Gruba (700)' ) );
			mus_pole( $n . '[w_rozmiar]', 'Rozmiar linku (px) – komputer', $f['w_rozmiar'], 'number', '', 'min="10" max="24" step="0.1"' );
			mus_pole( $n . '[w_rozmiar_m]', 'Rozmiar linku (px) – telefon', $f['w_rozmiar_m'], 'number', '', 'min="10" max="24" step="0.1"' );
			mus_wybor( $n . '[w_podkresl]', 'Podkreślenie', $f['w_podkresl'], array( 'zawsze' => 'Zawsze', 'najechanie' => 'Po najechaniu', 'brak' => 'Bez podkreślenia' ) );
			?>
		</div>

		<h3>Wymiary przycisków</h3>
		<div class="mus-siatka">
			<?php
			mus_pole( $n . '[p_rozmiar]', 'Rozmiar tekstu przycisku (px)', $f['p_rozmiar'], 'number', '', 'min="10" max="24" step="0.1"' );
			mus_pole( $n . '[p_zaokr]', 'Zaokrąglenie przycisku (px)', $f['p_zaokr'], 'number', '', 'min="0" max="60"' );
			mus_pole( $n . '[p_pion]', 'Wypełnienie góra/dół (px) – komputer', $f['p_pion'], 'number', '', 'min="0" max="30"' );
			mus_pole( $n . '[p_poziom]', 'Wypełnienie lewo/prawo (px) – komputer', $f['p_poziom'], 'number', '', 'min="0" max="60"' );
			mus_pole( $n . '[p_pion_m]', 'Wypełnienie góra/dół (px) – telefon', $f['p_pion_m'], 'number', '', 'min="0" max="30"' );
			mus_pole( $n . '[p_poziom_m]', 'Wypełnienie lewo/prawo (px) – telefon', $f['p_poziom_m'], 'number', '', 'min="0" max="60"' );
			?>
		</div>
		<p class="mus-usun"><button type="button" class="button-link button-link-delete" data-mus-usun>Usuń feed</button></p>
	</fieldset>
	<?php
}

function mus_panel() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( isset( $_POST['mus_odswiez'] ) && check_admin_referer( 'mus_odswiez', 'mus_nonce' ) ) {
		$bledy = array();
		foreach ( mus_odswiez_wszystko() as $id => $w ) {
			if ( is_wp_error( $w ) ) {
				$bledy[] = $id . ': ' . $w->get_error_message();
			}
		}
		echo '<div class="notice notice-' . ( $bledy ? 'error' : 'success' ) . '"><p>' . esc_html( $bledy ? 'Błąd – ' . implode( '; ', $bledy ) : 'Posty pobrane.' ) . '</p></div>';
	}
	$o = mus_opcje();
	?>
	<div class="wrap mus-panel">
		<h1>Social – posty z Facebooka i Instagrama</h1>
		<p>Źródło to kanał RSS jednego profilu. Feed to zestaw źródeł i sposób ich pokazania – wstawiasz go na stronie blokiem „Shortcode”. Zdjęcia zapisują się na serwerze strony.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'moveup_social' ); ?>
			<h2>Źródła</h2>
			<div class="mus-karty" data-mus-lista="zrodla">
				<?php
				foreach ( $o['zrodla'] as $i => $z ) {
					mus_karta_zrodla( $i, $z );
				}
				?>
			</div>
			<p><button type="button" class="button" data-mus-dodaj="zrodla">Dodaj źródło</button></p>
			<template id="mus-wzor-zrodla"><?php mus_karta_zrodla( '__i__', mus_zrodlo_domyslne() ); ?></template>

			<h2>Feedy</h2>
			<div class="mus-karty" data-mus-lista="feedy">
				<?php
				foreach ( $o['feedy'] as $i => $f ) {
					mus_karta_feedu( $i, $f, $o['zrodla'] );
				}
				?>
			</div>
			<p><button type="button" class="button" data-mus-dodaj="feedy">Dodaj feed</button></p>
			<template id="mus-wzor-feedy"><?php mus_karta_feedu( '__i__', mus_feed_domyslny(), $o['zrodla'] ); ?></template>
			<?php submit_button( 'Zapisz ustawienia' ); ?>
		</form>
		<form method="post" class="mus-odswiez">
			<?php wp_nonce_field( 'mus_odswiez', 'mus_nonce' ); ?>
			<p>Posty odświeżają się same co godzinę.</p>
			<?php submit_button( 'Pobierz posty teraz', 'secondary', 'mus_odswiez', false ); ?>
		</form>
	</div>
	<?php
}
