<?php
/**
 * moveUP – Social: wyświetlanie feedu (shortcode [moveup_social feed="…"]) i dociąganie świeżych postów przez REST.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	wp_register_style( 'moveup-social', MUS_URL . 'assets/social.css', array(), MUS_VER );
	wp_register_script( 'moveup-social', MUS_URL . 'assets/social.js', array(), MUS_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	add_shortcode( 'moveup_social', 'mus_shortcode' );
} );

function mus_shortcode( $atts = array() ) {
	$a = shortcode_atts( array( 'feed' => '' ), (array) $atts, 'moveup_social' );
	$f = mus_feed( sanitize_key( $a['feed'] ) );
	return $f ? mus_feed_html( $f ) : '';
}

/** Zmienne CSS feedu w atrybucie style (bez <style> w treści strony – W3C). */
function mus_zmienne( $f ) {
	$z = array(
		'--mus-kol-d'      => (int) $f['kol_d'],
		'--mus-kol-t'      => (int) $f['kol_t'],
		'--mus-kol-m'      => (int) $f['kol_m'],
		'--mus-prop'       => $f['proporcje'],
		'--mus-odstep'     => (int) $f['odstep'] . 'px',
		'--mus-odstep-m'   => (int) $f['odstep_m'] . 'px',
		'--mus-margines'   => (int) $f['margines'] . 'px',
		'--mus-margines-m' => (int) $f['margines_m'] . 'px',
		'--mus-zaokr'      => (int) $f['zaokr'] . 'px',
		'--mus-linie'      => (int) $f['linie'],
		'--mus-od-zdjecie' => (int) $f['od_zdjecie'] . 'px',
		'--mus-od-data'    => (int) $f['od_data'] . 'px',
		'--mus-od-wiecej'  => (int) $f['od_wiecej'] . 'px',
		'--mus-od-pod'     => (int) $f['od_pod'] . 'px',
		'--mus-od-pod-m'   => (int) $f['od_pod_m'] . 'px',
		'--mus-tekst'      => (float) $f['tekst_px'] . 'px',
		'--mus-tekst-m'    => (float) $f['tekst_px_m'] . 'px',
		'--mus-linia'      => (float) $f['linia_px'] . 'px',
		'--mus-p-rozmiar'  => (float) $f['p_rozmiar'] . 'px',
		'--mus-p-pion'     => (int) $f['p_pion'] . 'px',
		'--mus-p-poziom'   => (int) $f['p_poziom'] . 'px',
		'--mus-p-pion-m'   => (int) $f['p_pion_m'] . 'px',
		'--mus-p-poziom-m' => (int) $f['p_poziom_m'] . 'px',
		'--mus-p-zaokr'    => (int) $f['p_zaokr'] . 'px',
		'--mus-w-rozmiar'  => (float) $f['w_rozmiar'] . 'px',
		'--mus-w-rozmiar-m' => (float) $f['w_rozmiar_m'] . 'px',
		'--mus-w-grubosc'  => (int) $f['w_grubosc'],
		'--mus-w-dek'      => 'zawsze' === $f['w_podkresl'] ? 'underline' : 'none',
		'--mus-w-dek-hover' => 'brak' === $f['w_podkresl'] ? 'none' : 'underline',
		'--mus-z-grubosc'  => (int) $f['z_grubosc'],
		'--mus-z-dek'      => 'zawsze' === $f['z_podkresl'] ? 'underline' : 'none',
		'--mus-z-dek-hover' => 'brak' === $f['z_podkresl'] ? 'none' : 'underline',
	);
	// od 1.1.3 – opcjonalne (bez wartości zostaje wygląd jak w 1.1.2)
	foreach ( array( 'z_rozmiar' => '--mus-z-rozmiar', 'z_rozmiar_m' => '--mus-z-rozmiar-m', 'z_linia' => '--mus-z-linia', 'linia_px_m' => '--mus-linia-m' ) as $k => $zm ) {
		if ( (float) $f[ $k ] ) {
			$z[ $zm ] = (float) $f[ $k ] . 'px';
		}
	}
	if ( (int) $f['od_nazwa'] >= 0 ) {
		$z['--mus-od-nazwa'] = (int) $f['od_nazwa'] . 'px';
	}
	foreach ( array( 'z_kolor' => '--mus-z-kolor', 'kiedy_kolor' => '--mus-kiedy-kolor' ) as $k => $zm ) {
		if ( $f[ $k ] ) {
			$z[ $zm ] = $f[ $k ];
		}
	}
	if ( $f['kiedy_kolor'] ) {
		$z['--mus-kiedy-op'] = 1; // własny kolor daty – bez przygaszenia
	}
	foreach ( array( 'w_kolor' => '--mus-w-kolor', 'w_hover' => '--mus-w-hover', 'w_czcionka' => '--mus-w-czcionka', 'kolor' => '--mus-kolor', 'p_tlo' => '--mus-p-tlo', 'p_tekst' => '--mus-p-tekst', 'p_hover' => '--mus-p-hover', 'karta' => '--mus-karta' ) as $k => $zm ) {
		if ( $f[ $k ] ) {
			$z[ $zm ] = $f[ $k ];
		}
	}
	if ( $f['p_czcionka'] ) {
		$z['--mus-p-czcionka'] = $f['p_czcionka'];
	}
	$css = '';
	foreach ( $z as $k => $v ) {
		$css .= $k . ':' . $v . ';';
	}
	return $css;
}

function mus_feed_html( $f ) {
	$dane = mus_posty_feedu( $f );
	if ( ! $dane['posty'] ) {
		return '';
	}
	$serwisy = mus_serwisy();
	$zrodla  = array_values( array_filter( array_map( 'mus_zrodlo', $f['zrodla'] ) ) );
	$siatka  = 'siatka' === $f['uklad'];
	$wlasne  = $f['p_tlo'] || $f['p_tekst'] || $f['p_hover'] || $f['p_czcionka'];
	$id      = wp_unique_id( 'mus-' );
	$api     = add_query_arg( 'feed', $f['id'], rest_url( 'moveup-social/v1/feed' ) );
	$klasy   = array( 'mus', 'mus--' . $f['uklad'], 'mus--' . $f['szczegoly'] );
	if ( $siatka && 'pasek' === $f['telefon'] ) {
		$klasy[] = 'mus--pasek';
	}
	if ( 'gora' === $f['profile'] ) {
		$klasy[] = 'mus--z-profilem';
	}
	if ( $f['karta'] ) {
		$klasy[] = 'mus--karta';
	}

	// Przyciski „Obserwuj”: przy profilach na górze – obok profilu (na telefonie pod postami); inaczej wg ustawienia.
	$przyciski = function ( $miejsce ) use ( $zrodla, $serwisy, $wlasne, $f ) {
		$html = '';
		foreach ( $zrodla as $z ) {
			if ( ! $z['profil'] || ! $z['przycisk'] ) {
				continue;
			}
			$html .= sprintf(
				'<a class="button mus__przycisk%s" href="%s" target="_blank" rel="noopener">%s<span class="screen-reader-text"> (%s, otwiera się w nowej karcie)</span></a>',
				$wlasne ? ' mus__przycisk--wlasny' : '',
				esc_url( $z['profil'] ),
				esc_html( $z['przycisk'] ),
				esc_html( $serwisy[ $z['serwis'] ]['nazwa'] )
			);
		}
		return $html ? '<div class="mus__przyciski mus__przyciski--' . esc_attr( $miejsce ) . '">' . $html . '</div>' : '';
	};

	wp_enqueue_style( 'moveup-social' );
	wp_enqueue_script( 'moveup-social' );
	$etykieta = $f['tytul'] ? ' aria-labelledby="' . esc_attr( $id ) . '-tytul"' : ' aria-label="' . esc_attr( 'Ostatnie posty ' . implode( ', ', array_unique( array_map( function ( $z ) use ( $serwisy ) { return $serwisy[ $z['serwis'] ]['z']; }, $zrodla ) ) ) ) . '"';
	ob_start();
	?>
	<section class="<?php echo esc_attr( implode( ' ', $klasy ) ); ?>" style="<?php echo esc_attr( mus_zmienne( $f ) ); ?>"<?php echo $etykieta; // phpcs:ignore WordPress.Security.EscapeOutput ?> data-wiersze="<?php echo $siatka ? (int) $f['wiersze'] : 0; ?>" data-czas="<?php echo (int) $dane['czas']; ?>" data-api="<?php echo esc_url( $api ); ?>"<?php echo 'karuzela' === $f['uklad'] ? ' data-autoplay="' . (int) $f['autoplay'] * 1000 . '"' : ''; ?>>
		<?php if ( $f['tytul'] ) : ?>
			<h2 id="<?php echo esc_attr( $id ); ?>-tytul" class="mus__tytul"><?php echo esc_html( $f['tytul'] ); ?></h2>
		<?php endif; ?>
		<?php if ( $f['podtytul'] ) : ?>
			<p class="mus__podtytul"><?php echo esc_html( $f['podtytul'] ); ?></p>
		<?php endif; ?>
		<?php if ( 'gora' === $f['profile'] || 'gora' === $f['przyciski'] ) : ?>
			<div class="mus__glowa">
				<?php if ( 'gora' === $f['profile'] ) : ?>
					<div class="mus__profile">
						<?php foreach ( $zrodla as $z ) : ?>
							<?php if ( $z['nazwa'] ) : ?>
								<?php echo $z['profil'] ? '<a class="mus__konto" href="' . esc_url( $z['profil'] ) . '" target="_blank" rel="noopener">' : '<span class="mus__konto">'; // phpcs:ignore WordPress.Security.EscapeOutput ?>
									<?php if ( $z['awatar'] ) : ?>
										<img class="mus__awatar" src="<?php echo esc_url( $z['awatar'] ); ?>" alt="" width="50" height="50" loading="lazy" decoding="async">
									<?php endif; ?>
									<span class="mus__nazwa"><?php echo esc_html( $z['nazwa'] ); ?></span><?php if ( $z['profil'] ) : ?><span class="screen-reader-text"> (<?php echo esc_html( $serwisy[ $z['serwis'] ]['nazwa'] ); ?>, otwiera się w nowej karcie)</span><?php endif; ?>
								<?php echo $z['profil'] ? '</a>' : '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
				<?php echo 'brak' !== $f['przyciski'] && ( 'gora' === $f['przyciski'] || 'gora' === $f['profile'] ) ? $przyciski( 'gora' ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		<?php endif; ?>
		<?php if ( 'karuzela' === $f['uklad'] ) : ?>
			<div class="mus__karuzela">
				<button type="button" class="mus__strzalka mus__strzalka--prev" aria-label="Poprzednie posty"></button>
		<?php endif; ?>
		<ul class="mus__lista" role="list"<?php echo 'karuzela' === $f['uklad'] ? ' tabindex="0"' : ''; ?>>
			<?php echo mus_posty_html( $f, $dane['posty'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</ul>
		<?php if ( 'karuzela' === $f['uklad'] ) : ?>
				<button type="button" class="mus__strzalka mus__strzalka--next" aria-label="Następne posty"></button>
			</div>
		<?php endif; ?>
		<?php
		$dol = '';
		if ( 'brak' !== $f['przyciski'] && ( 'dol' === $f['przyciski'] || 'gora' === $f['profile'] ) ) {
			$dol = $przyciski( 'gora' === $f['profile'] && 'dol' !== $f['przyciski'] ? 'telefon' : 'dol' );
		}
		if ( ( $siatka && $f['wiersze'] ) || $dol ) :
			?>
			<div class="mus__stopka">
				<?php if ( $siatka && $f['wiersze'] ) : ?>
					<button type="button" class="button mus__przycisk mus__wiecej<?php echo $wlasne ? ' mus__przycisk--wlasny' : ''; ?>" hidden>Wczytaj więcej postów</button>
				<?php endif; ?>
				<?php echo $dol; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		<?php endif; ?>
	</section>
	<?php
	return ob_get_clean();
}

/** Data i godzina posta wg ustawień feedu. */
function mus_kiedy( $f, $czas ) {
	$czesci = array();
	if ( $f['data'] ) {
		$czesci[] = wp_date( 'j F Y', $czas );
	}
	if ( $f['godzina'] ) {
		$czesci[] = wp_date( 'H:i', $czas );
	}
	return implode( ', ', $czesci );
}

/** Ikona serwisu przy nazwie profilu (od 1.1.3) – kolor z tekstu (currentColor). */
function mus_ikona_serwisu( $serwis ) {
	if ( 'instagram' === $serwis ) {
		return '<svg class="mus__z-ikona" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7zm5 3.5a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9zm0 2a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM17.3 5.6a1.1 1.1 0 1 1 0 2.2 1.1 1.1 0 0 1 0-2.2z"/></svg>';
	}
	return '<svg class="mus__z-ikona" viewBox="0 0 448 512" aria-hidden="true" focusable="false"><path fill="currentColor" d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z"/></svg>';
}

function mus_posty_html( $f, $posty ) {
	$serwisy = mus_serwisy();
	$siatka  = 'siatka' === $f['uklad'];
	$w       = (int) $f['wiersze'];
	ob_start();
	foreach ( $posty as $i => $p ) {
		$z      = mus_zrodlo( $p['zrodlo'] );
		$s      = $serwisy[ $z['serwis'] ?? 'facebook' ];
		$tekst  = trim( html_entity_decode( (string) $p['tekst'], ENT_QUOTES, 'UTF-8' ) );
		$jedna  = preg_replace( '/\s+/u', ' ', $tekst );
		$krotki = mb_strlen( $jedna ) > 90 ? rtrim( mb_substr( $jedna, 0, 90 ) ) . '…' : $jedna;
		$kiedy  = mus_kiedy( $f, (int) $p['czas'] );
		$tid    = 'mus-' . md5( $f['id'] . $p['id'] );
		$klasy  = array( 'mus__post' );
		if ( $siatka && $w ) { // poza pierwszymi rzędami – ukryte do „Wczytaj więcej” (zanim zadziała skrypt: osobno dla komputera, tabletu i telefonu)
			foreach ( array( 'd' => $f['kol_d'], 't' => $f['kol_t'], 'm' => $f['kol_m'] ) as $ek => $kol ) {
				if ( $i >= $w * (int) $kol ) {
					$klasy[] = 'mus-poza-' . $ek;
				}
			}
		}
		$opis_sr  = 'Post ' . $s['na'] . ( $f['zrodlo'] && $z ? ' (' . $z['nazwa'] . ')' : '' ) . ( $krotki ? ': ' . $krotki : '' ) . ' (otwiera się w nowej karcie)';
		$tresc_na = in_array( $f['szczegoly'], array( 'pod', 'obok' ), true );
		$zdj_fokus = ! ( $tresc_na && $f['link'] ); // przy „Zobacz post” zdjęcie nie jest drugim przystankiem klawiatury
		$wym       = ( ! empty( $p['w'] ) && ! empty( $p['h'] ) ) ? ' width="' . (int) $p['w'] . '" height="' . (int) $p['h'] . '"' : '';

		$elementy = '';
		if ( $f['zrodlo'] && $z && $z['nazwa'] ) {
			// od 1.1.3: ikona serwisu i link do profilu (opcje feedu); na nakładce zawsze sam tekst (cała nakładka jest w linku do posta)
			$ikona = $f['z_ikona'] ? mus_ikona_serwisu( $z['serwis'] ) : '';
			if ( $f['z_link'] && $z['profil'] && 'nakladka' !== $f['szczegoly'] ) {
				$elementy .= '<a class="mus__zrodlo mus__zrodlo--' . esc_attr( $z['serwis'] ) . ' mus__zrodlo--link" href="' . esc_url( $z['profil'] ) . '" target="_blank" rel="noopener">' . $ikona . '<span>' . esc_html( $z['nazwa'] ) . '</span><span class="screen-reader-text"> (' . esc_html( $s['nazwa'] ) . ', otwiera się w nowej karcie)</span></a>';
			} else {
				$elementy .= '<span class="mus__zrodlo mus__zrodlo--' . esc_attr( $z['serwis'] ) . '">' . $ikona . '<span>' . esc_html( $z['nazwa'] ) . '</span></span>';
			}
		}
		if ( $kiedy ) {
			$elementy .= '<time class="mus__kiedy" datetime="' . esc_attr( gmdate( 'c', (int) $p['czas'] ) ) . '">' . esc_html( $kiedy ) . '</time>';
		}
		?>
		<li class="<?php echo esc_attr( implode( ' ', $klasy ) ); ?>">
			<a class="mus__zdjecie" href="<?php echo esc_url( $p['link'] ); ?>" target="_blank" rel="noopener"<?php echo $zdj_fokus ? '' : ' tabindex="-1" aria-hidden="true"'; ?>>
				<img src="<?php echo esc_url( $p['zdj'] ); ?>" alt=""<?php echo $wym; // phpcs:ignore WordPress.Security.EscapeOutput ?> loading="lazy" decoding="async">
				<?php if ( 'nakladka' === $f['szczegoly'] ) : ?>
					<span class="mus__nakladka" aria-hidden="true">
						<?php echo $elementy; // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( 'brak' !== $f['tekst'] && $tekst ) : ?>
							<span class="mus__tekst<?php echo 'skrot' === $f['tekst'] ? ' mus__tekst--skrot' : ''; ?>"><?php echo esc_html( $tekst ); ?></span>
						<?php endif; ?>
						<span class="mus__ikona mus__ikona--<?php echo esc_attr( $z['serwis'] ?? 'facebook' ); ?>"></span>
					</span>
				<?php endif; ?>
				<?php if ( $zdj_fokus ) : ?>
					<span class="screen-reader-text"><?php echo esc_html( $opis_sr ); ?></span>
				<?php endif; ?>
			</a>
			<?php if ( $tresc_na && ( $elementy || ( 'brak' !== $f['tekst'] && $tekst ) || $f['link'] ) ) : ?>
				<div class="mus__tresc">
					<?php echo $elementy; // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php if ( 'brak' !== $f['tekst'] && $tekst ) : ?>
						<div class="mus__tekst<?php echo 'skrot' === $f['tekst'] ? ' mus__tekst--skrot' : ''; ?><?php echo ( 'skrot' === $f['tekst'] && $f['skrot_ciagly'] ) ? ' mus__tekst--ciagly' : ''; ?>" id="<?php echo esc_attr( $tid ); ?>"><?php echo nl2br( esc_html( $tekst ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
						<?php if ( 'skrot' === $f['tekst'] ) : ?>
							<button type="button" class="mus__rozwin<?php echo 'przycisk' === $f['wiecej'] ? ' mus__rozwin--przycisk' : ''; ?>" aria-expanded="false" aria-controls="<?php echo esc_attr( $tid ); ?>" hidden>Czytaj więcej</button>
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( $f['link'] ) : ?>
						<a class="mus__link" href="<?php echo esc_url( $p['link'] ); ?>" target="_blank" rel="noopener">Zobacz post <?php echo esc_html( $s['na'] ); ?><span class="screen-reader-text"> (otwiera się w nowej karcie)</span></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</li>
		<?php
	}
	return ob_get_clean();
}

/* Aktualne posty z pominięciem cache strony; przy okazji odświeża źródła, gdy dane są starsze niż godzina. */
add_action( 'rest_api_init', function () {
	register_rest_route( 'moveup-social/v1', '/feed', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'args'                => array( 'feed' => array( 'type' => 'string', 'default' => '' ) ),
		'callback'            => function ( WP_REST_Request $req ) {
			do_action( 'litespeed_control_set_nocache', 'moveup-social: aktualne posty' );
			nocache_headers();
			$f = mus_feed( sanitize_key( $req['feed'] ) );
			if ( ! $f ) {
				return new WP_Error( 'mus_feed', 'Nie ma takiego feedu.', array( 'status' => 404 ) );
			}
			$dane = mus_posty_feedu( $f );
			if ( time() - $dane['czas'] > HOUR_IN_SECONDS && ! get_transient( 'mus_blokada' ) ) {
				set_transient( 'mus_blokada', 1, 5 * MINUTE_IN_SECONDS );
				foreach ( $f['zrodla'] as $id ) {
					$z = mus_zrodlo( $id );
					if ( $z ) {
						mus_odswiez_zrodlo( $z );
					}
				}
				$dane = mus_posty_feedu( $f );
			}
			return array( 'czas' => $dane['czas'], 'html' => $dane['posty'] ? mus_posty_html( $f, $dane['posty'] ) : '' );
		},
	) );
} );
