<?php
/**
 * Plugin Name: moveUP – Social
 * Description: Ostatnie posty z Facebooka i Instagrama (kanały RSS) na stronie – kilka profili w jednym feedzie, do wyboru siatka, karuzela albo lista, zdjęcia w wybranych proporcjach, data, godzina, tekst i link pod zdjęciem, obok niego albo na zdjęciu po najechaniu. Zdjęcia zapisywane na serwerze strony – odwiedzający nie łączą się z Facebookiem ani Instagramem. Ustawienia → Social, w treści: [moveup_social feed="…"].
 * Version: 1.1.3
 * Author: moveUP Agency
 * Text Domain: moveup-social
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Update URI: https://github.com/jbalabuch/moveup-wtyczki
 * License: GPLv2 or later
 */

defined( 'ABSPATH' ) || exit;

// Aktualizacje z GitHuba (jbalabuch/moveup-wtyczki) – Kokpit → Aktualizacje, jak przy wtyczkach z wordpress.org.
require_once __DIR__ . '/includes/moveup-aktualizacje.php';
MoveUP_Aktualizacje::rejestruj( __FILE__, 'moveup-social' );

define( 'MUS_VER', '1.1.3' );
define( 'MUS_URL', plugin_dir_url( __FILE__ ) );
define( 'MUS_OPCJA', 'mu_social' );
define( 'MUS_CRON', 'mu_social_odswiez' );

/* -------------------------------------------------------------------------
 * Ustawienia: źródła (kanały RSS) i feedy (co i jak pokazać)
 * ---------------------------------------------------------------------- */

/** Serwisy – nazwy do tekstów linków i opisów dla czytników ekranu. */
function mus_serwisy() {
	return array(
		'facebook'  => array( 'nazwa' => 'Facebook', 'na' => 'na Facebooku', 'z' => 'z Facebooka' ),
		'instagram' => array( 'nazwa' => 'Instagram', 'na' => 'na Instagramie', 'z' => 'z Instagrama' ),
	);
}

function mus_zrodlo_domyslne() {
	return array(
		'id'       => '',
		'nazwa'    => '',          // np. @pani_od_narkotykow albo nazwa strony
		'serwis'   => 'facebook',
		'rss'      => '',
		'profil'   => '',          // adres profilu
		'awatar'   => '',          // zdjęcie profilu (biblioteka mediów)
		'przycisk' => '',          // np. „Obserwuj na Instagramie”; puste – bez przycisku
	);
}

function mus_feed_domyslny() {
	return array(
		'id'          => '',
		'nazwa'       => '',
		'zrodla'      => array(),
		'uklad'       => 'siatka',   // siatka | karuzela | lista
		'telefon'     => 'siatka',   // siatka | pasek (przewijany palcem) – układ siatki na telefonie i tablecie
		'proporcje'   => '1/1',      // 1/1 | 4/5 | 3/4 | 4/3 | 16/9
		'kol_d'       => 3,
		'kol_t'       => 2,
		'kol_m'       => 1,
		'liczba'      => 6,
		'wiersze'     => 0,          // 0 – wszystkie posty od razu; >0 – tyle rzędów, reszta pod „Wczytaj więcej postów”
		'szczegoly'   => 'pod',      // pod | obok | nakladka (na zdjęciu po najechaniu) | brak (same zdjęcia)
		'data'        => 1,
		'godzina'     => 0,
		'tekst'       => 'skrot',    // brak | skrot (kilka linii, „Czytaj więcej”) | caly
		'linie'       => 4,
		'zrodlo'      => 0,          // nazwa profilu przy poście (przydaje się, gdy feed ma kilka źródeł)
		'link'        => 1,          // „Zobacz post na …”
		'profile'     => 'brak',     // brak | gora – zdjęcie i nazwa profilu z przyciskiem nad postami
		'przyciski'   => 'dol',      // gora | dol | brak – gdzie przyciski „Obserwuj”; przy profile=gora na telefonie zawsze na dole
		'tytul'       => '',
		'podtytul'    => '',
		'kolor'       => '',         // akcent: nazwy, linki, data
		'p_tlo'       => '',         // przycisk: tło
		'p_tekst'     => '',         // przycisk: tekst
		'p_hover'     => '',         // przycisk: tło po najechaniu
		'p_czcionka'  => '',         // przycisk: krój (puste – jak na stronie)
		'karta'       => '',         // tło karty (pod/obok); puste – przezroczyste
		'zaokr'       => 0,          // zaokrąglenie zdjęć i kart (px)
		'odstep'      => 20,         // odstęp między postami (px), komputer
		'odstep_m'    => 12,         // telefon
		'margines'    => 0,          // odstęp wokół feedu (px), komputer
		'margines_m'  => 0,          // telefon
		'autoplay'    => 0,          // karuzela: sekundy, 0 – bez przewijania
		// od 1.1.0 – odstępy pionowe i tekst postów (zamiast dodatkowego CSS strony)
		'od_zdjecie'  => 12,         // zdjęcie → pierwszy element pod nim (px)
		'od_data'     => 8,          // między nazwą / datą / tekstem (px)
		'od_wiecej'   => 4,          // tekst → „Czytaj więcej” / „Zobacz post” (px)
		'od_pod'      => 0,          // odstęp pod feedem (px), komputer
		'od_pod_m'    => 0,          // telefon
		'tekst_px'    => 14,         // rozmiar tekstu i daty (px), komputer
		'tekst_px_m'  => 14,         // telefon
		'linia_px'    => 20,         // wysokość linii tekstu (px)
		'skrot_ciagly'=> 0,          // skrót jako ciągły akapit (bez pustych linii do rozwinięcia)
		'wiecej'      => 'link',     // link | przycisk – wygląd „Czytaj więcej”
		'w_kolor'     => '',         // link „Czytaj więcej”: kolor (puste – kolor akcentu feedu)
		'w_hover'     => '',         // kolor po najechaniu (puste – bez zmiany)
		'w_czcionka'  => '',         // krój (puste – jak tekst)
		'w_rozmiar'   => 14,         // px, komputer
		'w_rozmiar_m' => 14,         // px, telefon
		'w_grubosc'   => 600,        // 400 | 500 | 600 | 700
		'w_podkresl'  => 'najechanie', // zawsze | najechanie | brak
		'p_rozmiar'   => 14,         // przyciski: rozmiar tekstu (px)
		'p_pion'      => 11,         // przyciski: wypełnienie góra/dół (px), komputer
		'p_poziom'    => 15,         // przyciski: wypełnienie lewo/prawo (px), komputer
		'p_pion_m'    => 11,         // telefon
		'p_poziom_m'  => 15,
		'p_zaokr'     => 20,         // przyciski: zaokrąglenie (px)
		// od 1.1.3 – nazwa profilu przy poście (np. jak dawny kanał Feedzy: ikona + link do profilu) i kolor daty
		'z_link'      => 0,          // nazwa profilu jako link do profilu (nowa karta)
		'z_ikona'     => 0,          // ikona serwisu (Facebook / Instagram) przed nazwą
		'z_kolor'     => '',         // puste – kolor akcentu feedu
		'z_rozmiar'   => 0,          // px, komputer; 0 – jak tekst posta
		'z_rozmiar_m' => 0,          // px, telefon; 0 – jak tekst posta
		'z_linia'     => 0,          // wysokość linii nazwy (px); 0 – jak tekst
		'z_grubosc'   => 700,        // 400 | 500 | 600 | 700
		'z_podkresl'  => 'brak',     // zawsze | najechanie | brak (dotyczy linku)
		'od_nazwa'    => -1,         // nazwa → data (px); -1 – jak „Data → tekst”
		'kiedy_kolor' => '',         // kolor daty; puste – kolor akcentu, lekko przygaszony
		'linia_px_m'  => 0,          // wysokość linii tekstu na telefonie (px); 0 – jak na komputerze
	);
}

function mus_opcje() {
	$o = get_option( MUS_OPCJA, array() );
	$o = is_array( $o ) ? $o : array();
	return array(
		'zrodla' => array_values( array_map( function ( $z ) { return wp_parse_args( (array) $z, mus_zrodlo_domyslne() ); }, (array) ( $o['zrodla'] ?? array() ) ) ),
		'feedy'  => array_values( array_map( function ( $f ) { return wp_parse_args( (array) $f, mus_feed_domyslny() ); }, (array) ( $o['feedy'] ?? array() ) ) ),
	);
}

function mus_zrodlo( $id ) {
	foreach ( mus_opcje()['zrodla'] as $z ) {
		if ( $z['id'] === $id ) {
			return $z;
		}
	}
	return null;
}

function mus_feed( $id = '' ) {
	$feedy = mus_opcje()['feedy'];
	foreach ( $feedy as $f ) {
		if ( $f['id'] === $id ) {
			return $f;
		}
	}
	return ( '' === $id && $feedy ) ? $feedy[0] : null;
}

/** Kolor CSS (#rgb, #rrggbb, #rrggbbaa) albo pusty. */
/** Liczba px z jednym miejscem po przecinku (np. 14.4) w zakresie, inaczej domyślna. */
function mus_px( $v, $min, $max, $domyslna ) {
	$v = str_replace( ',', '.', (string) $v );
	return is_numeric( $v ) ? max( $min, min( $max, round( (float) $v, 1 ) ) ) : $domyslna;
}

function mus_kolor( $v ) {
	$v = trim( (string) $v );
	return preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $v ) ? strtolower( $v ) : '';
}

function mus_oczysc( $v ) {
	$v      = is_array( $v ) ? $v : array();
	$zrodla = array();
	$uzyte  = array();
	foreach ( (array) ( $v['zrodla'] ?? array() ) as $z ) {
		$z = (array) $z;
		if ( empty( $z['rss'] ) && empty( $z['nazwa'] ) ) {
			continue; // pusty wiersz
		}
		$id = sanitize_key( $z['id'] ?? '' );
		if ( ! $id || isset( $uzyte[ $id ] ) ) {
			$id = sanitize_key( sanitize_title( $z['nazwa'] ?? '' ) ) ?: 'zrodlo';
			$baza = $id;
			for ( $i = 2; isset( $uzyte[ $id ] ); $i++ ) {
				$id = $baza . '-' . $i;
			}
		}
		$uzyte[ $id ] = true;
		$zrodla[]     = array(
			'id'       => $id,
			'nazwa'    => sanitize_text_field( $z['nazwa'] ?? '' ),
			'serwis'   => 'instagram' === ( $z['serwis'] ?? '' ) ? 'instagram' : 'facebook',
			'rss'      => esc_url_raw( $z['rss'] ?? '' ),
			'profil'   => esc_url_raw( $z['profil'] ?? '' ),
			'awatar'   => esc_url_raw( $z['awatar'] ?? '' ),
			'przycisk' => sanitize_text_field( $z['przycisk'] ?? '' ),
		);
	}
	$ids   = wp_list_pluck( $zrodla, 'id' );
	$feedy = array();
	$uzyte = array();
	$licz  = function ( $x, $min, $max, $dom ) {
		return ( is_numeric( $x ) ) ? min( $max, max( $min, (int) $x ) ) : $dom;
	};
	$jeden = function ( $x, $dozwolone, $dom ) {
		return in_array( $x, $dozwolone, true ) ? $x : $dom;
	};
	foreach ( (array) ( $v['feedy'] ?? array() ) as $f ) {
		$f = wp_parse_args( (array) $f, mus_feed_domyslny() );
		$id = sanitize_key( $f['id'] ) ?: ( sanitize_key( sanitize_title( $f['nazwa'] ) ) ?: 'feed' );
		$baza = $id;
		for ( $i = 2; isset( $uzyte[ $id ] ); $i++ ) {
			$id = $baza . '-' . $i;
		}
		$uzyte[ $id ] = true;
		$d            = mus_feed_domyslny();
		$feedy[]      = array(
			'id'         => $id,
			'nazwa'      => sanitize_text_field( $f['nazwa'] ),
			'zrodla'     => array_values( array_intersect( array_map( 'sanitize_key', (array) $f['zrodla'] ), $ids ) ),
			'uklad'      => $jeden( $f['uklad'], array( 'siatka', 'karuzela', 'lista' ), 'siatka' ),
			'telefon'    => $jeden( $f['telefon'], array( 'siatka', 'pasek' ), 'siatka' ),
			'proporcje'  => $jeden( $f['proporcje'], array( '1/1', '4/5', '3/4', '4/3', '16/9' ), '1/1' ),
			'kol_d'      => $licz( $f['kol_d'], 1, 6, $d['kol_d'] ),
			'kol_t'      => $licz( $f['kol_t'], 1, 4, $d['kol_t'] ),
			'kol_m'      => $licz( $f['kol_m'], 1, 3, $d['kol_m'] ),
			'liczba'     => $licz( $f['liczba'], 1, 30, $d['liczba'] ),
			'wiersze'    => $licz( $f['wiersze'], 0, 10, 0 ),
			'szczegoly'  => $jeden( $f['szczegoly'], array( 'pod', 'obok', 'nakladka', 'brak' ), 'pod' ),
			'data'       => empty( $f['data'] ) ? 0 : 1,
			'godzina'    => empty( $f['godzina'] ) ? 0 : 1,
			'tekst'      => $jeden( $f['tekst'], array( 'brak', 'skrot', 'caly' ), 'skrot' ),
			'linie'      => $licz( $f['linie'], 1, 12, 4 ),
			'zrodlo'     => empty( $f['zrodlo'] ) ? 0 : 1,
			'link'       => empty( $f['link'] ) ? 0 : 1,
			'profile'    => $jeden( $f['profile'], array( 'brak', 'gora' ), 'brak' ),
			'przyciski'  => $jeden( $f['przyciski'], array( 'gora', 'dol', 'brak' ), 'dol' ),
			'tytul'      => sanitize_text_field( $f['tytul'] ),
			'podtytul'   => sanitize_text_field( $f['podtytul'] ),
			'kolor'      => mus_kolor( $f['kolor'] ),
			'p_tlo'      => mus_kolor( $f['p_tlo'] ),
			'p_tekst'    => mus_kolor( $f['p_tekst'] ),
			'p_hover'    => mus_kolor( $f['p_hover'] ),
			'p_czcionka' => preg_replace( '/[^\p{L}0-9 ,"\'\-]/u', '', (string) $f['p_czcionka'] ),
			'karta'      => mus_kolor( $f['karta'] ),
			'zaokr'      => $licz( $f['zaokr'], 0, 40, 0 ),
			'odstep'     => $licz( $f['odstep'], 0, 80, 20 ),
			'odstep_m'   => $licz( $f['odstep_m'], 0, 80, 12 ),
			'margines'   => $licz( $f['margines'], 0, 80, 0 ),
			'margines_m' => $licz( $f['margines_m'], 0, 40, 0 ),
			'autoplay'   => $licz( $f['autoplay'], 0, 30, 0 ),
			'od_zdjecie' => $licz( $f['od_zdjecie'], 0, 80, $d['od_zdjecie'] ),
			'od_data'    => $licz( $f['od_data'], 0, 60, $d['od_data'] ),
			'od_wiecej'  => $licz( $f['od_wiecej'], 0, 60, $d['od_wiecej'] ),
			'od_pod'     => $licz( $f['od_pod'], 0, 200, 0 ),
			'od_pod_m'   => $licz( $f['od_pod_m'], 0, 200, 0 ),
			'tekst_px'   => mus_px( $f['tekst_px'], 10, 24, $d['tekst_px'] ),
			'tekst_px_m' => mus_px( $f['tekst_px_m'], 10, 24, $d['tekst_px_m'] ),
			'linia_px'   => mus_px( $f['linia_px'], 12, 40, $d['linia_px'] ),
			'skrot_ciagly' => empty( $f['skrot_ciagly'] ) ? 0 : 1,
			'wiecej'     => $jeden( $f['wiecej'], array( 'link', 'przycisk' ), 'link' ),
			'w_kolor'    => mus_kolor( $f['w_kolor'] ),
			'w_hover'    => mus_kolor( $f['w_hover'] ),
			'w_czcionka' => preg_replace( '/[^\p{L}0-9 ,"\'\-]/u', '', (string) $f['w_czcionka'] ),
			'w_rozmiar'  => mus_px( $f['w_rozmiar'], 10, 24, $d['w_rozmiar'] ),
			'w_rozmiar_m' => mus_px( $f['w_rozmiar_m'], 10, 24, $d['w_rozmiar_m'] ),
			'w_grubosc'  => (int) $jeden( (string) $f['w_grubosc'], array( '400', '500', '600', '700' ), '600' ),
			'w_podkresl' => $jeden( $f['w_podkresl'], array( 'zawsze', 'najechanie', 'brak' ), 'najechanie' ),
			'p_rozmiar'  => mus_px( $f['p_rozmiar'], 10, 24, $d['p_rozmiar'] ),
			'p_pion'     => $licz( $f['p_pion'], 0, 30, $d['p_pion'] ),
			'p_poziom'   => $licz( $f['p_poziom'], 0, 60, $d['p_poziom'] ),
			'p_pion_m'   => $licz( $f['p_pion_m'], 0, 30, $d['p_pion_m'] ),
			'p_poziom_m' => $licz( $f['p_poziom_m'], 0, 60, $d['p_poziom_m'] ),
			'p_zaokr'    => $licz( $f['p_zaokr'], 0, 60, $d['p_zaokr'] ),
			'z_link'     => empty( $f['z_link'] ) ? 0 : 1,
			'z_ikona'    => empty( $f['z_ikona'] ) ? 0 : 1,
			'z_kolor'    => mus_kolor( $f['z_kolor'] ),
			'z_rozmiar'  => '' === (string) $f['z_rozmiar'] || ! (float) str_replace( ',', '.', (string) $f['z_rozmiar'] ) ? 0 : mus_px( $f['z_rozmiar'], 10, 32, 0 ),
			'z_rozmiar_m' => '' === (string) $f['z_rozmiar_m'] || ! (float) str_replace( ',', '.', (string) $f['z_rozmiar_m'] ) ? 0 : mus_px( $f['z_rozmiar_m'], 10, 32, 0 ),
			'z_linia'    => '' === (string) $f['z_linia'] || ! (float) str_replace( ',', '.', (string) $f['z_linia'] ) ? 0 : mus_px( $f['z_linia'], 12, 48, 0 ),
			'z_grubosc'  => (int) $jeden( (string) $f['z_grubosc'], array( '400', '500', '600', '700' ), '700' ),
			'z_podkresl' => $jeden( $f['z_podkresl'], array( 'zawsze', 'najechanie', 'brak' ), 'brak' ),
			'od_nazwa'   => '' === (string) $f['od_nazwa'] || (int) $f['od_nazwa'] < 0 ? -1 : $licz( $f['od_nazwa'], 0, 60, 0 ),
			'kiedy_kolor' => mus_kolor( $f['kiedy_kolor'] ),
			'linia_px_m' => '' === (string) $f['linia_px_m'] || ! (float) str_replace( ',', '.', (string) $f['linia_px_m'] ) ? 0 : mus_px( $f['linia_px_m'], 12, 40, 0 ),
		);
	}
	return array( 'zrodla' => $zrodla, 'feedy' => $feedy );
}

/* -------------------------------------------------------------------------
 * Cron: odświeżanie źródeł co godzinę
 * ---------------------------------------------------------------------- */
register_activation_hook( __FILE__, function () {
	if ( ! wp_next_scheduled( MUS_CRON ) ) {
		wp_schedule_event( time() + 60, 'hourly', MUS_CRON );
	}
} );
register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( MUS_CRON );
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( MUS_CRON ) ) {
		wp_schedule_event( time() + 60, 'hourly', MUS_CRON );
	}
} );
add_action( MUS_CRON, 'mus_odswiez_wszystko' );

require_once __DIR__ . '/includes/pobieranie.php';
require_once __DIR__ . '/includes/wyswietlanie.php';
if ( is_admin() ) {
	require_once __DIR__ . '/includes/panel.php';
}
