/* moveUP – Dostępność: odsłuch strony (od 1.6.0). Czyta treść strony głosem przeglądarki, fragment po fragmencie
   (nagłówki, akapity, elementy list) – długi tekst w jednej wypowiedzi Chrome ucina po ok. 15 s, a pauza
   na Androidzie nie działa, więc pauza = zatrzymanie z zapamiętaniem fragmentu, wznowienie = od tego fragmentu. */
(function () {
	'use strict';
	if (window.muOdsluch || !('speechSynthesis' in window)) return;
	var d = document, w = d.querySelector('.mu-odsluch');
	if (!w) return;
	var btn = w.querySelector('.mu-odsluch__btn'), stop = w.querySelector('.mu-odsluch__stop'), napis = w.querySelector('.mu-odsluch__napis');
	var status = w.querySelector('[data-odsluch-status]');
	var lang = w.getAttribute('data-lang') || d.documentElement.lang || 'pl-PL';
	var CZYTAJ = 'h1, h2, h3, h4, h5, h6, p, li, blockquote, figcaption, dt, dd, td, th';
	var POMIN = 'nav, aside, footer, form, script, style, noscript, [aria-hidden="true"], [hidden], .mu-odsluch, .mu-a11y, .mu-pasek, .screen-reader-text, .cky-consent-container';
	var lista = [], nr = 0, gra = false, sesja = false, czytany = null, glos = null; // sesja: od „Słuchaj” do „Zatrzymaj”/końca (także w pauzie)

	function oglos(t) { status.textContent = ''; setTimeout(function () { status.textContent = t; }, 50); }

	function wybierzGlos() {
		var g = speechSynthesis.getVoices(), kod = lang.toLowerCase(), jezyk = kod.slice(0, 2);
		glos = g.filter(function (v) { return v.lang.toLowerCase() === kod && /zosia/i.test(v.name); })[0]
			|| g.filter(function (v) { return v.lang.toLowerCase().replace('_', '-') === kod; })[0]
			|| g.filter(function (v) { return v.lang.toLowerCase().indexOf(jezyk) === 0; })[0] || null;
	}
	wybierzGlos();
	if (speechSynthesis.onvoiceschanged !== undefined) speechSynthesis.addEventListener('voiceschanged', wybierzGlos);

	function widoczny(el) { return !!(el.getClientRects().length) && getComputedStyle(el).visibility !== 'hidden'; }

	function zbierz() {
		var korzen = w.parentElement || d.querySelector('main') || d.body;
		var el = [].slice.call(korzen.querySelectorAll(CZYTAJ)).filter(function (e) {
			return !e.closest(POMIN) && widoczny(e) && (e.innerText || '').trim().length > 1;
		});
		// bez dublowania: element, w którym jest inny element z listy (np. li z akapitem), czytamy przez jego środek
		return el.filter(function (e) { return !el.some(function (x) { return x !== e && e.contains(x); }); });
	}

	function podswietl(e) {
		if (czytany) czytany.classList.remove('mu-odsluch-czytany');
		czytany = e || null;
		if (czytany) {
			czytany.classList.add('mu-odsluch-czytany');
			var r = czytany.getBoundingClientRect();
			if (r.top < gora() + 60 || r.bottom > innerHeight - 20) czytany.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
		}
	}

	/* Przypięcie (od 1.6.1): w trakcie słuchania i pauzy przycisk zostaje na ekranie – gdy jego miejsce wyjedzie
	   w górę, przyczepia się pod paskiem ułatwień (albo pod górną krawędzią); po „Zatrzymaj” i po końcu wraca na miejsce. */
	var aktywny = false, klatkaP = 0;
	function gora() {
		var p = d.querySelector('.mu-pasek'), y = 8;
		if (p && p.getClientRects().length) y = Math.max(y, p.getBoundingClientRect().bottom + 8);
		var ab = d.getElementById('wpadminbar');
		if (ab && getComputedStyle(ab).position === 'fixed') y = Math.max(y, ab.getBoundingClientRect().bottom + 8);
		return y;
	}
	function przypnij() {
		klatkaP = 0;
		var y = gora(), r = w.getBoundingClientRect();
		var trzeba = aktywny && r.top < y;
		if (trzeba) {
			w.style.setProperty('--mu-odsluch-gora', y + 'px');
			w.style.setProperty('--mu-odsluch-l', Math.round(r.left) + 'px');
			w.style.setProperty('--mu-odsluch-w', Math.round(r.width) + 'px');
		}
		w.classList.toggle('mu-odsluch--przypiety', trzeba);
	}
	function naPrzewin() { if (!klatkaP) klatkaP = requestAnimationFrame(przypnij); }
	function ustawAktywny(on) {
		if (on === aktywny) return;
		aktywny = on;
		if (on) { addEventListener('scroll', naPrzewin, { passive: true }); addEventListener('resize', naPrzewin, { passive: true }); }
		else { removeEventListener('scroll', naPrzewin); removeEventListener('resize', naPrzewin); }
		przypnij();
	}

	function stanPrzycisku() {
		btn.setAttribute('aria-pressed', gra ? 'true' : 'false');
		napis.textContent = gra ? btn.getAttribute('data-pauza') : (sesja ? btn.getAttribute('data-wznow') : btn.getAttribute('data-tekst'));
		stop.hidden = !sesja;
		ustawAktywny(sesja);
	}

	function mow() {
		if (!gra) return;
		if (nr >= lista.length) { koniec(); return; }
		var e = lista[nr], u = new SpeechSynthesisUtterance(e.innerText.replace(/\s+/g, ' ').trim());
		u.lang = lang;
		if (glos) u.voice = glos;
		u.rate = 1;
		u.onend = function () { if (!gra) return; nr++; mow(); };
		u.onerror = function (x) { if (x.error === 'interrupted' || x.error === 'canceled') return; nr++; mow(); };
		podswietl(e);
		speechSynthesis.speak(u);
	}

	function graj() {
		if (!sesja) { lista = zbierz(); nr = 0; }
		if (!lista.length) return;
		gra = true; sesja = true; stanPrzycisku();
		speechSynthesis.cancel();
		mow();
	}

	function pauza() {
		gra = false;
		speechSynthesis.cancel();
		stanPrzycisku();
		oglos(btn.getAttribute('data-wznow'));
	}

	function koniec(cicho) {
		gra = false; sesja = false; nr = 0;
		speechSynthesis.cancel();
		podswietl(null);
		stanPrzycisku();
		if (!cicho) oglos(btn.getAttribute('data-tekst'));
	}

	function klik(b) {
		if (b === stop) { koniec(); try { btn.focus({ preventScroll: true }); } catch (e) { btn.focus(); } return; } // fokus wraca na przycisk, strona zostaje w miejscu
		if (gra) pauza(); else graj();
	}

	w.addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) klik(b); });
	// zatrzymaj przy zmianie strony i schowaniu karty (inaczej Chrome czyta dalej w tle albo się zawiesza)
	addEventListener('pagehide', function () { koniec(true); });
	d.addEventListener('visibilitychange', function () { if (d.hidden && gra) pauza(); });

	window.muOdsluch = { graj: graj, pauza: pauza, stop: koniec };
	if (window.muOdsluchKlik) { var x = window.muOdsluchKlik; window.muOdsluchKlik = 0; klik(x); }
})();
