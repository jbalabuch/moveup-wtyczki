<?php
/**
 * Ikony liniowe 24×24 (stroke = currentColor) – wspólne dla panelu i paska. Dekoracyjne: nazwę opcji niesie napis albo aria-label.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'rozmiar'   => '<path d="M3 7V5h11v2M8.5 5v14M6.5 19h4M14 13v-1.5h7V13M17.5 11.5V19M16 19h3"/>',
	'odstepy'   => '<path d="M21 6H9M21 12H9M21 18H9M4 4v16M2 6l2-2 2 2M2 18l2 2 2-2"/>',
	'czcionka'  => '<path d="M3 19 8.5 5h1L15 19M5.2 14h7.6M17.5 19v-6.5a2.5 2.5 0 0 1 5 0V19M17.5 15.5h5"/>',
	'ciemny'    => '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18z" fill="currentColor"/>',
	'jasny'     => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
	'odwroc'    => '<path d="M17 3l4 4-4 4M21 7H8a4 4 0 0 0-4 4M7 21l-4-4 4-4M3 17h13a4 4 0 0 0 4-4"/>',
	'szarosc'   => '<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z"/><path d="M12 3v19" />',
	'nasyc-n'   => '<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z" stroke-dasharray="3 3"/>',
	'nasyc-w'   => '<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z" fill="currentColor"/>',
	'linki'     => '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
	'naglowki'  => '<path d="M5 4v16M15 4v16M5 12h10M19 20v-8l-2 1.5"/>',
	'fokus'     => '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><rect x="9" y="9" width="6" height="6" rx="1"/>',
	'kursor'    => '<path d="M5 3l14 7-6 2-2 6z"/><path d="M13 12l6 6"/>',
	'animacje'  => '<circle cx="12" cy="12" r="9"/><path d="M10 9v6M14 9v6"/>',
	'czytaj'    => '<path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>',
	'linijka'   => '<rect x="2" y="8" width="20" height="8" rx="1.5"/><path d="M6 8v3M10 8v4M14 8v3M18 8v4"/>',
	'maska'     => '<rect x="3" y="3" width="18" height="18" rx="2" fill="currentColor" fill-opacity=".18" stroke="none"/><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 10h18M3 14h18"/><rect x="3" y="10" width="18" height="4" fill="#fff" stroke="none"/>',
	'obrazy'    => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.5"/><path d="m21 15-5-5-6 6M3 3l18 18"/>',
	'p-wzrok'   => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
	'p-dysleksja' => '<path d="M2 5h6a4 4 0 0 1 4 4v11a3 3 0 0 0-3-3H2zM22 5h-6a4 4 0 0 0-4 4v11a3 3 0 0 1 3-3h7z"/>',
	'p-adhd'    => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
	'p-epilepsja' => '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/><path d="M3 3l18 18"/>',
	'p-ruch'    => '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
	'p-poznawcze' => '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
	'reset'     => '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
);
