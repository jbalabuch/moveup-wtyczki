<?php
/**
 * Pasek ułatwień na górze strony (od 1.5.0, ustawienie „Wygląd: pasek u góry”). Najważniejsze opcje widoczne od razu,
 * reszta w pełnym panelu pod „Wszystkie ustawienia”. Na ekranach węższych niż „pasek od” – zwykły okrągły przycisk.
 * Kod paska działa dopiero po wczytaniu dostepnosc.js (pierwsze najechanie / fokus / kliknięcie); kliknięcie przed
 * wczytaniem jest zapamiętywane i wykonywane po wczytaniu.
 *
 * @var array $o ustawienia
 * @var array $f włączone funkcje (klucze)
 */
defined( 'ABSPATH' ) || exit;

$ikony = include __DIR__ . '/ikony.php';
$ikona = function ( $nazwa ) use ( $ikony ) {
	return '<svg class="mu-pasek__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $ikony[ $nazwa ] . '</svg>';
};
$przelacznik = function ( $nazwa, $klasa, $etykieta, $grupa = '' ) use ( $ikona ) {
	printf(
		'<button type="button" class="mu-pasek__btn" data-k="%s"%s aria-pressed="false" aria-label="%s" data-podpowiedz="%s">%s</button>',
		esc_attr( $klasa ),
		$grupa ? ' data-g="' . esc_attr( $grupa ) . '"' : '',
		esc_attr( $etykieta ),
		esc_attr( $etykieta ),
		$ikona( $nazwa ) // phpcs:ignore WordPress.Security.EscapeOutput -- stałe SVG
	);
};
$minus = '<svg class="mu-pasek__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14"/></svg>';
$plus  = '<svg class="mu-pasek__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14M5 12h14"/></svg>';
?>
<div class="mu-pasek" role="region" aria-label="<?php esc_attr_e( 'Ułatwienia dostępu', 'moveup-dostepnosc' ); ?>" lang="<?php echo esc_attr( substr( get_bloginfo( 'language' ), 0, 2 ) ); ?>">
	<a class="mu-pasek__skok" href="<?php echo esc_attr( apply_filters( 'moveup_dostepnosc_skok', '#main' ) ); ?>"><?php esc_html_e( 'Przejdź do treści', 'moveup-dostepnosc' ); ?></a>
	<div class="mu-pasek__in">
		<?php if ( isset( $f['kontrast'] ) ) : ?>
		<div class="mu-pasek__grupa" role="group" aria-labelledby="mu-pasek-kontrast">
			<span class="mu-pasek__lbl" id="mu-pasek-kontrast"><?php esc_html_e( 'Kontrast', 'moveup-dostepnosc' ); ?></span>
			<?php
			$przelacznik( 'odwroc', 'mu-odwroc', __( 'Odwrócone kolory', 'moveup-dostepnosc' ), 'kolory' );
			$przelacznik( 'szarosc', 'mu-szarosc', __( 'Odcienie szarości', 'moveup-dostepnosc' ), 'kolory' );
			$przelacznik( 'ciemny', 'mu-kontrast-ciemny', __( 'Ciemny kontrast', 'moveup-dostepnosc' ), 'kolory' );
			$przelacznik( 'jasny', 'mu-kontrast-jasny', __( 'Jasny kontrast', 'moveup-dostepnosc' ), 'kolory' );
			$przelacznik( 'nasyc-n', 'mu-nasycenie-niskie', __( 'Niskie nasycenie', 'moveup-dostepnosc' ), 'kolory' );
			$przelacznik( 'nasyc-w', 'mu-nasycenie-wysokie', __( 'Wysokie nasycenie', 'moveup-dostepnosc' ), 'kolory' );
			?>
		</div>
		<?php endif; ?>
		<?php if ( isset( $f['linki'] ) || isset( $f['naglowki'] ) || isset( $f['czcionka'] ) ) : ?>
		<div class="mu-pasek__grupa" role="group" aria-labelledby="mu-pasek-tekst">
			<span class="mu-pasek__lbl" id="mu-pasek-tekst"><?php esc_html_e( 'Tekst', 'moveup-dostepnosc' ); ?></span>
			<?php
			if ( isset( $f['linki'] ) ) {
				$przelacznik( 'linki', 'mu-linki', __( 'Podkreśl linki', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['naglowki'] ) ) {
				$przelacznik( 'naglowki', 'mu-naglowki', __( 'Wyróżnij nagłówki', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['czcionka'] ) ) {
				$przelacznik( 'czcionka', 'mu-czcionka', __( 'Czytelna czcionka', 'moveup-dostepnosc' ) );
			}
			?>
		</div>
		<?php endif; ?>
		<?php if ( isset( $f['rozmiar'] ) || isset( $f['odstepy'] ) ) : ?>
		<div class="mu-pasek__grupa" role="group" aria-labelledby="mu-pasek-powieksz">
			<span class="mu-pasek__lbl" id="mu-pasek-powieksz"><?php esc_html_e( 'Rozmiar', 'moveup-dostepnosc' ); ?></span>
			<?php if ( isset( $f['rozmiar'] ) ) : ?>
			<span class="mu-pasek__krok">
				<button type="button" class="mu-pasek__btn mu-pasek__btn--maly" data-krok="-1" aria-label="<?php esc_attr_e( 'Zmniejsz tekst', 'moveup-dostepnosc' ); ?>" data-podpowiedz="<?php esc_attr_e( 'Zmniejsz tekst', 'moveup-dostepnosc' ); ?>"><?php echo $minus; // phpcs:ignore ?></button>
				<span class="mu-pasek__wart" data-wart-pasek data-podpowiedz="<?php esc_attr_e( 'Rozmiar tekstu', 'moveup-dostepnosc' ); ?>"><span aria-hidden="true">Aa </span>100%</span>
				<button type="button" class="mu-pasek__btn mu-pasek__btn--maly" data-krok="1" aria-label="<?php esc_attr_e( 'Powiększ tekst', 'moveup-dostepnosc' ); ?>" data-podpowiedz="<?php esc_attr_e( 'Powiększ tekst', 'moveup-dostepnosc' ); ?>"><?php echo $plus; // phpcs:ignore ?></button>
			</span>
			<?php endif; ?>
			<?php
			if ( isset( $f['odstepy'] ) ) {
				$przelacznik( 'odstepy', 'mu-odstepy', __( 'Odstępy w tekście', 'moveup-dostepnosc' ) );
			}
			?>
		</div>
		<?php endif; ?>
		<?php if ( isset( $f['linijka'] ) || isset( $f['animacje'] ) || isset( $f['kursor'] ) || isset( $f['czytaj'] ) ) : ?>
		<div class="mu-pasek__grupa" role="group" aria-labelledby="mu-pasek-czytanie">
			<span class="mu-pasek__lbl" id="mu-pasek-czytanie"><?php esc_html_e( 'Czytanie', 'moveup-dostepnosc' ); ?></span>
			<?php
			if ( isset( $f['linijka'] ) ) {
				$przelacznik( 'linijka', 'mu-linijka', __( 'Linijka do czytania', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['animacje'] ) ) {
				$przelacznik( 'animacje', 'mu-bez-animacji', __( 'Zatrzymaj animacje', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['kursor'] ) ) {
				$przelacznik( 'kursor', 'mu-kursor', __( 'Duży kursor', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['czytaj'] ) ) {
				$przelacznik( 'czytaj', 'mu-czytaj', __( 'Czytaj na głos (kliknij tekst)', 'moveup-dostepnosc' ) );
			}
			?>
		</div>
		<?php endif; ?>
		<div class="mu-pasek__grupa mu-pasek__grupa--koniec">
			<button type="button" class="mu-pasek__btn mu-a11y__reset" data-reset aria-label="<?php esc_attr_e( 'Przywróć ustawienia', 'moveup-dostepnosc' ); ?>" data-podpowiedz="<?php esc_attr_e( 'Przywróć ustawienia', 'moveup-dostepnosc' ); ?>"><?php echo $ikona( 'reset' ); // phpcs:ignore ?></button>
			<button type="button" class="mu-pasek__wszystkie" data-wszystkie aria-controls="mu-a11y-panel" aria-expanded="false" aria-keyshortcuts="Alt+Shift+A" aria-label="<?php esc_attr_e( 'Więcej ułatwień dostępu', 'moveup-dostepnosc' ); ?>" data-podpowiedz="<?php esc_attr_e( 'Więcej ułatwień dostępu', 'moveup-dostepnosc' ); ?>"><?php esc_html_e( 'Więcej', 'moveup-dostepnosc' ); ?></button>
		</div>
	</div>
	<span class="mu-a11y-sr" role="status" data-status-pasek></span>
</div>
