<?php
/**
 * Przycisk i panel. Panel leży w <template> – przeglądarka go nie renderuje, dopóki ktoś nie otworzy ułatwień.
 *
 * @var array  $o   ustawienia
 * @var array  $f   włączone funkcje (klucze)
 * @var string $bok left | right
 *
 * Kolor akcentu w panelu: kolor przycisku, jeśli ma z białym kontrast min. 4,5:1 (tekst), inaczej prawie czarny.
 */
defined( 'ABSPATH' ) || exit;

$ikony = include __DIR__ . '/ikony.php';
$svg = function ( $nazwa, $klasa = 'mu-a11y__ico' ) use ( $ikony ) {
	return '<svg class="' . $klasa . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $ikony[ $nazwa ] . '</svg>';
};
$opcja = function ( $ikona, $klasa, $etykieta, $grupa = '' ) use ( $svg ) {
	printf(
		'<button type="button" class="mu-a11y__opt" data-k="%s"%s aria-pressed="false">%s<span class="mu-a11y__lbl">%s</span></button>',
		esc_attr( $klasa ),
		$grupa ? ' data-g="' . esc_attr( $grupa ) . '"' : '',
		$svg( $ikona ), // phpcs:ignore WordPress.Security.EscapeOutput -- stałe SVG
		esc_html( $etykieta )
	);
};
$profil = function ( $ikona, $id, $etykieta ) use ( $svg ) {
	printf(
		'<button type="button" class="mu-a11y__opt" data-profil="%s" aria-pressed="false">%s<span class="mu-a11y__lbl">%s</span></button>',
		esc_attr( $id ),
		$svg( $ikona ), // phpcs:ignore WordPress.Security.EscapeOutput -- stałe SVG
		esc_html( $etykieta )
	);
};
$tekst = isset( $f['odstepy'] ) || isset( $f['czcionka'] ) || isset( $f['rozmiar'] );
$nawig = isset( $f['linki'] ) || isset( $f['naglowki'] ) || isset( $f['fokus'] ) || isset( $f['kursor'] ) || isset( $f['linijka'] ) || isset( $f['maska'] );
$inne  = isset( $f['animacje'] ) || isset( $f['obrazy'] ) || isset( $f['czytaj'] );
?>
<button type="button" class="mu-a11y-btn" aria-keyshortcuts="Alt+Shift+A" aria-expanded="false" aria-controls="mu-a11y-panel" aria-label="<?php esc_attr_e( 'Ułatwienia dostępu', 'moveup-dostepnosc' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="4" r="2.2"/><path d="M4 7.6c2.7.8 5.3 1.2 8 1.2s5.3-.4 8-1.2l.5 1.9c-2 .6-4.1 1-6.2 1.2v3.2l2 7.6-1.9.5-2.4-6.9-2.4 6.9-1.9-.5 2-7.6v-3.2c-2.1-.2-4.2-.6-6.2-1.2z"/></svg></button>
<template id="mu-a11y-tpl">
<div id="mu-a11y-panel" class="mu-a11y mu-a11y--<?php echo esc_attr( $bok ); ?>" role="dialog" aria-labelledby="mu-a11y-tytul" lang="<?php echo esc_attr( substr( get_bloginfo( 'language' ), 0, 2 ) ); ?>" style="--mu-dol:<?php echo absint( $o['odstep_dol'] ) + 60; ?>px;--mu-bok:<?php echo absint( $o['odstep_bok'] ); ?>px;--mu-akcent:<?php echo esc_attr( mu_dost_kontrast( $o['kolor_tla'], '#ffffff' ) >= 4.5 ? $o['kolor_tla'] : '#1a1a1a' ); ?>">
	<div class="mu-a11y__head">
		<span class="mu-a11y__logo" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><circle cx="12" cy="4" r="2.2"/><path d="M4 7.6c2.7.8 5.3 1.2 8 1.2s5.3-.4 8-1.2l.5 1.9c-2 .6-4.1 1-6.2 1.2v3.2l2 7.6-1.9.5-2.4-6.9-2.4 6.9-1.9-.5 2-7.6v-3.2c-2.1-.2-4.2-.6-6.2-1.2z"/></svg></span>
		<h2 class="mu-a11y__title" id="mu-a11y-tytul" tabindex="-1"><?php esc_html_e( 'Ułatwienia dostępu', 'moveup-dostepnosc' ); ?></h2>
		<button type="button" class="mu-a11y__close" aria-label="<?php esc_attr_e( 'Zamknij ułatwienia dostępu', 'moveup-dostepnosc' ); ?>"><svg class="mu-a11y__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
	</div>
	<div class="mu-a11y__body">
		<?php if ( isset( $f['profile'] ) ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Profile', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			$profil( 'p-wzrok', 'slabowidzacy', __( 'Słabowidzący', 'moveup-dostepnosc' ) );
			$profil( 'p-dysleksja', 'dysleksja', __( 'Dysleksja', 'moveup-dostepnosc' ) );
			$profil( 'p-adhd', 'adhd', __( 'ADHD i skupienie', 'moveup-dostepnosc' ) );
			$profil( 'p-epilepsja', 'epilepsja', __( 'Epilepsja', 'moveup-dostepnosc' ) );
			$profil( 'p-ruch', 'ruch', __( 'Ruch i klawiatura', 'moveup-dostepnosc' ) );
			$profil( 'p-poznawcze', 'poznawcze', __( 'Trudności poznawcze', 'moveup-dostepnosc' ) );
			?>
		</div>
		<?php endif; ?>
		<?php if ( $tekst ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Tekst', 'moveup-dostepnosc' ); ?></h3>
		<?php if ( isset( $f['rozmiar'] ) ) : ?>
		<div class="mu-a11y__size" role="group" aria-labelledby="mu-a11y-rozm">
			<?php echo $svg( 'rozmiar' ); // phpcs:ignore ?>
			<span class="mu-a11y__lbl" id="mu-a11y-rozm"><?php esc_html_e( 'Rozmiar tekstu', 'moveup-dostepnosc' ); ?></span>
			<button type="button" class="mu-a11y__step" data-krok="-1" aria-label="<?php esc_attr_e( 'Zmniejsz tekst', 'moveup-dostepnosc' ); ?>"><svg class="mu-a11y__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14"/></svg></button>
			<span class="mu-a11y__val" data-wart>100%</span>
			<button type="button" class="mu-a11y__step" data-krok="1" aria-label="<?php esc_attr_e( 'Powiększ tekst', 'moveup-dostepnosc' ); ?>"><svg class="mu-a11y__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14M5 12h14"/></svg></button>
		</div>
		<?php endif; ?>
		<div class="mu-a11y__grid">

			<?php
			if ( isset( $f['odstepy'] ) ) {
				$opcja( 'odstepy', 'mu-odstepy', __( 'Odstępy w tekście', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['czcionka'] ) ) {
				$opcja( 'czcionka', 'mu-czcionka', __( 'Czytelna czcionka', 'moveup-dostepnosc' ) );
			}
			?>
		</div>
		<?php endif; ?>

		<?php if ( isset( $f['kontrast'] ) ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Kontrast i kolory', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			$opcja( 'ciemny', 'mu-kontrast-ciemny', __( 'Ciemny kontrast', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'jasny', 'mu-kontrast-jasny', __( 'Jasny kontrast', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'odwroc', 'mu-odwroc', __( 'Odwrócone kolory', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'szarosc', 'mu-szarosc', __( 'Odcienie szarości', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'nasyc-n', 'mu-nasycenie-niskie', __( 'Niskie nasycenie', 'moveup-dostepnosc' ), 'kolory' );
			$opcja( 'nasyc-w', 'mu-nasycenie-wysokie', __( 'Wysokie nasycenie', 'moveup-dostepnosc' ), 'kolory' );
			?>
		</div>
		<?php endif; ?>

		<?php if ( $nawig ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Nawigacja', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			if ( isset( $f['linki'] ) ) {
				$opcja( 'linki', 'mu-linki', __( 'Podkreśl linki', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['naglowki'] ) ) {
				$opcja( 'naglowki', 'mu-naglowki', __( 'Wyróżnij nagłówki', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['fokus'] ) ) {
				$opcja( 'fokus', 'mu-fokus', __( 'Wyraźny fokus', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['kursor'] ) ) {
				$opcja( 'kursor', 'mu-kursor', __( 'Duży kursor', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['linijka'] ) ) {
				$opcja( 'linijka', 'mu-linijka', __( 'Linijka do czytania', 'moveup-dostepnosc' ), 'prowadnica' );
			}
			if ( isset( $f['maska'] ) ) {
				$opcja( 'maska', 'mu-maska', __( 'Maska czytania', 'moveup-dostepnosc' ), 'prowadnica' );
			}
			?>
		</div>
		<?php endif; ?>

		<?php if ( $inne ) : ?>
		<h3 class="mu-a11y__sec"><?php esc_html_e( 'Animacje, obrazy i czytanie', 'moveup-dostepnosc' ); ?></h3>
		<div class="mu-a11y__grid">
			<?php
			if ( isset( $f['animacje'] ) ) {
				$opcja( 'animacje', 'mu-bez-animacji', __( 'Zatrzymaj animacje', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['obrazy'] ) ) {
				$opcja( 'obrazy', 'mu-bez-obrazow', __( 'Ukryj obrazy', 'moveup-dostepnosc' ) );
			}
			if ( isset( $f['czytaj'] ) ) {
				$opcja( 'czytaj', 'mu-czytaj', __( 'Czytaj na głos', 'moveup-dostepnosc' ) );
			}
			?>
		</div>
		<?php if ( isset( $f['czytaj'] ) ) : ?>
		<p class="mu-a11y__hint" data-czytaj-info hidden><?php esc_html_e( 'Kliknij akapit, nagłówek lub link, a przeczytamy go na głos. Klawiaturą: przejdź do elementu i naciśnij Alt + R.', 'moveup-dostepnosc' ); ?></p>
		<?php endif; ?>
		<?php endif; ?>
	</div>
	<div class="mu-a11y__foot">
		<button type="button" class="mu-a11y__reset"><?php echo $svg( 'reset' ); // phpcs:ignore ?><?php esc_html_e( 'Przywróć ustawienia', 'moveup-dostepnosc' ); ?></button>
		<?php if ( isset( $f['ukryj'] ) ) : ?>
		<button type="button" class="mu-a11y__reset mu-a11y__ukryj" data-ukryj aria-keyshortcuts="Alt+Shift+A" data-ukryj-tekst="<?php esc_attr_e( 'Ukryj przycisk', 'moveup-dostepnosc' ); ?>" data-pokaz-tekst="<?php esc_attr_e( 'Pokaż przycisk', 'moveup-dostepnosc' ); ?>" data-komunikat="<?php esc_attr_e( 'Przycisk ukryty do zamknięcia przeglądarki. Panel otworzysz skrótem Alt + Shift + A.', 'moveup-dostepnosc' ); ?>"><?php esc_html_e( 'Ukryj przycisk', 'moveup-dostepnosc' ); ?></button>
		<?php endif; ?>
		<?php if ( $o['deklaracja'] ) : ?>
		<a class="mu-a11y__link" href="<?php echo esc_url( $o['deklaracja'] ); ?>"><?php esc_html_e( 'Deklaracja dostępności', 'moveup-dostepnosc' ); ?></a>
		<?php endif; ?>
	</div>
	<p class="mu-a11y__skrot"><?php esc_html_e( 'Skrót klawiszowy panelu: Alt + Shift + A', 'moveup-dostepnosc' ); ?></p>
	<div class="mu-a11y__sr" role="status" data-status></div>
</div>
</template>
<script id="mu-a11y-btn-js">(function(){var b=document.querySelector(".mu-a11y-btn"),c=window.muA11y,w=0;function l(){if(w)return;w=1;if(!document.querySelector('link[href="'+c.css+'"]')){var s=document.createElement("link");s.rel="stylesheet";s.href=c.css;document.head.appendChild(s)}if(!document.querySelector('script[src="'+c.js+'"]')){var j=document.createElement("script");j.src=c.js;document.head.appendChild(j)}}
b.addEventListener("pointerenter",l,{once:true});b.addEventListener("focus",l,{once:true});function t(){l();window.muA11yPanel?window.muA11yPanel.toggle():(window.muA11yOtworz=1)}b.addEventListener("click",t);
document.addEventListener("keydown",function(e){if(e.altKey&&e.shiftKey&&!e.ctrlKey&&!e.metaKey&&e.code==="KeyA"){e.preventDefault();t()}});var p=document.querySelector(".mu-pasek");if(p){p.addEventListener("pointerover",l,{once:true});p.addEventListener("focusin",l,{once:true});p.addEventListener("click",function(e){var x=e.target.closest("button");if(x&&!window.muA11yPanel){l();window.muA11yKlik=x}})}})();</script>
<?php
