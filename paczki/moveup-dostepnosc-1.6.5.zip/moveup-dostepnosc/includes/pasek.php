<?php
/**
 * Pasek u góry strony (od 1.5.0, ustawienie „Wygląd: pasek u góry”).
 * Od szerokości „pasek_od” – pasek 40 px przyklejony do góry (strona przesunięta o jego wysokość, jak w DJ-Accessibility);
 * na węższych ekranach – okrągły przycisk jak dotąd. Najważniejsze opcje widoczne od razu, reszta pod „Wszystkie ustawienia”.
 * Pierwszy element paska to „Przejdź do treści” (cel: filtr moveup_dostepnosc_skok, domyślnie #main – Kadence),
 * żeby osoba z klawiaturą nie musiała przechodzić przez wszystkie przyciski paska (WCAG 2.4.1).
 * Styl paska (ok. 2 KB) w <head>, kod (dostepnosc.js) dopiero po pierwszym najechaniu, fokusie albo kliknięciu.
 */
defined( 'ABSPATH' ) || exit;

function mu_dost_css_paska( $o ) {
	$od    = absint( $o['pasek_od'] );
	$a     = esc_attr( $o['kolor_tla'] );
	$i     = esc_attr( $o['kolor_ikony'] );
	$tekst = mu_dost_kontrast( $o['kolor_tla'], '#ffffff' ) >= 4.5 ? $a : '#1a1a1a'; // napis na białym tle – min. 4,5:1
	$b     = '.mu-pasek .mu-pasek__btn';
	return '.mu-pasek{display:none}'
		. '@media (min-width:' . $od . 'px){'
		. 'body.mu-z-paskiem{padding-top:48px!important}'
		. 'body.mu-z-paskiem .mu-a11y-btn{display:none!important}'
		. '.mu-pasek{display:block;position:fixed;top:0;left:0;right:0;z-index:2147482998;height:48px;box-sizing:border-box;background:#f7f7fb;border-bottom:1px solid #e3e2ec;color:#1a1a1a;font:400 15px/1.2 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;text-align:left}'
		. '.admin-bar .mu-pasek{top:var(--wp-admin--admin-bar--height,32px);z-index:99998}' // od 1.6.3: pod paskiem WordPressa (99999) – inaczej jego rozwijane menu (np. „Kokpit”) chowało się pod paskiem ułatwień
		. '.mu-pasek__in{display:flex;justify-content:space-between;align-items:center;gap:0;height:100%;box-sizing:border-box;max-width:calc(var(--global-content-width,1180px) + 2 * var(--global-content-edge-padding,16px));margin:0 auto;padding:0 var(--global-content-edge-padding,16px)}'
		. '.mu-pasek__grupa{display:flex;align-items:center;gap:4px;height:100%;padding:0 0 0 16px;border-left:1px solid #e3e2ec}'
		. '.mu-pasek__grupa:first-child{padding-left:0;border-left:0}'
		. '.mu-pasek__grupa--koniec{gap:10px}'
		. '.mu-pasek__lbl{margin-right:8px;white-space:nowrap}'
		. '.mu-pasek__krok{display:inline-flex;align-items:center}'
		. '.mu-pasek__wart{min-width:64px;text-align:center;font-weight:600;white-space:nowrap}'
		. $b . ',' . $b . ':hover,' . $b . ':focus,' . $b . ':active{display:inline-flex!important;align-items:center;justify-content:center;width:36px!important;height:36px!important;min-height:0!important;margin:0!important;padding:0!important;border:1px solid transparent!important;border-radius:50%!important;background:transparent!important;color:#1a1a1a!important;box-shadow:none!important;cursor:pointer;line-height:1}'
		. $b . ':hover{background:#e9e8f2!important}'
		. $b . '[aria-pressed="true"],' . $b . '[aria-pressed="true"]:hover{background:' . $a . '!important;border-color:' . $a . '!important;color:' . $i . '!important}'
		. $b . ':disabled{opacity:.4;cursor:default}'
		. '.mu-pasek__ico{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}'
		. '.mu-pasek__btn--maly .mu-pasek__ico{width:16px;height:16px}'
		. '.mu-pasek .mu-pasek__wszystkie,.mu-pasek .mu-pasek__wszystkie:focus{height:34px!important;min-height:0!important;margin:0!important;padding:0 12px!important;border:1.5px solid ' . $a . '!important;border-radius:17px!important;background:#fff!important;color:' . $tekst . '!important;font:inherit!important;font-weight:600!important;line-height:1!important;box-shadow:none!important;cursor:pointer;white-space:nowrap;text-transform:none!important;letter-spacing:0!important}'
		. '.mu-pasek .mu-pasek__wszystkie:hover,.mu-pasek .mu-pasek__wszystkie[aria-expanded="true"]{background:' . $a . '!important;color:' . $i . '!important}'
		. '.mu-pasek :focus-visible{outline:3px solid ' . $a . '!important;outline-offset:2px!important}'
		// Podpowiedzi (od 1.6.2, jak w DJ-Accessibility): nazwa opcji od razu po najechaniu i przy fokusie z klawiatury (title pokazywał się po ok. 1 s i nie przy klawiaturze)
		. '.mu-pasek [data-podpowiedz]{position:relative}'
		. '.mu-pasek [data-podpowiedz]::after{content:attr(data-podpowiedz);position:absolute;top:calc(100% + 8px);left:50%;transform:translateX(-50%);z-index:3;padding:6px 10px;border-radius:6px;background:#1a1a1a;color:#fff;font:500 13px/1.3 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;letter-spacing:0;white-space:nowrap;pointer-events:none;opacity:0;visibility:hidden;transition:opacity .12s}'
		. '.mu-pasek [data-podpowiedz]:hover::after,.mu-pasek [data-podpowiedz]:focus-visible::after{opacity:1;visibility:visible}'
		. '.mu-pasek .mu-pasek__grupa--koniec [data-podpowiedz]::after{left:auto;right:0;transform:none}'
		. '.mu-pasek .mu-pasek__grupa:first-child .mu-pasek__btn:first-of-type::after{left:0;transform:none}'
		. '.mu-pasek .mu-pasek__skok{position:absolute;left:8px;top:-60px;z-index:1;padding:8px 14px;border-radius:6px;background:' . $a . ';color:' . $i . ';font-weight:600;text-decoration:none}'
		. '.mu-pasek .mu-pasek__skok:focus{top:4px}'
		. 'body.mu-z-paskiem .mu-a11y [data-ukryj]{display:none!important}'
		. '.mu-a11y-sr{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}'
		. 'body.mu-z-paskiem .mu-a11y{top:56px;bottom:auto!important;right:8px;left:auto;max-height:calc(100vh - 64px);max-height:calc(100dvh - 64px)}'
		. '.admin-bar.mu-z-paskiem .mu-a11y{top:calc(56px + var(--wp-admin--admin-bar--height,32px))}'
		. '}'
		. '@media (min-width:' . $od . 'px) and (max-width:1279px){.mu-pasek__lbl{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}.mu-pasek__grupa{padding-left:10px}.mu-pasek__in{gap:4px}}'
		. '@media print{.mu-pasek{display:none!important}body.mu-z-paskiem{padding-top:0!important}}';
}

add_filter( 'body_class', function ( $k ) {
	$o = mu_dost_opcje();
	if ( $o['wlaczony'] && 'pasek' === $o['uklad'] ) {
		$k[] = 'mu-z-paskiem';
	}
	return $k;
} );

add_action( 'wp_body_open', function () {
	$o = mu_dost_opcje();
	if ( ! $o['wlaczony'] || 'pasek' !== $o['uklad'] ) {
		return;
	}
	$f = array_flip( (array) $o['funkcje'] );
	include dirname( __DIR__ ) . '/tmpl/pasek.php';
}, 5 );
