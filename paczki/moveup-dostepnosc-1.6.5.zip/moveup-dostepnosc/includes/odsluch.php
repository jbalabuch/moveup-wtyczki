<?php
/**
 * Odsłuch strony (od 1.6.0, Ustawienia → Dostępność → „Przycisk odsłuchu strony”).
 * Przycisk „Słuchaj tekstu tej strony” przed treścią strony: czyta głosem przeglądarki (Web Speech API – bez zewnętrznych
 * usług, bez plików audio, bez zgody na cookies) nagłówki, akapity i listy treści, podświetla czytany fragment,
 * Pauza / Wznów / Zatrzymaj. Przycisk jest w HTML od razu (bez przeskoku układu), skrypt (assets/odsluch.js, ok. 3 KB)
 * wczytuje się dopiero po najechaniu, fokusie albo kliknięciu. Przeglądarka bez syntezy mowy – przycisk się chowa.
 * Zastępuje wtyczkę „Text To Speech TTS Accessibility” (AtlasVoice), pierwsze wdrożenie: budyzosine.monar.org.
 */
defined( 'ABSPATH' ) || exit;

function mu_dost_odsluch_wlaczony() {
	$o = mu_dost_opcje();
	return $o['wlaczony'] && ! empty( $o['odsluch'] ) && is_singular( (array) $o['odsluch_typy'] );
}

add_filter( 'the_content', function ( $tresc ) {
	if ( is_admin() || is_feed() || ! in_the_loop() || ! is_main_query() || ! mu_dost_odsluch_wlaczony() ) {
		return $tresc;
	}
	static $raz = false; // tylko raz na stronie
	if ( $raz ) {
		return $tresc;
	}
	$raz = true;
	$o   = mu_dost_opcje();
	$js  = MU_DOST_URL . 'assets/odsluch.js?ver=' . MU_DOST_VER;
	$ico = '<svg class="mu-odsluch__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path class="mu-odsluch__graj" d="M8 5v14l11-7z"/><path class="mu-odsluch__pauza" d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>';
	$btn = '<div class="mu-odsluch" data-js="' . esc_url( $js ) . '" data-lang="' . esc_attr( str_replace( '_', '-', get_locale() ) ) . '"><div class="mu-odsluch__in">'
		. '<button type="button" class="mu-odsluch__btn" aria-pressed="false" data-tekst="' . esc_attr( $o['odsluch_tekst'] ) . '" data-pauza="' . esc_attr__( 'Wstrzymaj słuchanie', 'moveup-dostepnosc' ) . '" data-wznow="' . esc_attr__( 'Wznów słuchanie', 'moveup-dostepnosc' ) . '">'
		. $ico . '<span class="mu-odsluch__napis">' . esc_html( $o['odsluch_tekst'] ) . '</span></button>'
		. '<button type="button" class="mu-odsluch__stop" hidden aria-label="' . esc_attr__( 'Zatrzymaj słuchanie', 'moveup-dostepnosc' ) . '" title="' . esc_attr__( 'Zatrzymaj słuchanie', 'moveup-dostepnosc' ) . '"><svg class="mu-odsluch__ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6h12v12H6z"/></svg></button>'
		. '</div><span class="mu-a11y-sr" role="status" data-odsluch-status></span>'
		. '</div>';
	return $btn . $tresc;
}, 1 );

add_action( 'wp_head', function () {
	if ( ! mu_dost_odsluch_wlaczony() ) {
		return;
	}
	$o = mu_dost_opcje();
	$a = esc_attr( $o['kolor_tla'] );
	$i = esc_attr( $o['kolor_ikony'] );
	$b = '.mu-odsluch .mu-odsluch__btn';
	$s = '.mu-odsluch .mu-odsluch__stop';
	echo '<style id="mu-odsluch-css">'
		. '.mu-odsluch{min-height:40px;margin:0}'
		. '.mu-odsluch__in{display:flex;gap:8px}'
		// od 1.6.1: podczas słuchania i pauzy przycisk jedzie ze stroną (przypięty u góry, gdy jego miejsce wyjedzie z ekranu); po „Zatrzymaj” wraca na miejsce
		. '.mu-odsluch--przypiety .mu-odsluch__in{position:fixed;z-index:2147482990;top:var(--mu-odsluch-gora,8px);left:var(--mu-odsluch-l,8px);width:var(--mu-odsluch-w,calc(100% - 16px));border-radius:6px;box-shadow:0 4px 18px rgba(0,0,0,.28)}'
		. '.mu-odsluch.mu-odsluch--brak{display:none}'
		. $b . ',' . $b . ':hover,' . $b . ':focus,' . $s . ',' . $s . ':hover,' . $s . ':focus{display:flex!important;align-items:center;justify-content:center;gap:10px;min-height:40px!important;margin:0!important;padding:6px 16px!important;border:0!important;border-radius:6px!important;background:' . $a . '!important;color:' . $i . '!important;font:inherit!important;font-size:16px!important;line-height:1.3!important;font-weight:500!important;text-align:center;text-transform:none!important;letter-spacing:0!important;box-shadow:none!important;cursor:pointer}'
		. $b . '{flex:1 1 auto}'
		. $s . '{flex:0 0 48px;padding:6px!important}'
		. $s . '[hidden]{display:none!important}'
		. $b . ':hover,' . $s . ':hover{filter:brightness(1.15)}'
		. $b . ':focus-visible,' . $s . ':focus-visible{outline:3px solid ' . $a . '!important;outline-offset:3px!important}'
		. '.mu-odsluch__ico{width:18px;height:18px;flex:0 0 auto;fill:currentColor}'
		. '.mu-odsluch__pauza,.mu-odsluch__btn[aria-pressed="true"] .mu-odsluch__graj{display:none}'
		. '.mu-odsluch__btn[aria-pressed="true"] .mu-odsluch__pauza{display:inline}'
		. '.mu-odsluch-czytany{outline:3px solid #ffde00!important;outline-offset:3px!important;box-shadow:0 0 0 6px rgba(0,0,0,.65)!important;border-radius:2px}'
		. '.mu-a11y-sr{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}'
		. '@media print{.mu-odsluch{display:none!important}}'
		. "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- wartości oczyszczone wyżej
	// wczytanie skryptu przy pierwszym najechaniu / fokusie / kliknięciu (kliknięcie zapamiętane i wykonane po wczytaniu)
	echo '<script id="mu-odsluch-init">document.addEventListener("DOMContentLoaded",function(){var w=document.querySelector(".mu-odsluch");if(!w)return;if(!("speechSynthesis" in window)){w.className+=" mu-odsluch--brak";return}var z=0;function l(){if(z)return;z=1;var j=document.createElement("script");j.src=w.getAttribute("data-js");document.head.appendChild(j)}w.addEventListener("pointerover",l,{once:true});w.addEventListener("focusin",l,{once:true});w.addEventListener("click",function(e){var b=e.target.closest("button");if(b&&!window.muOdsluch){l();window.muOdsluchKlik=b}})});</script>' . "\n";
}, 3 );
